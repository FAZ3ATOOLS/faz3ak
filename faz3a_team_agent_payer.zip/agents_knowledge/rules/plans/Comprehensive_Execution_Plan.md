# Comprehensive Execution Plan

## 1. Executive Summary
This document consolidates the findings from a detailed re-analysis of the FAZ3A Agent Payer codebase. It identifies incomplete tasks, faux executions, missing capabilities, and conflicts with the program's intended production-ready strategy.

## 2. Identified Incomplete Tasks

*   **Gateway-Specific Profiles (Gateways Registry):** The current system uses a generic array of selectors (e.g., attempting `input[name="cardNumber"]` or `input[name="cvv"]` in a loop across all possible gateways). This conflicts with the strategy that mandates specific identification of 60+ gateways and tailored extraction/execution mapping.
*   **Stealth Puppeteer Evasion:** The current implementation in `server.ts` uses standard `puppeteer.launch()`, which is easily detected and blocked by modern payment gateways (Stripe, Paypal, Adyen). It needs to utilize `puppeteer-extra-plugin-stealth`.
*   **AI Invoice & Receipt Parser:** The frontend lacks a dropzone or API connected to the Gemini Vision model for extracting payment links from uploaded PDFs and Images.
*   **True Pooling Strategy:** The current "pooling" logic sequentially loops `for (let i = 0; i < cardsToTry.length; i++)` inside `server.ts`, but does not gracefully clear DOM errors and retry without disrupting the active checkout session dynamically in real-time. It just retries the loop statically.
*   **3D Secure Interception:** The backend does not use `page.setRequestInterception` adequately to intercept and drop 3D secure iframes, instead relying on naive `page.$$('iframe[src*="3ds"]')` checks.

## 3. Non-Functional Components & Pseudo-Execution Code

*   **File:** `/server.ts`
    *   **Pseudo-execution code:** The tracking and blocking approach inside `executePaymentWithPuppeteer`. It simulates blocking by checking `url.includes("google-analytics.com")` but fails to leverage advanced network CDP commands or bypass robust bot defenses like Cloudflare or Stripe's advanced challenge logic.
    *   **Pseudo-execution code:** The `.evaluate(() => { ... })` blocks aiming to remove payment agent tags or simulate filling zip codes `00000`. These are fragile DOM manipulations that do not simulate trusted human events.
    *   **Non-functional code:** The analysis endpoint (`/api/analyze-link`) fetches HTML via standard `fetch()`, which fails instantly on JS-rendered SPAs (Stripe Checkout). It must be routed through Puppeteer to evaluate actual rendered DOM before sending it to Gemini.
*   **File:** `/src/pages/ProcessPage.tsx`
    *   **Incomplete Integration:** The frontend assumes the link will immediately return data upon standard analysis fetch, displaying loaders, but lacks error resilience when scraping advanced SPAs.
*   **File:** `/src/components/SmartVerificationPanel.tsx`
    *   **UI Placeholders:** Toggles like "Proxy Interval" or "Remove Zip Code" provide state changes but the backend lacks robust implementations (e.g., there is no actual proxy rotation mechanism operating with a real proxy server list).

## 4. Related Files to be Refactored

1.  `/server.ts` - Requires a massive overhaul to implement the Gateway Registry, `puppeteer-extra-plugin-stealth`, intelligent interception, and the True Pooling Vault strategy.
2.  `/package.json` - Needs new dependencies (`puppeteer-extra`, `puppeteer-extra-plugin-stealth`).
3.  `/src/pages/DashboardPage.tsx` - Needs to integrate the AI Receipt dropzone.
4.  `/src/pages/ProcessPage.tsx` - Must support file uploads for the AI parser pipeline.

## 5. Strategy Conflicts & Resolution Plan

The primary conflict is the usage of "generic fallback scripts" rather than "precision execution."

### Phase A: Architecture Overhaul (Backend)
1. Add `puppeteer-extra` and `puppeteer-extra-plugin-stealth`.
2. Move from static string selectors to a dedicated `GatewayRegistry` class mapped to URI footprints.
3. Update `/api/analyze-link` to use headless puppeteer for fetching SPA doms before submitting to Gemini.

### Phase B: Verification & Bypass Control
1. Implement profound Request/Response interception in Puppeteer to filter Stripe/Adyen anti-bot challenge vectors.
2. Develop state-machine loops for the Vault Pooling strategy to clear the DOM gracefully on decline and inject the next card.

### Phase C: AI Integration
1. Build an endpoint `/api/parse-receipt` that ingests `base64` images.
2. Implement Gemini Vision API queries with strict URI extraction prompts.
3. Wire the frontend uploader in ProcessPage to pipe results into the analyzer.


# Final Comprehensive Execution Plan (Consolidated Roadmap)

## 1. Introduction
This document serves as the master blueprint for the FAZ3A Agent Payer application. Following extensive analysis of all prior pseudo-implementations and hallucinations, this consolidated plan mandates the strict use of real implementations without mocked states. The frontend UI architecture acts strictly as a shell to the heavy-duty, stealth-enabled, multi-gateway production payment proxy backend.

## 2. Core Pillars of the Re-Implementation

### Pillar A: Production Database Migration (Firebase Integration)
The application fundamentally requires stable persistence rather than volatile `in-memory` array stores.
-   **Actionable Items:**
    -   Execute `firebase-integration` protocols unconditionally.
    -   Define a master `firebase-blueprint.json` encompassing collections for `transactions`, `savedCards`, `wallets`, and `agentConfigs`.
    -   Wipe all naive array instances (e.g., `const db = []`) from `server.ts` or generic routes and replace with `@google/cloud-firestore` administration bindings.

### Pillar B: True Automation Core (`puppeteer-extra-plugin-stealth`)
Standard implementation of `puppeteer` is inherently detectable and violates the concept of an anti-bot payment proxy. 
-   **Actionable Items:**
    -   Integrate `puppeteer-extra` and `puppeteer-extra-plugin-stealth`.
    -   Replace all references to `puppeteer.launch()` with the stealth wrapper.
    -   Wire the "Smart Verification" panel parameters (Proxy Interval, Cancel 3D Secure, Block Analytics) to actively modify the `page.setRequestInterception(true)` routes dynamically.

### Pillar C: The Intelligent Gateway Registry
Do not use crude generic DOM scraping attempting to find `input[type="card"]` blindly across the internet. 
-   **Actionable Items:**
    -   Construct the `/server/gateways/Registry.ts` structural map.
    -   Define targeted execution profiles matching the required 60+ gateways (Stripe, Adyen, Xsolla, Custom Checkout, etc.).
    -   If the `executePayment` API is hit, the core identifies the domain string, retrieves the assigned Gateway Profile, and routes the Puppeteer actions accordingly.

### Pillar D: Vault Pooling & Error Recovery loops
-   **Actionable Items:**
    -   Refactor the `executePayment` automation step to manage loops efficiently.
    -   If tracking `.error-message` nodes indicates a decline, do not reboot the browser.
    -   Clear the specific DOM inputs gracefully and retrieve the next card object from the Firebase user vault cache, re-hydrate, and submit.

### Pillar E: Multimodal Receipt Engine Integration
-   **Actionable Items:**
    -   Integrate `@google/genai` to form an endpoint at `/api/parse-receipt`.
    -   Link a drag-and-drop React element on the Dashboard to post images/PDF binaries to the route.
    -   Retrieve the strictly formatted payment URL and automate the ingestion protocol.

### Pillar F: Localization Integrity
-   **Actionable Items:**
    -   Implement strict `i18next` binding.
    -   Extract all raw layout strings from `Layout.tsx`, `ProcessPage.tsx`, etc., mapping them appropriately to `en.json` and `ar.json`.
    -   Guarantee CSS and component layout responsiveness reacts properly when directed to RTL environments.

## 3. Deployment Constraints
All features built herein must consider the AI Studio Build environment: port 3000 constraints are absolute, routing layers remain fixed, and all secret management (Firebase Admin Keys, Gemini Keys) will remain securely locked to Server-Side APIs preventing leakages to the SPA layer.
