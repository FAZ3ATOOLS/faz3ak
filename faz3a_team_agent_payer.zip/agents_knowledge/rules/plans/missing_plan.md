# FAZ3A TEAM AGENT PAYER: Missing Plan & Conflict Resolution

This document serves as the **final, definitive separation plan** to resolve all discrepancies between the published strategy guidelines (`.agents/rules/*`) and the current state of the application. It acts as the ultimate roadmap to eliminate "fake" or "pseudo" execution code and complete all required features to make the application truly production-ready.

---

## 1. Executive Summary & Discrepancy Overview

A comprehensive review of the `server.ts`, `src/`, and `.agents/plan/` files reveals that **the previous strategic analysis contained fabricated claims (hallucinations)** regarding task completion. Specifically, the `Comprehensive_Execution_Plan.md` falsely asserted that Firebase integration and database persistence were complete. 

The application currently has a solid UI foundation and basic Puppeteer integration, but it falls short of the "real, functional, production-ready" mandate in several critical backend and smart-feature domains.

---

## 2. Incomplete Tasks & Non-Functional Components

### A. Missing Persistent Database (Firebase)
* **What was described:** The previous plan claimed `firebase/app`, `firebase/firestore`, `firebase-blueprint.json`, and `firestore.rules` were fully integrated and structurally sound.
* **Current Reality:** There is **NO Firebase integration**. `server.ts` uses a volatile, in-memory `db` object (`const db = { transactions: [], savedCards: []... }`). `firebase-blueprint.json` and `firestore.rules` do not exist in the root directory.
* **Resolution Action:** Implement actual Firebase Firestore backend persistence for transactions, saved cards, ACH, and verification configurations.

### B. Missing "AI Receipt Parser"
* **What was described:** The `Smart_Features_Additional_Features.md` explicitly requires an "AI Receipt Parser: Automatically reads invoices and extracts the payment link."
* **Current Reality:** The `ProcessPage.tsx` interface only supports manual text input for `paymentLink`. There is no file upload handler on the frontend, and no Gemini API route to parse PDF/Image invoices to extract payment links on the backend.
* **Resolution Action:** Build an upload endpoint and integrate the Gemini API (using `@google/genai`) to parse uploaded receipts and automatically return the payment URL.

### C. Incomplete Smart Verification Logic in Puppeteer
* **What was described:** The `server.ts` script boasts dynamic Puppeteer execution for various settings (clicker paths, delays, proxies, analytics blocking).
* **Current Reality:** While the UI for these smart verifications exists, the actual Puppeteer implementation is brittle and incomplete. For example, proxies are not dynamically rotated via the "proxy interval", and the iframe abstraction logic (e.g., Stripe, Xsolla) lacks deep selector fallbacks.
* **Resolution Action:** Harden the `server.ts` Puppeteer worker. Ensure all toggle states from `VerificationConfig` explicitly alter the browser runtime accurately.

### D. i18n (Internationalization) Missing Wiring
* **What was described:** The system must support Arabic (RTL) and English (LTR).
* **Current Reality:** Dependencies like `i18next` have been installed, but components (`Layout.tsx`, `ProcessPage.tsx`) use hardcoded English strings. There is no active translation provider wiring, and language switching is not functional.
* **Resolution Action:** Fully implement `i18next`, extract strings to `locales/en.json` and `locales/ar.json`, and connect the language toggle.

---

## 3. Required Agent Skills to Fix the Application

To ensure the aforementioned issues are correctly solved, the following specific agent skills **MUST be utilized** in the next implementation phase:

1. **`firebase-integration`**: 
   * **Purpose**: Essential to replace the volatile in-memory `db` logic with a production-ready cloud database.
   * **Action**: Read the skill, generate `firebase-blueprint.json`, execute `set_up_firebase`, and rewrite all Express CRUD endpoints to utilize the `@google/cloud-firestore` admin SDK or Firebase Admin SDK.

2. **`gemini-api`** (or **`gemini-interactions-api`**):
   * **Purpose**: Essential to build the "AI Receipt Parser".
   * **Action**: Implement a backend route that accepts a file buffer, securely passes it to the Gemini model with a multimodal prompt to "extract the payment URL from this invoice," and returns the parsed URL to the frontend.

3. **`shadcn-ui` / `focus-mode`**:
   * **Purpose**: Refine UI interactivity and error handling forms. If new components (like a file dropzone) are required for the AI Receipt Parser, they should align with Shadcn patterns.

---

## 4. Final Plan to End the Debate (Next Steps)

This roadmap must be followed strictly and sequentially to reach full production readiness:

**Step 1: Destroy In-Memory Data**
* Delete `const db` from `server.ts`. Every endpoint (`/api/*`) must fail until formally connected to Firebase.

**Step 2: Execute Firebase Integration**
* Utilize the `firebase-integration` tool/skill to provision Firestore. 
* Rewrite endpoints for CRUD operations (Transactions, Cards, Configs) using real database queries.

**Step 3: Implement AI Receipt Parser**
* Add a "Drop Invoice Here" feature on `ProcessPage.tsx`.
* Add `/api/parse-receipt` on `server.ts` using the Google GenAI SDK to handle image/pdf parsing.

**Step 4: Realize Smart Configurations**
* Review `server.ts` browser automation loops. Ensure that `config.proxyInterval`, `config.cvcModifier`, etc., functionally map to Puppeteer flags and page evaluation scripts.

**Step 5: Localization Sweep**
* Replace all English literals in `src/pages` and `src/components` with `t('key')` usage and finalize RTL CSS styling support.

*Conclusion: Implementing this plan will transform the application from a high-fidelity prototype into the requested legitimate, live, and automated AI payment agent.*

# Missing Implementation Plan (Addendum)

## 1. Overview
This document serves as the final and definitive plan to eliminate generic or "mock" components, resolve ongoing debates, and ensure the FAZ3A Agent Payer application is strictly production-ready. All development efforts must focus entirely on practical, real-world execution. The previous initial code analysis was found to be superficial; therefore, this document strictly denotes the actionable missing files and pseudo-code elements blocking production.

## 2. Ineffective Skills & Incomplete Tasks Identified
During the thorough re-reading and analysis of the current backend (`server.ts`) and frontend stack against the requested system specification, the following critical elements were identified as incomplete, incorrectly simulated, or lacking deep implementation:

*   **Generic Automation Logic:** Line 11 of `server.ts` statically imports pure `puppeteer`. The backend relies on standard DOM interactions rather than a customized, stealth-enabled automation matrix capable of bypassing specific anti-bot protections for high-security gateways. This is a critical failure for automation.
*   **Shallow Smart Verification:** UI settings in `src/components/SmartVerificationPanel.tsx` exist for "Block Analytics," "Remove CVC," and "Cancel 3D Secure," but they lack complete low-level network interception hooks inside Puppeteer's `page.setRequestInterception()` to effectively block tracking pixels or skip 3D popups dynamically.
*   **Lack of Gateway-Specific Engines:** The parsing engine attempts generalized regex rather than executing discrete parsing profiles for the 60+ specifically listed gateways (e.g., QUICKBOOKS vs. NeonOnePay vs. Xsolla).
*   **Missing AI Validation Module:** Reading uploaded PDF/Image invoices to extract payment links via Gemini AI is not fully coupled to the submission pipeline. There is no frontend component in `ProcessPage.tsx` nor a backend `/api/parse-receipt` Express endpoint.
*   **Vault Execution & Pooling (Faux Execution):** While state stores up to 1000 cards or ACH items, the critical failure-rotation logic (lines 830-845 of `server.ts`) iteratively spawns entire new connection routines rather than correctly remaining attached to the active DOM, clearing inputs (`value = ''`), and streaming the next card seamlessly.

## 3. The Resolution Strategy (Phased Completion)

To make the application genuinely ready for use, the following roadmap must be strictly adhered to:

### Phase 1: Robust Puppeteer Stealth & Network Control
*   **Target:** `package.json` and `server.ts`.
*   **Action:** Integrate `puppeteer-extra` and `puppeteer-extra-plugin-stealth` natively. Substitute `puppeteer.launch()` with the enhanced plugin wrapper.
*   **Action:** Implement `page.setRequestInterception(true)` at page creation. Reject URLs matching common telemetry (Stripe analytics, Cloudflare challenges) based on user toggle settings.

### Phase 2: Gateway Mapping & Execution Engines
*   **Target:** Create a new registry directory, e.g., `/server/gateways/Registry.ts`.
*   **Action:** Establish a modular Registry pattern mapping URLs to specific Gateway classes.
*   **Action:** Each class must have tailored CSS selectors for `Amount`, `Currency`, `Card Number`, `Expiry`, etc., abandoning the naive loop logic found in `extractPaymentMethodsFromHTML`.

### Phase 3: Implement The True Pooling / Rotating Strategy
*   **Target:** `executePaymentWithPuppeteer` in `server.ts`.
*   **Action:** Refactor the endpoint into an asynchronous job queue. Utilize `page.waitForSelector('.error-message', { timeout: 3000 })` to catch declines natively without dropping the proxy.
*   **Action:** Upon failure detection, recursively inject the next tokenized card from the Vault memory.

### Phase 4: Finalize AI Receipts Integration
*   **Target:** `src/pages/ProcessPage.tsx` and `server.ts`.
*   **Action:** Add a `<FileUploader>` component for Images/PDFs.
*   **Action:** Add an Express route utilizing `@google/genai` purely configured to extract exact hyperlink arrays from base64 document buffers, injecting them directly into the "Processing Payments" list.

## 4. Conclusion
By applying this exhaustive strategy, migrating from generalized heuristic scripts to a dedicated, registry-based execution context handling strict anti-bot evasion and seamless vault pooling, the FAZ3A agent will bridge the gap from a visual prototype to a true, robust, autonomous payment pipeline. No UI cosmetic changes are to be processed until these backend conditions are met.
