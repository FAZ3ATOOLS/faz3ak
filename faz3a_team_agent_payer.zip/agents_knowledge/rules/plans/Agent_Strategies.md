# Agent Workflow Strategies

The FAZ3A Agent uses various strategies to maneuver payment gateways dynamically.

## 1. The Strategy Pattern (Code Structure)
- **GenericStrategy**: Uses semantic heuristics to find inputs (e.g., looking for fields with 'card', 'cv' in their name or placeholder).
- **StripeStrategy**: Interacts specifically with Stripe JS elements, targeting iframes specifically used by Stripe v3.
- **PayPalStrategy**: Clicks the standard PayPal buttons and navigates the subsequent popup/iframe flows.

## 2. DOM Manipulation (Stealth Module applying User Verification Controls)
These strategies are toggled in the Smart Verification Panel:
- **CVC Modifier:** Finds the CVC input and either fills generated data, attempts to delete the HTML element (`remove`), or skips it.
- **Cancel 3D Popup:** Detects standard `div` overlays and iframe overlays related to Verified-by-Visa or Mastercard SecureCode and attempts `display: none` or script interception.
- **Block Analytics:** Overrides global variables `ga`, `fbq`, etc., inside the browser context to prevent tracking the automated scripts.
- **Zip Code Removal:** Identifies Zip/Postal inputs and forcibly clears validation requirements if front-end based.

## 3. Interaction Humanization
- **Delay:** Arbitrary `setTimeout` pauses between key presses to simulate human typing rates (`delay(5000)`).
- **Click on Load (Delay):** Waiting for specific DOM 'ready' events before firing click triggers.
- **Proxy Rotation:** Re-routing the execution endpoint IP every interval.
