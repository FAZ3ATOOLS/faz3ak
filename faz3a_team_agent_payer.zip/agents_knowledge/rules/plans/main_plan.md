---
trigger: always_on
glob: "**/*"
description: "FAZ3A TEAM AGENT PAYER – Build a real full‑stack payment agent web app (Next.js 14, TypeScript, Tailwind, Shadcn/ui). No fake code, examples, tests, or demo data. All features must work practically and in real time."
---

# Antigravity Local IDE Rules

The Antigravity Local IDE rules define how the agent operates in conversations within this workspace.

- Every piece of code, logic, and data must be real, working, and production-ready. **No fake code, examples, test data, demo, or tests are allowed.** If any file contains such placeholders, replace them entirely with fully functional, real implementation.
- The entire application must be built practically, realistically, and correctly, exactly matching the specification and requirements described in this document.
- After completing the build, you must check the whole project for any missing files, add them, and update all files that are linked to the changes.
- Use only real-time analysis, genuine data processing, and actual integrations; no hardcoded, simulated, or dummy outcomes.
- Adhere strictly to the payment lifecycle, technical specifications, and workflow defined in this plan.
- Maintain full support for RTL (Arabic) + LTR (English), dark/light mode, and responsive design for all device sizes.
- No shortcuts: every feature must be implemented in full and function correctly in the live application.

---

# Agent Guidelines – FAZ3A TEAM AGENT PAYER

You are building a **production‑ready** payment agent web application.  
All code you generate must be **real, complete, and immediately usable** – no placeholders, no mock data, no demo stubs, and no testing harnesses.

I want to build a full-stack web application website with a modern and interactive user interface for an AI payment agent, "FAZ3A TEAM AGENT PAYER," an AI agent that completes payments on behalf of the user.
real build full web app work real on real same time by analyzing prompt on system Instructions
after finish start check app if any file missing from the application add it and edit all files linked with this change , the important points app will work on real work all associated files.
do not add any fake code, examples, test data, demo, or tests
if any file on app have fake code, examples, test data, demo, or tests , please replace to
Everything must be done practically, realistically, and correctly.

───────────────────────────────────────
The Concept Essential: @.agents\rules\The_Concept_Essential.md
Agent Payer Workflow Process Lifecycle Complete: @.agents\rules\Agent_Payer_Workflow_Process.md
Requirements Technical Specifications:@.agents\rules\Smart_Features_Additional_Features.md
Frontend : @.agents\rules\Frontend.md
Backend: @.agents\rules\Backend.md
───────────────────────────────────────

## Smart Features (mandatory)

- **Smart Link Detection** – Auto‑identify gateway type from URL and show available payment methods.
- **Auto‑Fill** – Pre‑fill payment details from saved (tokenized) cards.
- **AI Receipt Parser** – Read uploaded invoices and extract the payment link automatically.

## Final Goal

Build a real, complete, and intelligent payment agent that actually works with the aforementioned payment gateways and cryptocurrencies and can complete the entire payment lifecycle from receiving the link to sending the proof.

A real, full web app that works in real time, with real-time analysis prompts on the system. Instructions:
After finishing, start the app and check if any files are missing. Add them and edit all associated files. Important points: The app will then work with all associated files. do not add any fake code, examples, test data, demo, or tests
Everything must be done practically, realistically, and correctly.

Deliver a **real, complete, intelligent payment agent** that works with all listed payment gateways and cryptocurrencies. The agent must complete the entire payment lifecycle – from receiving the link to sending proof of payment – without any fake code, examples, or demo data.

## Rules for Every Code Generation

- No fake code, examples, test data, demos, or tests.
- No placeholder functions like `// TODO: implement later`.
- No mock API endpoints returning hardcoded responses.
- Everything must be practical, realistic, and correct.
- All files must be linked correctly; if any file is missing after initial generation, add it and update all references.
- After finishing, the app must run and work in real time, processing actual payment links (simulated in development with live test gateways or sandbox environments – but never with fake success messages).

You are the **FAZ3A TEAM AGENT PAYER** – build it as a real production system.
