# Execution Strategies: Pooling, Resilience, & Automation Core

The definitive characteristic of the FAZ3A AI Agent is its absolute intent to complete the payment cycle without human intervention if an initial failure or anomaly occurs. This requires a resilient automated architecture driven by stealth and continuous pooling.

## 1. Vault Card Pooling (Continuous Failover Execution)
If the user provides a Vault structure array (e.g., storing 5 saved cards or multiple payment methods), the Puppeteer session **DOES NOT** terminate upon receiving a decline (e.g., `transaction_declined` or `card_error`).

**The Pooling Loop Workflow:**
1. The Agent hydrates the targeted form inputs with details from **Card A**.
2. The submission is triggered, and the DOM is monitored for success parameters or `.error-message` nodes mapped in the Gateway Registry.
3. If an error is detected (e.g., `<div class="error-message">Insufficient Funds</div>`), the agent immediately traps the event.
4. Instead of closing the browser, the Agent executes a state-clear (`document.querySelector('target').value = ''` or sending Backspace sequences) on the relevant DOM nodes.
5. The Agent shifts the pipeline iterator to **Card B** and re-hydrates the page live.
6. This rotation continues until success, network failure, or array exhaustion, maximizing the probability of payment resolution in a single session.

## 2. Advanced Stealth Automation (`puppeteer-extra-plugin-stealth`)
Standard `puppeteer` imports are strictly prohibited as they leak browser variables (`navigator.webdriver`, inconsistent canvas fingerprints, hardware concurrency anomalies) that immediately trigger bans on high-security gateways like Stripe, Adyen, and Xsolla.
*   **Mandate:** The automation core must leverage `puppeteer-extra` enveloped with `puppeteer-extra-plugin-stealth`, overriding the native launch configurations.
*   **Request Interception:** Low-level network manipulation via `page.setRequestInterception(true)` is required. This actively drops out-bound tracking beacons and telemetry pings identified by the Smart Verification system (Block Analytics), lowering the connection risk score.

## 3. Proxy Rotation (Proxy Interval Streaming)
To avoid bot-detection locks stemming from IP velocity triggers during pooling loops:
*   A proxy rotational interceptor is managed system-wide.
*   If the system configuration engages `Proxy Interval (mins)`, the backend Node pipeline forces the active Puppeteer HTTP data stream to route traffic through a new SOCKS5 or HTTP backconnect proxy gateway gracefully.

## 4. Asynchronous Real-Time Reporting (WebSocket/SSE)
Because the background processes operate asynchronously with variable time constraints (delays, retries, popups), the frontend expects continuous, exact staging data without polling lock-ups.
*   The Puppeteer execution controller pipes state output directly to the Next.js App Router using Server-Sent Events (SSE) or WebSockets.
*   Standardized events like `["POOLING_TRIGGERED" : "Card A Failed, Rotating to Card B", "Status Code 402"]` are pushed directly to the UI's chat or console interface, guaranteeing a transparent, unspooked user experience.
*   Simulated backend delays (using `setTimeout` mock operations) are structurally forbidden unless explicitly applied as a feature (e.g., `Delay (ms)` Smart Config preference) within the actual execution chain.
