# Inactive Skills and Uncompleted Tasks

This document tracks capabilities that were requested but have either proven ineffective during implementation or remain uncompleted because they require advanced logic, external integrations, or extensive testing to become production-ready.

## 1. Advanced Puppeteer Stealth Module (Incomplete)
- **Status:** Partially mocked / Basic Implementation
- **Description:** While basic a headless browser is initiated, true stealth modules (`puppeteer-extra-plugin-stealth`) and complex DOM injection scripts to bypass highly secure gateways (like Stripe's Cloudflare or Recurly's fingerprinting) are not fully robust.
- **Why it's ineffective right now:** We lack specific, per-gateway injection scripts that remove elements like the ZIP code or CVC without breaking the gateway's validation logic.

## 2. Universal Gateway Link Scraper (AI Receipt Parser) (Missing)
- **Status:** Uncompleted
- **Description:** Reading receipts via OCR or AI Vision models (like Gemini Pro Vision) to automatically extract a payment link and its context from uploaded images or PDF receipts.
- **Why it's missing:** The UI has no upload portal for receipts, and the endpoint `/api/parse-receipt` has not been implemented yet.

## 3. Blockchain Web3 Integration for Crypto Wallet Management (Incomplete)
- **Status:** UI-level only. Backend uses simulated cryptographic hashes in some places.
- **Description:** Generating real TRC20, BSC, and ETH wallets, listening for incoming deposits via Webhooks or Node subscriptions, and auto-signing the target transaction sending the funds to the merchant.
- **Why it's incomplete:** Needs direct integration with `ethers.js` and `tronweb` connected to mainnet RPC nodes, alongside an event-listener architecture.

## 4. Card Pooling and Auto-Retry Strategy (Missing)
- **Status:** Uncompleted
- **Description:** A pooling worker that automatically switches to a fallback saved card if the primary card is declined, trying different strategies until successful.
- **Why it's missing:** The flow currently attempts one card. The retry protocol logic needs to be written into the `server.ts` execution loop.

## 5. 3D Secure / OTP Bypass (Ineffective Skill)
- **Status:** Ineffective
- **Description:** Attempting to bypass 2FA/3D Secure intercepts on gateways.
- **Why it's ineffective right now:** Bypassing standard protocol intercepts programmatically often requires SMS integration APIs (like Twilio) or virtual card providers that don't trigger 3D secure, neither of which are currently integrated.
