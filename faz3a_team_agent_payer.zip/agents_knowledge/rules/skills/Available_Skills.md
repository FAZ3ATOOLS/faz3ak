# Available_Skills

This document lists all active and available skills for the AI Agent, including their full descriptions, use cases, and strategies, exactly as defined in the system.

## 1. firebase-integration
**Description:** Integrate Firebase (Firestore and Auth) into applications, generate secure rules, and handle errors.
**Strategy and Use Cases:**
Use this skill in the following scenarios:
* New Backend Requirements: When the user requests to add a database, persistent storage, or user authentication to their application and Firestore with Firebase Authentication is a good fit.
* Schema Design: When defining the data structure for a new feature or application using Firestore.
* Security Hardening: When generating or auditing Firestore security rules to prevent unauthorized access and data leaks.
* Troubleshooting: When debugging "Missing or insufficient permissions" errors or other Firebase-related failures.
* SDK Integration: When adding Firebase initialization and data fetching code to a React or TypeScript application.
**Constraints:** Do NOT use this skill for:
* General GCP resource management outside of the specific Firebase tools provided.
* Applications that do not use or intend to use Firebase as their backend.

## 2. focus-mode
**Description:** Instructions for responding to UI element selection (CSS selectors).

## 3. gemini-api
**Description:** Provides model selection guidance and coding patterns for the @google/genai TypeScript SDK. 
**Strategy and Use Cases:** 
Use when the application requires AI capabilities (e.g., text/image generation, smart features) or when the task involves implementing an "AI-powered" feature. The model should prefer this modern SDK over legacy alternatives. Covers model aliases, streaming, chat, function calling, search and maps grounding, Live API, TTS, and API key handling.
**Constraints:** Do NOT use for general discussions about AI without implementation intent.

## 4. gemini-interactions-api
**Description:** Provides coding patterns for the @google/genai TypeScript SDK. 
**Strategy and Use Cases:** 
Covers using the Interactions API for the Antigravity agent, Deep Research agent, and general model capabilities (text, image, speech generation), as well as other specialized APIs for video (Veo), music (Lyria), and real-time audio (Live API) in a server-side context. Use when user requests the Interactions API, Antigravity agent, or Deep Research agent.

## 5. github-import-migration
**Description:** Execute-First migration for GitHub repositories imported into AI Studio. 
**Strategy and Use Cases:** 
Triages projects and routes to the appropriate self-contained migration reference. Supports Web (Node.js) and Android (Kotlin/Compose) runtimes.

## 6. google-maps-platform
**Description:** Provides architectural guidance and generates production-ready code for applications using Google Maps Platform. 
**Strategy and Use Cases:** 
Specializes in building software with location APIs and SDKs such as Places API (New), Routes API, and Address Validation API, utilizing modern React patterns. Dynamically retrieves documentation and code context via the rpc_action tool to provide accurate implementation details. Use this skill when you need to implement any location-based application task or solution, such as a Store Locator, Checkout/shipping experiences with address validation, data visualizations on maps, or directions routing logic in a React application.

## 7. image-generation
**Description:** Use when the application needs to generate or update images — hero banners, illustrations, icons, backgrounds, avatars, product photos, or any visual asset. 
**Strategy and Use Cases:** 
Covers image selection strategy (using tools vs assets vs placeholders) and runtime generation using Gemini models.

## 8. oauth-integration
**Description:** Guidelines for implementing OAuth flows (Strava, GitHub, etc.) in the AI Studio preview environment. 
**Strategy and Use Cases:** 
Use when the user requests OAuth, login with third-party services, or popup-based authentication. Covers iframe constraints, cookie configuration, and redirect URI setup.

## 9. real-time-and-multi-user
**Description:** Guidelines for implementing real-time features, WebSockets, and collaborative canvases. 
**Strategy and Use Cases:** 
Use when the app requires chat, live collaboration, multiplayer games, or notifications. Covers server-authoritative state, event-based communication, and canvas library selection (Konva, Fabric.js).

## 10. shadcn-ui
**Description:** Guidelines for using shadcn/ui components and CLI. 
**Strategy and Use Cases:** 
Use ONLY when the user requests shadcn or shadcn/ui. Covers initialization, adding components, community registries, and theming.

## 11. workspace-integration
**Description:** Integrate Google Workspace APIs (Drive, Docs, Sheets, Slides, Calendar, Gmail, Chat, Meet, Forms, Tasks, Keep, People) into the application. 
**Strategy and Use Cases:** 
Use when the user wants to read, write, or search Workspace data. Requires OAuth setup via the set_up_oauth tool.
