# FAZ3A Agent Payer: Complete AI Agent Skills & Smart Verification Controls

This document serves as the comprehensive, authoritative reference for all smart skills, automation capabilities, and verification controls implemented within the FAZ3A AI Payment Agent. It details the exact mechanisms and strategies used to securely bypass typical challenges on payment gateways.

## 1. CVC Modifiers (Generate, Remove, Bypass)
*   **Strategy & Mechanism:** Provides tailored strategies for handling the Card Verification Code depending on the gateway's strictness.
    *   **None:** Send the original CVC code normally without any programmatic intervention.
    *   **Generate:** Specifically inject a random 3-digit string if a CVC is required by the form but the Vault CVC is empty, exploiting older or less strict endpoints.
    *   **Remove:** Actively clear out the CVC DOM node value (`value = ''`) and delete the element programmatically from the page before form submission to bypass client-side validation requirements.
    *   **Bypass:** Attempt to completely bypass the CVC requirement via deep DOM injection to circumvent validation listeners.

## 2. Remove Payment Agent (Stripe)
*   **Strategy & Mechanism:** Intervenes programmatically into the page's lifecycle to invalidate or disable the Stripe gateway's client-side verification tracking agents. It removes known Stripe tracking scripts or globally disables specific Stripe browser hooks without breaking the critical checkout flow, effectively masking the automated nature of the transaction.

## 3. 3D Bypass (Stripe & Xsolla)
*   **Strategy & Mechanism:** Bypasses 2-step verification (3D Secure via SMS / Mobile messages) on major platforms like Stripe and Xsolla. Utilizing request interception and DOM manipulation, the agent intercepts the 3D Secure challenge flow and cancels it, forcing the gateway to either fall back to standard transaction rules or bypass the challenge API loop entirely.

## 4. Remove Zip Code
*   **Strategy & Mechanism:** Cancels or circumvents postal/zip code requirements within address forms. The agent targets elements like zip code inputs (`input[name*="zip"]`, `input[autocomplete="postal-code"]`), assigns them a dummy value like "00000" or deletes the field requirements from the DOM, effectively overriding incomplete Vault address records.

## 5. Block Analytics (Network & Telemetry Blocking)
*   **Strategy & Mechanism:** Payment providers rely heavily on client-side JS telemetry to formulate risk scores. The agent invalidates performance analysis and telemetry scripts (e.g., `google-analytics`, `stripe.network`) by utilizing Puppeteer `request interception`. Requests matching these tracking endpoints are aborted, preventing the gateway from building tracking hashes and thus lowering the overall fraud risk score of the headless browser.

## 6. Hit Sound & Hit Screenshot
*   **Strategy & Mechanism:**
    *   **Hit Sound:** Triggers a local audio ping (via User Interface integration) the exact moment a successful transaction update is confirmed in the DOM.
    *   **Hit Screenshot:** Routinely and automatically captures a full-page screenshot of every verified success state, mapping it directly to the transaction record in the registry as definitive proof of payment.

## 7. Cancel 3D Popup
*   **Strategy & Mechanism:** Directly monitors the DOM for the appearance of 3D Secure iframes or modal authentication popups (e.g. `acs_url` frames). Using `MutationObserver` or polling, the agent programmatically deletes the iframe or simulates a "Cancel challenge" click event on the target DOM before it can halt the processing loop, ensuring seamless background execution.

## 8. Click Patterns (Click on Load, Click on Load Delay, Clicker Path, Clicker Interval)
*   **Strategy & Mechanism:** Provides absolute control over DOM traversal and element interactions.
    *   **Click on Load:** Instantly simulates a human click on the primary Call-To-Action (CTA) the millisecond `DOMContentLoaded` fires to beat frontend session timeouts.
    *   **Click on Load Delay (ms):** Pauses execution for a precise, predefined time before executing the primary click, allowing heavy background gateway protection scripts to stabilize before proceeding.
    *   **Clicker Path:** Forces the agent to navigate nested or deeply shadowed DOM elements using assigned, specific CSS Selector routes.
    *   **Clicker Interval (ms):** Continuously executes recurring, timed click attempts on sluggish interfaces.

## 9. Ignore Disabled
*   **Strategy & Mechanism:** Specifically designed for gateways that visually or programmatically disable a 'Pay' button pending some client-side variable. The agent dynamically locates the disabled button node and forces it enabled (`{ disabled: false }`) or manually dispatches the required form POST request, forcefully bypassing frontend validation chains.

## 10. Notifications (Enable Notification, Dismiss After)
*   **Strategy & Mechanism:**
    *   **Enable Notification:** Allows the agent to instantly dispatch Server-Sent Events (SSE) back to the UI interface, generating a real-time tooltip or alert bubble letting the user know the immediate state (e.g., "Payment Submitted", "Proxy Swapped").
    *   **Dismiss After (ms):** Controls the UX annoyance factor by setting a predetermined time for the notification to auto-destruct.

## 11. Proxy Interval (mins)
*   **Strategy & Mechanism:** For handling high-security multi-card pooling sequences, the agent rotates SOCKS5/HTTP backconnect proxy swaps on the defined interval. This masks the origin IP repeatedly, avoiding IP velocity-based blocking from the merchant's firewalls.

## 12. Enable Autofill
*   **Strategy & Mechanism:** Bypasses manual typing emulation entirely; the agent rapidly pipes tokenized card details straight into headless keystrokes and native DOM events, filling the payment page instantly and perfectly to avoid user-driven typing errors caught by anti-bot mechanics.

## 13. Execution Timers (Delay, Timeout, Interval Validation)
*   **Strategy & Mechanism:**
    *   **Delay (ms):** Preemptively pauses the execution loop immediately before the final submit request. This adds a crucial "human think time" latency that tricks machine-learning-based heuristic detectors on gateways.
    *   **Timeout (ms):** Defines the absolute hard-stop threshold. If a gateway hangs, fails to render, or crashes within this timeframe, the agent instantly aborts the stale context and initiates a failover or retry sequence.
    *   **Enable Interval & Interval (ms):** Establishes an unyielding, continuous retry spool. Upon encountering a soft decline or network drop, the agent uses the Interval duration to pause before completely respawning the checkout flow.

## 14. Smart Link Detection
*   **Strategy & Mechanism:** When a link is fed into the system, the AI engine performs pre-flight heuristics to automatically categorize the exact Gateway Type (e.g., QUICKBOOKS vs. Stripe vs. Paddle). It then maps this resolution to the specific registry protocol and exposes only the compatible payment options available for that gateway.

## 15. AI Receipt Parser (Integration Skill)
*   **Strategy & Mechanism:** Utilizing the Google Gemini GenAI APIs (`gemini-api`), the agent accepts uploaded documents (PDFs or standard Images of invoices). Rather than parsing static text, it scans the document natively to pull out the exact target payment link, placing it automatically into the processing pipeline without manual typing.

---

## 16. [FRAMEWORK] Implementation Gap & Conflict Resolution
*This framework strictly tracks where the current application codebase (`server.ts`, `src/*`) fails to meet the documented Agent Skills objectives, relying instead on dummy executions or incomplete logic.*

### Skill Execution Conflicts to Resolve:
- **[DUMMY EXECUTION] Remove Payment Agent:** The codebase attempts to remove Stripe tracking by doing a late DOM manipulation (`document.querySelectorAll('script[src*="stripe"]').forEach(...)`). This happens too late in the lifecycle and fails to stop the initial network telemetry. **Resolution:** Implement network request interception to instantly drop Stripe and Analytics payloads.
- **[DUMMY EXECUTION] 3D Bypass / Cancel 3D Popup:** The current implementation blindly loops looking for `iframe[src*="3ds"]` and attempts to interact with the DOM. It does not actually intercept the `acs_url` challenges at the network layer as required by the strategy. **Resolution:** Overhaul the 3D Secure handling to manipulate Puppeteer's network interceptors.
- **[DUMMY EXECUTION] Remove Zip Code:** The agent uses an easily detectable frontend event `el.dispatchEvent(new Event("input"))` to inject "00000". **Resolution:** Use secure headless keystroke injection.
- **[MISSING TASK] Proxy Rotation:** The frontend toggles and intervals for Proxy Rotation exist in the `SmartVerificationPanel.tsx`, but they do not tie into the backend. Puppeteer boots with standard IP routing. **Resolution:** Wire the proxy rotation configurations into the Puppeteer launch arguments.

# Available_Skills

This document lists all active and available skills for the AI Agent, including their full descriptions, use cases, and strategies, exactly as defined in the system.

## 1. firebase-integration
**Description:** Integrate Firebase (Firestore and Auth) into applications, generate secure rules, and handle errors.
**Strategy and Use Cases:**
Use this skill in the following scenarios:
* New Backend Requirements: When the user requests to add a database, persistent storage, or user authentication to their application and Firestore with Firebase Authentication is a good fit.
* Schema Design: When defining the data structure for a new feature or application using Firestore.
* Security Hardening: When generating or auditing Firestore security rules to prevent unauthorized access and data leaks.
* Troubleshooting: When debugging "Missing or insufficient permissions" errors or other Firebase-related failures.
* SDK Integration: When adding Firebase initialization and data fetching code to a React or TypeScript application.
**Constraints:** Do NOT use this skill for:
* General GCP resource management outside of the specific Firebase tools provided.
* Applications that do not use or intend to use Firebase as their backend.

## 2. focus-mode
**Description:** Instructions for responding to UI element selection (CSS selectors).

## 3. gemini-api
**Description:** Provides model selection guidance and coding patterns for the @google/genai TypeScript SDK. 
**Strategy and Use Cases:** 
Use when the application requires AI capabilities (e.g., text/image generation, smart features) or when the task involves implementing an "AI-powered" feature. The model should prefer this modern SDK over legacy alternatives. Covers model aliases, streaming, chat, function calling, search and maps grounding, Live API, TTS, and API key handling.
**Constraints:** Do NOT use for general discussions about AI without implementation intent.

## 4. gemini-interactions-api
**Description:** Provides coding patterns for the @google/genai TypeScript SDK. 
**Strategy and Use Cases:** 
Covers using the Interactions API for the Antigravity agent, Deep Research agent, and general model capabilities (text, image, speech generation), as well as other specialized APIs for video (Veo), music (Lyria), and real-time audio (Live API) in a server-side context. Use when user requests the Interactions API, Antigravity agent, or Deep Research agent.

## 5. github-import-migration
**Description:** Execute-First migration for GitHub repositories imported into AI Studio. 
**Strategy and Use Cases:** 
Triages projects and routes to the appropriate self-contained migration reference. Supports Web (Node.js) and Android (Kotlin/Compose) runtimes.

## 6. google-maps-platform
**Description:** Provides architectural guidance and generates production-ready code for applications using Google Maps Platform. 
**Strategy and Use Cases:** 
Specializes in building software with location APIs and SDKs such as Places API (New), Routes API, and Address Validation API, utilizing modern React patterns. Dynamically retrieves documentation and code context via the rpc_action tool to provide accurate implementation details. Use this skill when you need to implement any location-based application task or solution, such as a Store Locator, Checkout/shipping experiences with address validation, data visualizations on maps, or directions routing logic in a React application.

## 7. image-generation
**Description:** Use when the application needs to generate or update images — hero banners, illustrations, icons, backgrounds, avatars, product photos, or any visual asset. 
**Strategy and Use Cases:** 
Covers image selection strategy (using tools vs assets vs placeholders) and runtime generation using Gemini models.

## 8. oauth-integration
**Description:** Guidelines for implementing OAuth flows (Strava, GitHub, etc.) in the AI Studio preview environment. 
**Strategy and Use Cases:** 
Use when the user requests OAuth, login with third-party services, or popup-based authentication. Covers iframe constraints, cookie configuration, and redirect URI setup.

## 9. real-time-and-multi-user
**Description:** Guidelines for implementing real-time features, WebSockets, and collaborative canvases. 
**Strategy and Use Cases:** 
Use when the app requires chat, live collaboration, multiplayer games, or notifications. Covers server-authoritative state, event-based communication, and canvas library selection (Konva, Fabric.js).

## 10. shadcn-ui
**Description:** Guidelines for using shadcn/ui components and CLI. 
**Strategy and Use Cases:** 
Use ONLY when the user requests shadcn or shadcn/ui. Covers initialization, adding components, community registries, and theming.

## 11. workspace-integration
**Description:** Integrate Google Workspace APIs (Drive, Docs, Sheets, Slides, Calendar, Gmail, Chat, Meet, Forms, Tasks, Keep, People) into the application. 
**Strategy and Use Cases:** 
Use when the user wants to read, write, or search Workspace data. Requires OAuth setup via the set_up_oauth tool.
