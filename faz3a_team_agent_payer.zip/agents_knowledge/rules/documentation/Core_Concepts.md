# Core Concept: FAZ3A Tracker & Automation Engine

## 1. Executive Summary
The FAZ3A TEAM AGENT PAYER is a specialized AI agent system that acts on behalf of the user to process and complete payment links automatically. It takes over the entire lifecycle of a payment transaction—from receiving the URL, analyzing the gateway, fetching context, requesting payment methods (or using a vault), and executing the payment headlessly using advanced stealth browser automation. Finally, it retrieves success proofs (screenshots, IDs) and notifies the user via real-time WebSocket/SSE streams.

## 2. Essential Workflow & Lifecycle
1.  **Submission:** Instantly captures the payment link and adds it to the "Processing Payments" queue with the status "Under Analysis".
2.  **Scraping & Extraction:** Fetches the page to extract critical payment information including Amount, Currency, Description, Seller, and importantly, the specific Gateway Type.
3.  **Smart Verification:** Verifies link validity, detects context mismatches, scores fraud risk, and applies extensive anti-tracking strategies (CVC modifications, 3D Secure bypasses, proxy rotations, etc.).
4.  **Data Hydration:** Evaluates available payment methods. It uses user input via a secure popup interface or completely automates the process using Auto-Fill from the saved Cards Vault. For crypto, it provides secure, seamless smart contract routing.
5.  **Headless Execution:** Processes the payment via the backend using robust Puppeteer automation (with stealth plugins), removing the need for manual browser interaction or native API availability.
6.  **Proof Capture & Status Sync:** Uploads transaction success status, full parsed error messages if declined, captures a real full-page screenshot of the success page, and stores the transaction ID.
7.  **Real-Time Notification:** Streams live events (progress hooks) back to the client interface.

## 3. Frontend Architecture (UI/UX)
*   **Frameworks:** Next.js 14 (App Router) + TypeScript.
*   **Styling & UI:** Tailwind CSS, Shadcn/ui, Framer Motion for animations, Recharts for statistics.
*   **Localization:** Complete dual-language support for LTR (English) and RTL (Arabic).
*   **Design Language:** 
    *   *Theme:* "FAZ3A TEAM AGENT PAYER"
    *   *Colors:* Charcoal Black (`#0A0A0F`), Neon Green (`#00FF88`), Electric Blue (`#0088FF`), Gold (`#FFD700`).
    *   *Visuals:* Glassmorphism layers, Neon Glow accents, and dynamic particle backgrounds.
*   **Responsiveness:** Full dynamic display suitable for all device form factors.
*   **Security Feature:** Specialized Proxy Activation toggle in the settings accessed via the security token `Aamm0909@`.

## 4. Required Pages
1.  **Landing Page:** Explains the agent, mechanisms, and features.
2.  **Dashboard:** Live statistics, smart "Send New Payment Link" module, and real-time transaction activity feeds showing the exact lifecycle.
3.  **Submission (Process) Page:** Input field with instant link parser preview, displaying accurate un-spoofed transaction execution.
4.  **Transaction Details Page:** Progress bar tracking states, an Agent Chat Interface for execution logging, secure localized data entry forms, and transparent final result proofs.
5.  **Settings & Vault:** Management of up to 1000 tokenized saved cards, ACH routing numbers, Crypto Wallet configuration (USDT TRC20, BSC), and Agent control preferences.
