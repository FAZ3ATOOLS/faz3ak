---
trigger: always_on
glob: "**/*"
description: Backend
---

Selecting the appropriate and system-integrated interface to provide the AI ​​Engine.
• Analyzing links and extracting information to analyze payment pages, understand the context to analyze the payment description, extract the correct amount, and build integrations to access payment links without requiring an API in the backend for both card and crypto systems.

When analyzing links, the available payment methods on the link must be displayed for selection.

Smart Features Additional Features:

1. Smart Link Detection: Automatically identifies the gateway type from the link and displays available payment methods.
2. Auto-Fill: Automatically fills in payment details from saved (tokenized) cards.
3. AI Receipt Parser: Automatically reads invoices and extracts the payment link.
