# FAZ3A TEAM AGENT PAYER: Error Handling & Disaster Recovery

To ensure the application operates without future disruptions, the following error handling protocols MUST be implemented:

## 1. Puppeteer & Automation Fragility
- **Selector Dynamics**: Payment gateways frequently change CSS selectors. The automation must implement fallback selectors and fuzzy matching using XPath or textual content.
- **Timeout Escapes**: All page interactions (`waitForSelector`, `click`) MUST have defined timeouts. If a timeout occurs, a screenshot of the failure state should be saved to `/screenshots` and an error log must be written to the database.
- **Captcha/2FA Detection**: The bot must detect unexpected verification screens (3D Secure, Cloudflare turnstile) and gracefully pause the transaction, notifying the user rather than crashing.

## 2. API & Network Failures
- **Proxy Rotation Failure**: If the primary proxy drops connection, the `server.ts` must catch the `ERR_PROXY_CONNECTION_FAILED` and seamlessly retry with a secondary proxy before marking the transaction as failed.
- **Rate Limiting**: Implement exponential backoff for backend API calls.

## 3. Graceful Shutdown & Memory Leaks
- Ensure `browser.close()` is universally called in a `finally {}` block for every Puppeteer script to prevent zombie Chromium processes that drain server memory.
