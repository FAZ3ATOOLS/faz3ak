---
trigger: always_on
glob: "**/*"
description: The Concept Essential
---

A specialized AI agent that receives "payment links" from the user (QUICKBOOKS, Stripe, PayPal Checkout, Razorpay, Coinbase Commerce, NowPayments, Anedot, BasisTheory (API), BasisTheory (JS), Blackbaud, Cellpointdigital, CodaPayments, CtCt, Cybersource (flex v2), Finby, GetOpenPay) , NMI, NeonOnePay, OnerWay, Oppwa, PayCom, PayPal ACDC, PayPlus, PaymentsAI, PipoPayment (Cashier), Safecharge, Saferpay, SecurionPay, Shift4, SumUp, Tebex, TrainPal, VeryGoodProxy, VivaPayments, Wix, Zuora, Adyen , Airwallex , Antom , Authorize , Authorize (2) , Bluesnap , Braintree , Checkout , Checkout (Devices API) , Checkout (Invoice) , Computop , EGenius , Endurance , Fansly , Fansly (Tokenize) , Grammarly , Marketpay , Mercadopago , MoneyMotion , NCR Secure Pay , Nord Payments , Paddle, Patreon, Pay360 (PayStack, Payzen, Playstation, Primer, Processout, Recurly, Recurly (EU), RizzUp, Sagepay, Secure Pay, Spreedly, Square, Steam, Stripe (Billing), Worldpay (Access), Worldpay (Payments), Xendit, Xsolla, crypto wallets, etc.) performs the following:

1. Instantly captures the link and adds it to the "Processing Payments" list.
2. Fetches/Scrapes the page to extract payment information (amount, currency, description, seller, gateway type).
3. Verifies the link and amount.
4. Manages the payment process to ensure its success.
5. Requests payment information from the user (card details, crypto wallet address for the agent).
6. Executes the payment via the backend using NextJS and React technologies.
7. Sends proof of payment: screenshot + confirmation link + invoice (if available).
