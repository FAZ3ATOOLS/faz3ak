# FAZ3A TEAM AGENT PAYER: Deployment & Infrastructure Checklist

To deploy this tool without future bugs, the hosting environment must meet these precise specifications to accommodate the complex requirements of browser automation:

## 1. System Requirements for Node/Puppeteer
- Because Puppeteer requires a real underlying Chromium runtime to bypass anti-bot systems, the deployment server (VPS, Cloud Run, or Docker container) MUST include all standard Linux graphics and networking dependencies (`libxss1`, `libnss3`, `libatk-bridge2.0-0`, etc.).
- **Memory & Concurrency**: Minimum 1GB - 2GB RAM required per active concurrent browser worker. Over-provision memory to avoid out-of-memory (OOM) crashes during peak background processing. Do not spawn infinite browsers.

## 2. Environment Variables (.env)
The application MUST strictly validate the existence of these variables on startup, and gracefully shut down with warnings if missing:
- `FIREBASE_PROJECT_ID`
- `FIREBASE_ADMIN_CREDENTIALS`
- `GEMINI_API_KEY` (for AI Receipt Parsing)
- `PROXY_URL` & `PROXY_CREDENTIALS`

## 3. Database & App Initialization
- Ensure Firebase collections match the structured database rules (`firebase-blueprint.json`) before accepting real production traffic.
- Maintain `npm run build` and `dist/server.cjs` outputs up-to-date with TypeScript definitions.
