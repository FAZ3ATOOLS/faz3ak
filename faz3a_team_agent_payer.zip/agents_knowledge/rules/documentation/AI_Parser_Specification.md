# AI Receipt & Invoice Parser Specifications

A significant automated feature to optimize the FAZ3A ecosystem is bypassing manual URL extraction entirely through the use of a native AI parsing engine, primarily operating off the `@google/genai` Vision APIs.

## 1. Abstract Application
Users routinely receive PDF invoices, screenshots of payment portals, or scanned documents containing tiny, complex, or otherwise tedious hyperlink strings intended for payment routing. Instead of manual transcription, the user provides the document directly to the agent.

## 2. Technical Pipeline Implementation

### A. Frontend Hook (Drag and Drop Zone)
*   **Component:** An integrated file uploader/dropzone placed prominently within the `ProcessPage.tsx` or Dashboard.
*   **Supported MIME Types:** `.pdf`, `.png`, `.jpeg`, `.jpg`.
*   **Processing:** The client intercepts the file, checks limits, converts it to an array buffer or `base64` natively, and transmits it via POST to the backend API.

### B. Backend API Route Integration (`/api/parse-receipt`)
*   **Engine:** The backend initializes the Gemini AI client (`@google/genai`).
*   **Multimodal Prompting System Instruction:** 
    *"You are a strict URI extraction parser operating as an automated pipeline worker. Your sole purpose is to locate and extract the root payment URI or hyperlink contained visually or contextually within this provided invoice document. You must not provide context, do not explain your reasoning, and do not format your response with markdown code blocks. Output ONLY the absolute, fully formed URL path. If absolutely none exists, output exactly the string 'NULL'."*
*   **Parsing Logic:** The image/binary is piped to `gemini-3.1-pro-preview` or equivalent vision-capable models alongside the system prompt.

### C. Execution Handoff
*   **Validation:** The returned text payload is caught, trimmed, and run through a standard HTTP URL validation regex regex.
*   **Hydration:** If verified as a URL scheme, the backend immediately forces the URL into the "Processing Payments" state, effectively triggering the `Gateways_Registry` heuristic lookup and bypassing manual input entirely.
