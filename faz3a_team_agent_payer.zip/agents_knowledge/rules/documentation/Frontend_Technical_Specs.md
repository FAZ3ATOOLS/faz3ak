---
trigger: always_on
glob: "**/*"
description: Frontend
---
• Framework: Next.js 14 (App Router) + TypeScript
• Design: Tailwind CSS + Shadcn/ui
• Animation: Framer Motion
• Charts: Recharts (for statistics)
• Languages: RTL (Arabic) + LTR (English)
• Mode: Dark/Light Mode
• Sizes and Devices: Dynamic display suitable for all different device sizes, iPad, tablet, or Computer
• Security: The activation code in the interface allows the use of the proxy. The code is Aamm0909@

Required Pages:

1. Landing Page: Agent explanation + how it works + features

2. Dashboard:

- Statistics: Total payments, amounts, success rate, pending, and failed transactions

- Smart "Send New Payment Link" button

- Real-time transaction list: Displays the transaction, its lifecycle, and execution accurately without any spoofing

- History of completed, pending, and failed transactions

3. Payment Link Submission Page:

- Link input field

- Instant preview of the link after analysis, displaying the transaction, its lifecycle, and execution accurately without any spoofing

- Amount confirmation and details

4. Transaction Details Page:

- Progress bar: Displays the payment status, transaction, its lifecycle, and execution accurately without any spoofing

- Chat Interface with Agent

- Secure payment data entry form: Link it to the settings and ensure the session is saved

- Displays the actual transaction result

5. Settings Page:

- Link saved payment cards Up to 1000 cards

- Link routing number - account number for ACH payments

- Create a USDT TRC20 wallet, a BSC network wallet, and view wallet balances for TRON and BSC agents, along with the password. Real-time and address display for receiving payments.

- Notification settings


🎨 Design Required:

───────────────────────────────────────
• Theme: "FAZ3A TEAM AGENT PAYER"
• Colors:

- Charcoal Black (#0A0A0F)

- Neon Green (#00FF88) — For Success

- Electric Blue (#0088FF) — For Confidence

- Gold (#FFD700) — For Distinction
• Fonts: Cairo (Arabic) + Inter (English)
• Effects: Glassmorphism, Neon Glow, Particles Background
• Icons: Lucide React