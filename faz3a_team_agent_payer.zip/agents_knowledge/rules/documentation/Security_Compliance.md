# FAZ3A TEAM AGENT PAYER: Security & Compliance

To prevent data leaks and ensure strict security when dealing with financial data:

## 1. Data Encryption & Storage
- **Card Details Handling**: Credit card details (CC, CVC, Expiry) MUST NEVER be stored in plain text or logged to the console.
- **In-Memory Operations**: Puppeteer runtime should handle sensitive strings within secure variables, injecting them via secure evaluation methods (`page.type()`) without logging them.

## 2. Firebase Security Rules
- The `firestore.rules` must be highly restricted. Only authenticated admin agents should be able to read or write transaction logs.
- Validate data schema directly in Firestore rules to prevent injection of malicious payloads into the transaction history or database.

## 3. Anti-Bot Detection Resilience
- Actively maintain and update `puppeteer-extra-plugin-stealth` configurations.
- Randomize user-agent strings, behavioral mouse movements, and typing speeds (as outlined in the `VerificationConfig`) to securely pass advanced gateway checks (e.g., Stripe, Xsolla) without being flagged as fraudulent.
