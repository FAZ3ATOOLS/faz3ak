---
trigger: always_on
glob: "**/*"
description: Agent Payer Workflow Process Lifecycle 
---

[User] ──► [Send Payment Link]
                  │
                  ▼
[Agent] ◄──── [Automatically Capture Link]
                  │
                  ▼
[Ongoing Transactions List] ──► Status: "Under Analysis"
                  │
                  ▼
[Fetch/Scrape Page] Extract:
    • Seller/Store Name
    • Amount Due
    • Currency
    • Product/Description
    • Payment Gateway Type (QUICKBOOKS, Stripe, PayPal Checkout, Razorpay, Coinbase Commerce, NowPayments, Anedot, BasisTheory (API), BasisTheory (JS), Blackbaud, Cellpointdigital, CodaPayments, CtCt, Cybersource (flex v2), Finby, GetOpenPay, NMI, NeonOnePay, OnerWay, Oppwa, PayCom, PayPal ACDC, PayPlus, PaymentsAI, PipoPayment (Cashier), Safecharge, Saferpay, SecurionPay, Shift4, SumUp, Tebex, TrainPal, VeryGoodProxy, VivaPayments, Wix, Zuora) Adyen Airwallex , Nord Payments , Paddle , Patreon , Pay360 , PayStack , Payzen , Playstation , Primer , Processout , Recurly , Recurly (EU) , RizzUp , Sagepay , Secure Pay , Spreedly , Square , Steam , Stripe (Billing) , Worldpay (Access) , Worldpay (Payments) , Xendit , Xsolla, crypto wallet...) 
    • Any other information
                  │
                  ▼
[Smart Verification] ──► Verifies:
    • Link validity
    • Amount matches context
    • No duplicate transaction
    • Fraud risk assessment (Risk Score) and makes it safe if high
    • CVC Modifier: Generate , remove , bypass
    • Remove Payment Agent (Stripe)
    • 3D Bypass (Stripe & Xsolla)
    • Remove Zip Code
    • Block analytics
    • Hit Sound
    • Hit Screenshot
    • Cancel 3D Popup
    • Click on Load
    • Click on Load Delay (ms): 2000
    • Clicker Path
    • Clicker Interval (ms): 5000
    • Ignore Disabled
    • Enable Notification
    • Dismiss After (ms): 2000
    • Proxy interval (mins): 0.5
    • Enable Autofill
    • Delay (ms): 5000
    • Timeout (ms): 5000
    • Enable Interval
    • Interval (ms): 5000
                  │
                  ▼
[Requesting Payment Information from User] ──► Depending on the Gateway Type:
    ► all Payment method on request thin print The input failed on popup tab "can save this method on settengs to another time"

    ► Crypto-wallet: The agent creates a wallet and sends a private key to the user. The user deposits funds into the wallet, and the agent displays the transaction details with the wallet address and confirms the signature in the backend without needing to contact the user.

                  │
                  ▼
[Executing Payment] ──► Via:

    • Because it is a "smart payment agent," it doesn't use an API but utilizes all available capabilities without requiring anything from the user to access the payment link.                  │
    • the process will pooling to get payment link paid "If the user has selected a specific payment method and has added more than one account or card to that payment method, the system will attempt smart payment strategies until the payment is successful."
                  │
                  ▼
[Capturing Proof] ──►:
    • Screenshot of the successful payment page
    • Payment confirmation link (Confirmation URL)
    • Transaction ID
    • Invoice/Receipt PDF (if available)
    • Full Transaction Details
                  │
                  ▼
[User Notification] ──► Via:

    • In-App Notification (WebSocket) after get real paid send Notification.
                  │
                  ▼
[Status Update] ──► Result of Payment link :

    • "Completed, declined , error , that same error on payment link page will fetich" + 
    • Archived in Log