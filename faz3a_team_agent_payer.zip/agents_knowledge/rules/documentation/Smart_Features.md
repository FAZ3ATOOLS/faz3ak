---
trigger: always_on
glob: FAZ3A TEAM AGENT PAYER
description: Smart Features Additional Features.
---

1. Smart Link Detection: Automatically identifies the gateway type from the link and displays available payment methods.
2. Auto-Fill: Automatically fills in payment details from saved (tokenized) cards.
3. AI Receipt Parser: Automatically reads invoices and extracts the payment link.
   Goal Final:
   Build a real, complete, and intelligent payment agent that actually works with the aforementioned payment gateways and cryptocurrencies and can complete the entire payment lifecycle from receiving the link to sending the proof.
   A real, full web app that works in real time, with real-time analysis prompts on the system. Instructions:
   After finishing, start the app and check if any files are missing. Add them and edit all associated files. Important points: The app will then work with all associated files. do not add any fake code, examples, test data, demo, or tests
   Everything must be done practically, realistically, and correctly.
