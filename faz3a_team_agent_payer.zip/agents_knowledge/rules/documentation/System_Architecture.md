# FAZ3A TEAM AGENT PAYER: System Architecture

This document defines the underlying architecture, execution strategies, and supported gateway configurations for the "FAZ3A TEAM AGENT PAYER" application.

## 1. Core Architecture Stack

- **Frontend:** Next.js 14 (App Router) + TypeScript, built with Tailwind CSS & Shadcn/ui.
- **Backend Service:** Node.js Express server (`server.ts`) executed via `tsx` or bundled via `esbuild`.
- **Database & Persistence:** Cloud Firestore via Firebase Admin SDK. All transactions, saved payment methods, and user configurations must be durably stored. In-memory data arrays are strictly forbidden for production states.
- **Automation Engine:** Puppeteer alongside `puppeteer-extra-plugin-stealth` to execute secure headless browser interactions.
- **Blockchain Automation:** `ethers.js` handles real-time cryptographic wallet generation and transaction verifications.
- **AI Processing:** Google `@google/genai` SDK is utilized for tasks like the "AI Receipt Parser" (extracting payment links from uploaded invoices).

## 2. Automated Agent Strategies

The FAZ3A Agent leverages dynamic headless browser maneuvering to fulfill transactions securely without alerting anti-bot security systems.

### 2.1 The Strategy Pattern (Code Structure)
- **GenericStrategy:** Uses semantic heuristics to find inputs (e.g., scanning the DOM for `input` fields containing 'card', 'cvc', 'billing' in attributes).
- **StripeStrategy:** Interacts explicitly with Stripe JS components, targeting embedded iframes specifically used by Stripe v3.
- **PayPalStrategy:** Automates standard PayPal single-click buttons and securely navigates the resulting popup/iframe flows.
- **Pooling Strategy:** When users provide a configured payment method containing multiple saved cards/accounts, the agent iterates through them sequentially if declines occur, retrying intelligently.

### 2.2 Stealth & Smart Verification Controls
These controls are set in the UI and alter the backend Puppeteer execution matrix:
- **CVC Modifiers:** `None` (bypass), `Generate` (random string), `Remove` (DOM deletion), `Bypass` (script injection).
- **Remove Payment Agent:** Explicitly targets Stripe verification agents to neutralize them contextually.
- **3D Secure Bypass:** Intercepts 2FA SMS overlays on Stripe and Xsolla.
- **Address & Tracking Evasion:** Drops ZIP code requirements (`Remove Zip Code`) and suppresses trackers (`Block Analytics` targeting `ga`, `fbq`).
- **Interaction Frequencies:** Employs features like `Click on Load`, `Clicker Path`, `Clicker Interval`, and `Delay` to mimic human interaction and allow gateway scripts ample initialization time.
- **Network Evasion:** Rotates residential proxies on an interval (`Proxy Interval`) to mask the crawler's datacenter footprint.

## 3. Supported Payment Gateways

The agent is designed to interact natively with over 60+ payment gateways via its headless Chromium interface.

### Tier 1: Fully Supported
- Stripe (Billing and standard Checkout)
- PayPal Checkout
- Xsolla
- Coinbase Commerce
- Razorpay

### Tier 2: Documented and Targetable
- QUICKBOOKS, NowPayments, Anedot, BasisTheory (API & JS)
- Blackbaud, Cellpointdigital, CodaPayments, CtCt
- Cybersource (flex v2), Finby, GetOpenPay, NMI, NeonOnePay
- OnerWay, Oppwa, PayCom, PayPal ACDC, PayPlus, PaymentsAI
- PipoPayment (Cashier), Safecharge, Saferpay, SecurionPay
- Shift4, SumUp, Tebex, TrainPal, VeryGoodProxy, VivaPayments
- Wix, Zuora, Adyen, Airwallex, Antom, Authorize, Bluesnap
- Braintree, Checkout.com, Computop, EGenius, Endurance, Fansly
- Grammarly, Marketpay, Mercadopago, MoneyMotion, NCR Secure Pay
- Nord Payments, Paddle, Patreon, Pay360, PayStack, Payzen, Playstation
- Primer, Processout, Recurly, RizzUp, Sagepay, Secure Pay, Spreedly, Square, Steam, Worldpay, Xendit, and general Crypto Wallets.

## 4. Automation Protocol & Execution Container
1. **Detect Framework:** Matches gateway patterns against known URL/DOM signatures.
2. **Contextual Scrape:** Extracts actionable input vectors.
3. **Payload Execution:** Maps extracted DOM selectors to the user's provided secure vault credentials, circumventing tracking blocks.
4. **Environment Isolation:** Puppeteer explicit cleanup. `browser.close()` must be enforced in `finally` blocks to guarantee no zombie Chromium processes remain on the host environment (Docker/Linux deployment), preventing memory leaks.

---

## 5. [FRAMEWORK] Implementation Gap & Conflict Resolution
*This framework strictly tracks where the current application codebase (`server.ts`, `src/*`) fails to meet the documented advanced objectives, relying instead on dummy executions or incomplete logic.*

### Architectural Conflicts to Resolve:
- **[DUMMY EXECUTION] Firebase Persistence:** The codebase currently uses a volatile, in-memory array (`const db = { transactions: [], savedCards: [] }`) instead of the mandated Cloud Firestore bindings. **Resolution:** Implement `@google/cloud-firestore` and eradicate all in-memory arrays.
- **[DUMMY EXECUTION] Automation Engine Stealth:** The `server.ts` file initiates basic headless Chromium (`puppeteer.launch()`), completely ignoring the required `puppeteer-extra-plugin-stealth`. **Resolution:** Overhaul the launcher to use `puppeteer-extra` to prevent instant bot detection.
- **[MISSING TASK] AI Processing (Receipt Parser):** The application relies on standard `fetch()` API calls to text-parse URLs, failing on SPAs. The `@google/genai` vision pipeline (`/api/parse-receipt`) is entirely unwritten. **Resolution:** Build the Gemini document parser and integrate a UI dropzone.
