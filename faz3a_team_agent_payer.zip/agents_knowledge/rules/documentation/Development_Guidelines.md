# FAZ3A TEAM AGENT PAYER: Development Rules

The core directive for developing this application revolves around absolute authenticity and production readiness. 

## 1. Zero Artificial Simulation Rule
- **No Mock Execution**: Code must actually execute what it claims. Endpoints like `execute-payment` must NEVER utilize chained `setTimeout()` simulated delays resolving to a static successful JSON object.
- **No Hardcoded Crypto Keys**: Displaying default mock wallet addresses to the user is forbidden. Wallet generation must use actual libraries (e.g., `ethers.js`) mapped to real keypairs securely processed server-side.
- **No Fake API Returns**: Error text, success states, and transactional metadata must accurately reflect the payload string parsed directly from the headless browser's interaction with the live network/payment gateway.

## 2. Mandatory Persistent Database
- **No In-Memory Defaults**: The backend must never utilize an unreliable in-memory data store array (e.g., `let db = { transactions: [] }`) for major architecture state.
- **Firebase Mandate**: All transactions, user-settings configurations, and saved tokenized cards must reliably sink into Google Cloud Firestore. The `firebase-integration` tool must be leveraged to create proper schemas via `firebase-blueprint.json` and strict read/write security rules.

## 3. Strict State Propagation
- Transactions must visibly transition through the state models provided by the backend.
- The WebSocket and SSE connection pipelines must supply granular "agent action" messages to inform the user interface.
- Frontend React composite keys must be handled gracefully to prevent component remount tearing, especially within chat logs matching `TransactionStage`.

## 4. UI/UX Paradigm
- The system incorporates high-contrast visual choices relying on `Tailwind CSS`, specifically incorporating `neon-glow-accent` elements and `Glassmorphism`.
- All text must support bidirectional translation. Hardcoded Strings within the user interface are bugs. Integration of `i18next` utilizing `/locales/en.json` and `/locales/ar.json` is non-negotiable.

## 5. Security & Isolation
- The App requires a specific activation passphrase `Aamm0909@` entered via Settings to unlock internal proxy and verification controls to prevent unauthorized misuse.
- Headless Chromium sessions can leak significant container memory. `browser.close()` must be consistently trapped within `finally` blocks in standard error handling workflows to avoid resource starvation in cloud environments.
