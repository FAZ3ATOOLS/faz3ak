# FAZ3A TEAM AGENT PAYER: Product Requirements Document

This document outlines the workflow, concepts, and features that make up the AI-powered payment automation engine.

## 1. Executive Summary
FAZ3A TEAM AGENT PAYER acts as an intelligent proxy, accepting payment links from users and autonomously executing the checkout process using headless browser automation (Puppeteer). The system simulates human behavior to successfully bypass anti-bot security measures across over 60+ payment gateways.

## 2. The Agent Payer Workflow Process

### Step 1: User Submission
- **Link Capture**: The user pastes a payment link. The Agent captures the link and immediately assigns it to the "Ongoing Transactions" list with the status: "Under Analysis".
- **AI Receipt Parser (Alternative)**: Users upload an invoice (Image/PDF). The AI SDK automatically reads it, extracts the payment portal link from the document, and proceeds to the next step.

### Step 2: Fetch & Scrape
- The Agent navigates to the URL in the background. It extracts:
  1. Seller/Store Name
  2. Amount Due & Currency
  3. Product/Description
  4. Payment Gateway Type (Identified through DOM footprint)
  5. Available Payment Methods (e.g., Credit Card, PayPal, Crypto Wallets, ACH)

### Step 3: Smart Verification & User Provisioning
- **Smart Configurations**: The UI presents the "Smart Verification Panel" for the user to tune the Puppeteer execution environment (see section 3).
- **Payment Method Prompt**: A floating popup tab appears displaying the exact payment methods the scraper found available on the payment page.
- **Data Input**: The user inputs details or selects a tokenized, saved payment method from their "Vault". For crypto payments, the backend utilizes `ethers` to generate a real address matching the token standard, receiving deposits, and signing the transaction automatically.
- **Save to Vault**: Any newly entered payment method can be saved to the Vault via settings for future auto-fill.

### Step 4: Automated Execution
- **Headless Actions**: Puppeteer loads the payment gateway, fills the forms via injected keyboard events, clicks submit buttons, and handles standard interaction paths.
- **Error/Feedback Loop**: If card data is declined, the agent captures the exact error string published by the gateway and bubbles it up to the frontend UI precisely.
- **Card Pooling**: If a user selects a vault grouping, the agent loops until a card succeeds or the pool is exhausted.

### Step 5: Proof Capture & Status Resolution
- **Capture**: The Agent grabs a full-page screenshot of the success screen, confirmation URL, Transaction ID, and any downloadable receipt (PDF).
- **Notifications**: Real-time WebSocket events trigger notifications on the frontend.
- **Final Status**: The transaction is irreversibly marked as `Completed`, `Declined`, or `Error`.

## 3. Configuration: Smart Verification Controls
The user has explicit granular control over the agent's behavior via these panel settings:
- **CVC Modifier**: Options to `Generate` (fake it), `Remove` (delete DOM element), `Bypass` (script injection), or `None`.
- **Remove Payment Agent**: Specific scripts to neutralize Stripe checkout agents.
- **3D Bypass**: Scripts targeting Stripe & Xsolla 2FA SMS overlays.
- **Remove Zip Code**: Drops address requirement attributes.
- **Cancel 3D Popup**: Force closes iframe overlays related to Verified-by-Visa / SecureCode.
- **Block Analytics**: Suppresses `ga`, `fbq`, and trackers.
- **Clicker Configuration**: Explicit configuration via `Click on Load`, `Click on Load Delay (ms)`, `Clicker Path`, and `Clicker Interval (ms)`.
- **Interaction Frequencies**: `Delay (ms)`, `Timeout (ms)`, `Enable Interval`, and `Interval (ms)`.
- **Ignore Disabled**: Skips injection on `disabled` form fields.
- **Enable Autofill**: Triggers ultra-fast keyboard injection scripts.
- **Proxy Interval**: Rotates the residential proxy IP every X minutes.
- **Hit Feedback**: `Hit Sound`, `Hit Screenshot`, and `Enable Notification` controls.

## 4. Required UI Pages
1. **Landing Page**: Promotional hero with a particle background.
2. **Dashboard**: Statistical tracking (success rates via Recharts), active transaction feed.
3. **Process/Submission Page**: The heart of the application rendering the Link Input, Scrape Results, Smart Verification Panel, and the Floating Payment Method Popup.
4. **Transaction Details**: A dedicated progress view. Displays the full lifecycle timeline, SSE streaming text detailing the agent's inner actions, captured screenshots, and real error results.
5. **Settings (Vault)**: A secure management console. Features an activation code lock (`Aamm0909@`) to uncover configurations, manages up to 1000 Tokenized Cards, ACH banks, Crypto Wallets, and Global settings. Supports full `i18n` toggling for English (LTR) and Arabic (RTL).
