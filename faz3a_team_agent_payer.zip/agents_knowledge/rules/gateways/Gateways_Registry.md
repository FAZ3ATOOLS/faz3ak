# Gateways Registry & Integration Context

To move away from crude, standardized DOM scraping that fails across varied architectures, the FAZ3A system relies on identifying the underlying Gateway from the raw URI or initial domain redirect, mapping the execution to a specific, hardened module structure.

## 1. Supported Core Gateways
The system explicitly targets and structures its execution vectors against over 60 specific gateways, including but not limited to:

1.  **Primary Leaders:** Stripe (Checkout & Billing), PayPal (Checkout & ACDC), Adyen, Square, Braintree.
2.  **Gaming & SaaS:** Xsolla, Tebex, Steam, Playstation, Patreon, Wix.
3.  **Enterprise & Invoicing:** QUICKBOOKS, Blackbaud, Zuora, Checkout.com (Invoice & Devices API).
4.  **Regional & Specialized Processors:**
    - Anedot, BasisTheory (API/JS), Cellpointdigital, CodaPayments, CtCt, Cybersource (flex v2).
    - Finby, GetOpenPay, NMI, NeonOnePay, OnerWay, Oppwa, PayCom, PayPlus, PaymentsAI.
    - PipoPayment, Safecharge, Saferpay, SecurionPay, Shift4, SumUp, TrainPal.
    - VeryGoodProxy, VivaPayments, Airwallex, Antom, Authorize, Bluesnap, Computop.
    - EGenius, Endurance, Fansly, Grammarly, Marketpay, MoneyMotion, NCR Secure Pay.
    - Nord Payments, Paddle, Pay360, PayStack, Payzen, Primer, Processout, Recurly.
    - RizzUp, Sagepay, Secure Pay, Spreedly, Worldpay (Access/Payments), Xendit.
5.  **Digital Assets:** Crypto Wallets (Coinbase Commerce, NowPayments, native routing).

## 2. Integration Principle & Architecture
Whenever a link is submitted, the Puppeteer environment identifies the top-level window layout or endpoint domain. This triggers a specific profile mapping to ensure selectors always match precisely and iframe depth is handled natively.

*Architectural Mapping Strategy Example:*
```typescript
interface GatewayProfile {
  name: string;
  domainMatch: RegExp;
  amountSelector: string;
  cardRouting: {
    iframeDepth?: string; // Target specific iframes if necessary
    cardNumberInput: string;
    expiryInput: string;
    cvcInput: string;
  };
  stealthRequired: boolean;
  telemetryDomains: string[]; // Domains to block via request interception
  submitAction: string;       // Selector for final execution
}

const GatewayRegistry: GatewayProfile[] = [
  {
     name: "Stripe Checkout",
     domainMatch: /checkout\.stripe\.com/i,
     amountSelector: ".SubmitButton-IconContainer + span",
     cardRouting: {
        cardNumberInput: "input[name='cardnumber']",
        expiryInput: "input[name='exp-date']",
        cvcInput: "input[name='cvc']"
     },
     stealthRequired: true,
     telemetryDomains: ["m.stripe.com", "b.stripe.com"],
     submitAction: "button.SubmitButton"
  },
  {
     name: "PayPal Checkout",
     domainMatch: /paypal\.com\/checkout/i,
     amountSelector: "div[data-testid='cart-total']",
     cardRouting: {
        cardNumberInput: "input[id='cardNumber']",
        expiryInput: "input[id='cardExpiry']",
        cvcInput: "input[id='cardCvv']"
     },
     stealthRequired: true,
     telemetryDomains: ["c.paypal.com", "t.paypal.com"],
     submitAction: "button#submitBtn"
  }
  // ... maps to cover all 60+ gateways dynamically
];
```

By enforcing a Gateway Registry architecture, the automation core inherently averts runtime failures such as "No card input found" or being stuck on unexpected multi-stage forms.

---

## 3. [FRAMEWORK] Implementation Gap & Conflict Resolution
*This framework strictly tracks where the current application codebase (`server.ts`, `src/*`) fails to meet the documented Gateway Registry objectives, relying instead on dummy executions or incomplete logic.*

### Gateway Execution Conflicts to Resolve:
- **[DUMMY EXECUTION] Crude Generic Scraping:** The `server.ts` file completely ignores the dynamic `GatewayProfile` architecture. Instead, it attempts a brittle "spray-and-pray" approach using static arrays (e.g., `cardSelectors = ['input[name="cardNumber"]', ...]`). **Resolution:** Delete the generic arrays and implement a strict Gateway routing module that matches the domain before injecting credentials.
- **[DUMMY EXECUTION] Contextless Execution:** The application launches a fresh browser for every single transaction loop iteration rather than gracefully handling iframe depth or DOM resets within a targeted gateway session. **Resolution:** Introduce targeted frame-depth parsing as outlined in `cardRouting.iframeDepth`.
- **[MISSING TASK] Telemetry Domain Blocking:** The system does not intercept or block the `telemetryDomains` listed in the profiles, rendering the stealth requirements moot. **Resolution:** Implement `page.on('request')` to abort network calls matching the registry's blocklist.
