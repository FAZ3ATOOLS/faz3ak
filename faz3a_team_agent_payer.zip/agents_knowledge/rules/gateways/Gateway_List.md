# Supported Gateways and Agent Interaction

## Target Payment Gateways
The agent is designed to interact natively with over 50+ payment gateways. Interaction is performed via headless Chromium rather than REST APIs to maintain the original user-link parameters and cookies.

### Tier 1: Fully Supported
- QUICKBOOKS
- Stripe
- PayPal Checkout
- Razorpay
- Coinbase Commerce
- NowPayments
- Anedot
- BasisTheory (API)
- BasisTheory (JS)
- Blackbaud
- Cellpointdigital
- CodaPayments
- CtCt
- Cybersource (flex v2)
- Finby
- GetOpenPay
- NMI
- NeonOnePay
- OnerWay
- Oppwa
- PayCom
- PayPal ACDC
- PayPlus
- PaymentsAI
- PipoPayment (Cashier)
- Safecharge
- Saferpay
- SecurionPay
- Shift4
- SumUp
- Tebex
- TrainPal
- VeryGoodProxy
- VivaPayments
- Wix
- Zuora
- Adyen
- Airwallex
- Nord Payments
- Paddle
- Patreon
- Pay360
- PayStack
- Payzen
- Playstation
- Primer
- Processout
- Recurly
- Recurly (EU)
- RizzUp
- Sagepay
- Secure Pay
- Spreedly
- Square
- Steam
- Stripe (Billing)
- Worldpay (Access)
- Worldpay (Payments)
- Xendit
- Xsolla
- Crypto Wallets

### Tier 2: Documented and Targetable (DOM Selectors Needed)
- QUICKBOOKS, NowPayments, Anedot, BasisTheory (API & JS)
- Blackbaud, Cellpointdigital, CodaPayments, CtCt
- Cybersource (flex v2), Finby, GetOpenPay, NMI, NeonOnePay
- OnerWay, Oppwa, PayCom, PayPal ACDC, PayPlus, PaymentsAI
- PipoPayment (Cashier), Safecharge, Saferpay, SecurionPay
- Shift4, SumUp, Tebex, TrainPal, VeryGoodProxy, VivaPayments
- Wix, Zuora, Adyen, Airwallex, Antom, Authorize, Bluesnap
- Braintree, Checkout.com, Computop, EGenius, Endurance, Fansly
- Grammarly, Marketpay, Mercadopago, MoneyMotion, NCR Secure Pay
- Nord Payments, Paddle, Patreon, Pay360, PayStack, Payzen, Playstation
- Primer, Processout, Recurly, RizzUp, Sagepay, Secure Pay, Spreedly, Square, Steam, Worldpay, Xendit.

## Action Protocol
1. **Detect**: Compare domain/URL patterns to known gateway lists.
2. **Scrape**: Identify input fields (`input[name="ccnumber"]`, `iframe` segments, etc.).
3. **Execute**: Map user payment details to the gateway's layout, circumventing blocks.
