import { useMemo, useCallback } from 'react';
import { useAppContext } from '../context/AppContext';

export function useNotifications() {
  const { state, dispatch, markNotificationRead } = useAppContext();

  const unreadCount = useMemo(
    () => state.notifications.filter((n) => !n.read).length,
    [state.notifications]
  );

  const markRead = useCallback(
    (id: string) => {
      markNotificationRead(id);
    },
    [markNotificationRead]
  );

  const clearAll = useCallback(() => {
    dispatch({ type: 'CLEAR_NOTIFICATIONS' });
  }, [dispatch]);

  return {
    notifications: state.notifications,
    unreadCount,
    markRead,
    clearAll,
  };
}
