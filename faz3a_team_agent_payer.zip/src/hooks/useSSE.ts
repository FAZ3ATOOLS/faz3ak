import { useEffect, useState, useRef } from 'react';
import { useAppContext } from '../context/AppContext';
import type { Transaction } from '../types';

export function useSSE() {
  const { dispatch } = useAppContext();
  const [backendStage, setBackendStage] = useState<string>('');
  const [isConnected, setIsConnected] = useState(false);
  const eventSourceRef = useRef<EventSource | null>(null);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    function connect() {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }

      const es = new EventSource('/api/stream');
      eventSourceRef.current = es;

      es.onopen = () => {
        setIsConnected(true);
      };

      es.addEventListener('init', (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.transactions && Array.isArray(data.transactions)) {
            dispatch({ type: 'SET_TRANSACTIONS', payload: data.transactions as Transaction[] });
          }
        } catch {
          /* invalid data */
        }
      });

      es.addEventListener('payment_update', (event) => {
        try {
          const tx = JSON.parse(event.data) as Transaction;
          dispatch({ type: 'UPDATE_TRANSACTION', payload: tx });
        } catch {
          /* invalid data */
        }
      });

      es.addEventListener('payment_stage', (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.stage) {
            setBackendStage(data.stage);
          }
          if (data.id) {
            dispatch({
              type: 'UPDATE_TRANSACTION',
              payload: {
                id: data.id,
                stages: [
                  ...(data.stages || []),
                  {
                    name: data.stage,
                    status: 'active' as const,
                    timestamp: new Date().toISOString(),
                    message: data.stage,
                  },
                ],
              } as Transaction,
            });
          }
        } catch {
          /* invalid data */
        }
      });

      es.onerror = () => {
        setIsConnected(false);
        es.close();
        eventSourceRef.current = null;
        reconnectTimer.current = setTimeout(connect, 3000);
      };
    }

    connect();

    return () => {
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      eventSourceRef.current?.close();
    };
  }, [dispatch]);

  return { backendStage, isConnected, setBackendStage };
}
