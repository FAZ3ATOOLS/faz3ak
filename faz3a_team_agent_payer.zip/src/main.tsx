import { createRoot } from 'react-dom/client';
import './i18n';
import { AppProvider } from './context/AppContext';
import { WebSocketProvider } from './context/WebSocketContext';
import App from './App';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <AppProvider>
    <WebSocketProvider>
      <App />
    </WebSocketProvider>
  </AppProvider>,
);
