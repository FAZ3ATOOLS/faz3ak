import { createContext, useContext, useEffect, useRef, useState, useCallback, type ReactNode } from 'react';
import { useAppContext } from './AppContext';
import { toast } from 'sonner';

interface WebSocketContextType {
  isConnected: boolean;
  sendMessage: (data: Record<string, unknown>) => void;
}

const WebSocketContext = createContext<WebSocketContextType>({
  isConnected: false,
  sendMessage: () => {},
});

// Dynamic WS URL: use current host with the same port, 
// but allow override via env or meta tag for proxy setups
function getWSUrl(): string {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  let host = window.location.host;
  // If running locally on port 5173 but backend is on 3000, redirect to 3000
  if (window.location.port === '5173') {
    host = window.location.hostname + ':3000';
  }
  return `${protocol}//${host}/ws`;
}

const MAX_RECONNECT_DELAY = 30000;
const INITIAL_RECONNECT_DELAY = 2000;

export function WebSocketProvider({ children }: { children: ReactNode }) {
  const { dispatch, addNotification } = useAppContext();
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectDelay = useRef(INITIAL_RECONNECT_DELAY);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const connectAttempt = useRef(0);
  const isMounted = useRef(true);

  const playBeep = useCallback(() => {
    try {
      const audioCtx = new AudioContext();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime);
      gainNode.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.5);
      oscillator.start(audioCtx.currentTime);
      oscillator.stop(audioCtx.currentTime + 0.5);
    } catch {
      /* audio not available */
    }
  }, []);

  const connect = useCallback(() => {
    if (!isMounted.current) return;
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    // Clean up any existing connection first
    if (wsRef.current) {
      try {
        wsRef.current.onclose = null;
        wsRef.current.onerror = null;
        wsRef.current.close();
      } catch {
        // ignore cleanup errors
      }
      wsRef.current = null;
    }

    try {
      connectAttempt.current += 1;
      const wsUrl = getWSUrl();
      const ws = new WebSocket(wsUrl);

      // Connection timeout: if not opened within 10s, force close and retry
      const connectionTimeout = setTimeout(() => {
        if (ws.readyState !== WebSocket.OPEN) {
          try {
            ws.close();
          } catch {
            // ignore
          }
          // Trigger reconnect via onclose
        }
      }, 10000);

      ws.onopen = () => {
        clearTimeout(connectionTimeout);
        if (!isMounted.current) {
          try { ws.close(); } catch { /* */ }
          return;
        }
        setIsConnected(true);
        reconnectDelay.current = INITIAL_RECONNECT_DELAY;
        connectAttempt.current = 0;
      };

      ws.onmessage = (event) => {
        try {
          const parsed = JSON.parse(event.data);
          const { event: eventType, data } = parsed;

          switch (eventType) {
            case 'init':
              if (data.transactions && Array.isArray(data.transactions)) {
                dispatch({ type: 'SET_TRANSACTIONS', payload: data.transactions });
              }
              break;

            case 'payment_complete':
              dispatch({ type: 'UPDATE_TRANSACTION', payload: { ...data, status: 'success' } });
              addNotification({
                type: 'success',
                title: 'Payment Successful',
                message: `Payment of ${data.amount} ${data.currency} to ${data.vendor} completed.`,
                transactionId: data.id,
              });
              playBeep();
              toast.success(`Payment to ${data.vendor} completed successfully!`);
              break;

            case 'payment_declined':
              dispatch({ type: 'UPDATE_TRANSACTION', payload: { ...data, status: 'declined' } });
              addNotification({
                type: 'warning',
                title: 'Payment Declined',
                message: `Payment of ${data.amount} ${data.currency} to ${data.vendor} was declined.${data.errorDetails ? ` Reason: ${data.errorDetails}` : ''}`,
                transactionId: data.id,
              });
              toast.warning(`Payment to ${data.vendor} was declined.`);
              break;

            case 'payment_error':
              dispatch({ type: 'UPDATE_TRANSACTION', payload: { ...data, status: 'error' } });
              addNotification({
                type: 'error',
                title: 'Payment Error',
                message: `An error occurred processing payment to ${data.vendor}.${data.errorDetails ? ` Details: ${data.errorDetails}` : ''}`,
                transactionId: data.id,
              });
              toast.error(`Payment error for ${data.vendor}.`);
              break;

            case 'transaction_update':
              dispatch({ type: 'UPDATE_TRANSACTION', payload: data });
              break;

            default:
              break;
          }
        } catch {
          /* Invalid JSON */
        }
      };

      ws.onclose = (event) => {
        clearTimeout(connectionTimeout);
        if (!isMounted.current) return;
        setIsConnected(false);
        wsRef.current = null;
        const delay = Math.min(reconnectDelay.current, MAX_RECONNECT_DELAY);
        reconnectTimer.current = setTimeout(() => {
          reconnectDelay.current = Math.min(reconnectDelay.current * 2, MAX_RECONNECT_DELAY);
          connect();
        }, delay);
      };

      ws.onerror = (error) => {
        // Don't close here — let onclose handle reconnection
        // ws.close() is called automatically after onerror
      };

      wsRef.current = ws;
    } catch {
      /* connection failed, retry via timer */
      if (isMounted.current) {
        const delay = Math.min(reconnectDelay.current, MAX_RECONNECT_DELAY);
        reconnectTimer.current = setTimeout(() => {
          reconnectDelay.current = Math.min(reconnectDelay.current * 2, MAX_RECONNECT_DELAY);
          connect();
        }, delay);
      }
    }
  }, [dispatch, addNotification, playBeep]);

  useEffect(() => {
    isMounted.current = true;
    // Delay initial connection to avoid race with Vite HMR websocket setup
    const initialDelay = setTimeout(() => {
      connect();
    }, 500);

    return () => {
      isMounted.current = false;
      clearTimeout(initialDelay);
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      if (wsRef.current) {
        try {
          wsRef.current.onclose = null;
          wsRef.current.close();
        } catch {
          // ignore
        }
        wsRef.current = null;
      }
    };
  }, [connect]);

  const sendMessage = useCallback((data: Record<string, unknown>) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(data));
    }
  }, []);

  return (
    <WebSocketContext.Provider value={{ isConnected, sendMessage }}>
      {children}
    </WebSocketContext.Provider>
  );
}

export function useWebSocket() {
  return useContext(WebSocketContext);
}
