import { createContext, useContext, useCallback, useReducer, type ReactNode, type Dispatch } from 'react';
import {
  type Transaction,
  type SavedCard,
  type SavedACH,
  type CryptoWallet,
  type AppNotification,
  type SmartVerificationConfig,
  type TabType,
  DEFAULT_VERIFICATION_CONFIG,
} from '../types';
import { v4 as uuidv4 } from 'uuid';

interface AppState {
  transactions: Transaction[];
  savedCards: SavedCard[];
  savedACH: SavedACH[];
  wallets: CryptoWallet[];
  notifications: AppNotification[];
  verificationConfig: SmartVerificationConfig;
  activeTab: TabType;
  selectedTransactionId: string | null;
  language: 'en' | 'ar';
  proxyActivated: boolean;
}

type AppAction =
  | { type: 'SET_TRANSACTIONS'; payload: Transaction[] }
  | { type: 'ADD_TRANSACTION'; payload: Transaction }
  | { type: 'UPDATE_TRANSACTION'; payload: Transaction }
  | { type: 'SET_SAVED_CARDS'; payload: SavedCard[] }
  | { type: 'ADD_SAVED_CARD'; payload: SavedCard }
  | { type: 'REMOVE_SAVED_CARD'; payload: string }
  | { type: 'SET_DEFAULT_CARD'; payload: string }
  | { type: 'SET_SAVED_ACH'; payload: SavedACH[] }
  | { type: 'ADD_SAVED_ACH'; payload: SavedACH }
  | { type: 'REMOVE_SAVED_ACH'; payload: string }
  | { type: 'SET_WALLETS'; payload: CryptoWallet[] }
  | { type: 'ADD_WALLET'; payload: CryptoWallet }
  | { type: 'SET_NOTIFICATIONS'; payload: AppNotification[] }
  | { type: 'ADD_NOTIFICATION'; payload: AppNotification }
  | { type: 'MARK_NOTIFICATION_READ'; payload: string }
  | { type: 'CLEAR_NOTIFICATIONS' }
  | { type: 'SET_VERIFICATION_CONFIG'; payload: SmartVerificationConfig }
  | { type: 'UPDATE_VERIFICATION_CONFIG'; payload: Partial<SmartVerificationConfig> }
  | { type: 'SET_ACTIVE_TAB'; payload: TabType }
  | { type: 'SET_SELECTED_TRANSACTION_ID'; payload: string | null }
  | { type: 'SET_LANGUAGE'; payload: 'en' | 'ar' }
  | { type: 'SET_PROXY_ACTIVATED'; payload: boolean };

const initialState: AppState = {
  transactions: [],
  savedCards: [],
  savedACH: [],
  wallets: [],
  notifications: [],
  verificationConfig: DEFAULT_VERIFICATION_CONFIG,
  activeTab: 'landing',
  selectedTransactionId: null,
  language: 'en',
  proxyActivated: false,
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_TRANSACTIONS':
      return { ...state, transactions: action.payload };
    case 'ADD_TRANSACTION':
      return { ...state, transactions: [action.payload, ...state.transactions] };
    case 'UPDATE_TRANSACTION': {
      const idx = state.transactions.findIndex((t) => t.id === action.payload.id);
      if (idx === -1) return { ...state, transactions: [action.payload, ...state.transactions] };
      const updated = [...state.transactions];
      updated[idx] = { ...updated[idx], ...action.payload };
      return { ...state, transactions: updated };
    }
    case 'SET_SAVED_CARDS':
      return { ...state, savedCards: action.payload };
    case 'ADD_SAVED_CARD':
      return { ...state, savedCards: [...state.savedCards, action.payload] };
    case 'REMOVE_SAVED_CARD':
      return { ...state, savedCards: state.savedCards.filter((c) => c.id !== action.payload) };
    case 'SET_DEFAULT_CARD':
      return {
        ...state,
        savedCards: state.savedCards.map((c) => ({
          ...c,
          isDefault: c.id === action.payload,
        })),
      };
    case 'SET_SAVED_ACH':
      return { ...state, savedACH: action.payload };
    case 'ADD_SAVED_ACH':
      return { ...state, savedACH: [...state.savedACH, action.payload] };
    case 'REMOVE_SAVED_ACH':
      return { ...state, savedACH: state.savedACH.filter((a) => a.id !== action.payload) };
    case 'SET_WALLETS':
      return { ...state, wallets: action.payload };
    case 'ADD_WALLET':
      return { ...state, wallets: [...state.wallets, action.payload] };
    case 'SET_NOTIFICATIONS':
      return { ...state, notifications: action.payload };
    case 'ADD_NOTIFICATION':
      return { ...state, notifications: [action.payload, ...state.notifications] };
    case 'MARK_NOTIFICATION_READ':
      return {
        ...state,
        notifications: state.notifications.map((n) =>
          n.id === action.payload ? { ...n, read: true } : n
        ),
      };
    case 'CLEAR_NOTIFICATIONS':
      return { ...state, notifications: [] };
    case 'SET_VERIFICATION_CONFIG':
      return { ...state, verificationConfig: action.payload };
    case 'UPDATE_VERIFICATION_CONFIG':
      return {
        ...state,
        verificationConfig: { ...state.verificationConfig, ...action.payload },
      };
    case 'SET_ACTIVE_TAB':
      return { ...state, activeTab: action.payload };
    case 'SET_SELECTED_TRANSACTION_ID':
      return { ...state, selectedTransactionId: action.payload };
    case 'SET_LANGUAGE':
      return { ...state, language: action.payload };
    case 'SET_PROXY_ACTIVATED':
      return { ...state, proxyActivated: action.payload };
    default:
      return state;
  }
}

interface AppContextType {
  state: AppState;
  dispatch: Dispatch<AppAction>;
  addNotification: (notification: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) => void;
  markNotificationRead: (id: string) => void;
  fetchSavedCards: () => Promise<void>;
  fetchWallets: () => Promise<void>;
  fetchACH: () => Promise<void>;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  const addNotification = useCallback(
    (notification: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) => {
      dispatch({
        type: 'ADD_NOTIFICATION',
        payload: {
          ...notification,
          id: uuidv4(),
          timestamp: new Date().toISOString(),
          read: false,
        },
      });
    },
    []
  );

  const markNotificationRead = useCallback((id: string) => {
    dispatch({ type: 'MARK_NOTIFICATION_READ', payload: id });
  }, []);

  const fetchSavedCards = useCallback(async () => {
    try {
      const res = await fetch('/api/saved-cards');
      if (res.ok) {
        const data = await res.json();
        dispatch({ type: 'SET_SAVED_CARDS', payload: Array.isArray(data) ? data : data.cards || [] });
      }
    } catch {
      /* Server may not have this endpoint yet */
    }
  }, []);

  const fetchWallets = useCallback(async () => {
    try {
      const res = await fetch('/api/wallets');
      if (res.ok) {
        const data = await res.json();
        dispatch({ type: 'SET_WALLETS', payload: Array.isArray(data) ? data : data.wallets || [] });
      }
    } catch {
      /* Server may not have this endpoint yet */
    }
  }, []);

  const fetchACH = useCallback(async () => {
    try {
      const res = await fetch('/api/saved-ach');
      if (res.ok) {
        const data = await res.json();
        dispatch({ type: 'SET_SAVED_ACH', payload: Array.isArray(data) ? data : data.accounts || [] });
      }
    } catch {
      /* Server may not have this endpoint yet */
    }
  }, []);

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
        addNotification,
        markNotificationRead,
        fetchSavedCards,
        fetchWallets,
        fetchACH,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppContext must be used within AppProvider');
  return ctx;
}
