import { useMemo } from 'react';
import { motion } from 'motion/react';
import {
  ArrowLeft, CheckCircle2, Loader2, AlertTriangle, XCircle,
  Bot, FileText, Link, Clock,
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { StatusBadge } from '../components/StatusBadge';

export default function TransactionDetailsPage() {
  const { state, dispatch } = useAppContext();
  const tx = useMemo(
    () => state.transactions.find((t) => t.id === state.selectedTransactionId),
    [state.transactions, state.selectedTransactionId]
  );

  if (!tx) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="p-6 lg:p-10 max-w-4xl mx-auto text-center"
      >
        <p className="text-muted-foreground">Transaction not found.</p>
        <button
          onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: 'dashboard' })}
          className="mt-4 px-6 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-all"
        >
          Back to Dashboard
        </button>
      </motion.div>
    );
  }

  const statusIcon = {
    processing: <Loader2 className="w-6 h-6 animate-spin text-secondary" />,
    success: <CheckCircle2 className="w-6 h-6 text-primary" />,
    failed: <XCircle className="w-6 h-6 text-destructive" />,
    declined: <AlertTriangle className="w-6 h-6 text-destructive" />,
    error: <AlertTriangle className="w-6 h-6 text-orange-500" />,
  };

  const lifecycleStages = tx.stages || [
    { name: 'Link Received', status: 'completed' as const, timestamp: tx.timestamp },
    { name: 'Page Fetched & Analyzed', status: 'completed' as const, timestamp: tx.timestamp },
    { name: 'Payment Method Selected', status: 'completed' as const, timestamp: tx.timestamp },
    {
      name: tx.status === 'processing' ? 'Executing Payment...' : 'Payment Executed',
      status: tx.status === 'processing' ? ('active' as const) : ('completed' as const),
      timestamp: tx.timestamp,
    },
  ];

  return (
    <motion.div
      key="transaction-details"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="p-6 lg:p-10 max-w-4xl mx-auto"
    >
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: 'dashboard' })}
          className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all"
        >
          <ArrowLeft className="w-5 h-5 text-muted-foreground" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-white">Transaction Details</h2>
          <p className="text-sm text-muted-foreground font-mono">{tx.id}</p>
        </div>
        <div className="ml-auto">
          <StatusBadge status={tx.status} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column — Lifecycle & Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Lifecycle Progress */}
          <div className="glass-panel rounded-2xl p-6 border-white/5">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <Clock className="w-5 h-5 text-secondary" />
              Lifecycle Stages
            </h3>
            <div className="space-y-4">
              {lifecycleStages.map((stage, i) => (
                <div key={`stage-desktop-${i}-${stage.timestamp}`} className="flex items-start gap-4">
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        stage.status === 'completed'
                          ? 'bg-primary/20'
                          : stage.status === 'active'
                          ? 'bg-secondary/20'
                          : stage.status === 'failed'
                          ? 'bg-destructive/20'
                          : 'bg-white/5'
                      }`}
                    >
                      {stage.status === 'completed' ? (
                        <CheckCircle2 className="w-4 h-4 text-primary" />
                      ) : stage.status === 'active' ? (
                        <Loader2 className="w-4 h-4 animate-spin text-secondary" />
                      ) : stage.status === 'failed' ? (
                        <XCircle className="w-4 h-4 text-destructive" />
                      ) : (
                        <div className="w-2 h-2 rounded-full bg-white/20" />
                      )}
                    </div>
                    {i < lifecycleStages.length - 1 && (
                      <div
                        className={`w-0.5 h-8 ${
                          stage.status === 'completed' ? 'bg-primary/30' : 'bg-white/10'
                        }`}
                      />
                    )}
                  </div>
                  <div className="flex-1 pb-2">
                    <div className="font-medium text-white">{stage.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(stage.timestamp).toLocaleString()}
                    </div>
                    {stage.message && (
                      <div className="text-sm text-muted-foreground mt-1">{stage.message}</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Payment Information */}
          <div className="glass-panel rounded-2xl p-6 border-white/5">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5 text-accent" />
              Payment Information
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 p-4 rounded-xl">
                <div className="text-xs text-muted-foreground mb-1">Vendor</div>
                <div className="font-bold text-white">{tx.vendor}</div>
              </div>
              <div className="bg-white/5 p-4 rounded-xl">
                <div className="text-xs text-muted-foreground mb-1">Amount</div>
                <div className="font-bold text-accent">
                  ${tx.amount.toFixed(2)} {tx.currency}
                </div>
              </div>
              <div className="bg-white/5 p-4 rounded-xl">
                <div className="text-xs text-muted-foreground mb-1">Gateway</div>
                <div className="font-medium text-white">{tx.gateway}</div>
              </div>
              <div className="bg-white/5 p-4 rounded-xl">
                <div className="text-xs text-muted-foreground mb-1">Payment Method</div>
                <div className="font-medium text-white capitalize">{tx.paymentMethod}</div>
              </div>
              <div className="bg-white/5 p-4 rounded-xl">
                <div className="text-xs text-muted-foreground mb-1">Risk Score</div>
                <div className="font-medium text-primary">{tx.riskScore}</div>
              </div>
              <div className="bg-white/5 p-4 rounded-xl">
                <div className="text-xs text-muted-foreground mb-1">Timestamp</div>
                <div className="font-medium text-white text-sm">
                  {new Date(tx.timestamp).toLocaleString()}
                </div>
              </div>
            </div>
          </div>

          {/* Error Details */}
          {(tx.status === 'failed' || tx.status === 'declined' || tx.status === 'error') && tx.errorDetails && (
            <div className="glass-panel rounded-2xl p-6 border-destructive/20">
              <h3 className="text-lg font-bold text-destructive mb-4 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                Error Details
              </h3>
              <div className="bg-destructive/10 p-4 rounded-xl text-sm text-white/80 font-mono">
                {tx.errorDetails}
              </div>
            </div>
          )}

          {/* Proof of Payment */}
          {tx.status === 'success' && tx.proof && (
            <div className="glass-panel rounded-2xl p-6 border-primary/20">
              <h3 className="text-lg font-bold text-primary mb-4 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5" />
                Proof of Payment
              </h3>
              <div className="space-y-4">
                {tx.proof.transactionId && (
                  <div className="bg-white/5 p-4 rounded-xl">
                    <div className="text-xs text-muted-foreground mb-1">Transaction ID</div>
                    <div className="font-mono text-white text-sm">{tx.proof.transactionId}</div>
                  </div>
                )}
                {tx.proof.confirmationUrl && (
                  <div className="bg-white/5 p-4 rounded-xl">
                    <div className="text-xs text-muted-foreground mb-1">Confirmation URL</div>
                    <a
                      href={tx.proof.confirmationUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-secondary hover:underline text-sm flex items-center gap-1"
                    >
                      <Link className="w-3 h-3" />
                      {tx.proof.confirmationUrl}
                    </a>
                  </div>
                )}
                {tx.proof.screenshotUrl && (
                  <div className="bg-white/5 p-4 rounded-xl">
                    <div className="text-xs text-muted-foreground mb-2">Payment Screenshot</div>
                    <img
                      src={tx.proof.screenshotUrl}
                      alt="Payment proof screenshot"
                      className="rounded-lg max-w-full border border-white/10"
                    />
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right Column — Agent Chat */}
        <div className="space-y-6">
          <div className="glass-panel rounded-2xl p-6 border-white/5 sticky top-6">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <Bot className="w-5 h-5 text-primary" />
              Agent Communication
            </h3>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {lifecycleStages.map((stage, i) => (
                <div key={`stage-mobile-${i}-${stage.timestamp}`} className="flex gap-3">
                  <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Bot className="w-3.5 h-3.5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm text-white">{stage.name}</div>
                    {stage.message && (
                      <div className="text-xs text-muted-foreground mt-0.5">{stage.message}</div>
                    )}
                    <div className="text-xs text-white/20 mt-0.5">
                      {new Date(stage.timestamp).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              ))}

              {tx.status === 'processing' && (
                <div className="flex gap-3">
                  <div className="w-7 h-7 rounded-full bg-secondary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Loader2 className="w-3.5 h-3.5 text-secondary animate-spin" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm text-muted-foreground">Processing payment...</div>
                  </div>
                </div>
              )}

              {tx.status === 'success' && (
                <div className="flex gap-3">
                  <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm text-primary font-medium">
                      Payment completed successfully!
                    </div>
                  </div>
                </div>
              )}

              {(tx.status === 'failed' || tx.status === 'declined' || tx.status === 'error') && (
                <div className="flex gap-3">
                  <div className="w-7 h-7 rounded-full bg-destructive/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-destructive" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm text-destructive font-medium">
                      {tx.errorDetails || 'Payment failed'}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Quick Status */}
          <div className="glass-panel rounded-2xl p-6 border-white/5">
            <div className="flex items-center gap-4">
              {statusIcon[tx.status]}
              <div>
                <div className="font-bold text-white capitalize">{tx.status}</div>
                <div className="text-xs text-muted-foreground">{tx.description}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
