import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Bot, Link2, Activity, Key, FileText, Loader2,
  CheckCircle2, Zap, ChevronRight, AlertTriangle, Copy, Check,
} from 'lucide-react';
import { toast } from 'sonner';
import { useAppContext } from '../context/AppContext';
import { useSSE } from '../hooks/useSSE';
import PaymentMethodSelector from '../components/PaymentMethodSelector';
import { PaymentMethodModal } from '../components/PaymentMethodModal';
import SmartVerificationPanel from '../components/SmartVerificationPanel';
import type { PaymentDetails } from '../types';

type AgentStatus = 'idle' | 'analyzing' | 'confirm' | 'select_method' | 'payment_input' | 'processing' | 'success' | 'error';

export default function ProcessPage() {
  const { state, dispatch } = useAppContext();
  const { backendStage } = useSSE();

  const [agentStatus, setAgentStatus] = useState<AgentStatus>('idle');
  const [paymentLink, setPaymentLink] = useState('');
  const [details, setDetails] = useState<PaymentDetails | null>(null);
  const [selectedMethod, setSelectedMethod] = useState<string>('');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [currentTxId, setCurrentTxId] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleAnalyzeLink = async () => {
    if (!paymentLink.trim()) {
      toast.error('Please enter a valid payment link');
      return;
    }
    setAgentStatus('analyzing');
    setErrorMessage('');

    try {
      const response = await fetch('/api/analyze-link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ link: paymentLink }),
      });

      const payload = await response.json();
      if (response.ok) {
        setDetails(payload);
        setAgentStatus('confirm');
        toast.success('Link analyzed successfully');
      } else {
        throw new Error(payload.error || 'Failed analysis');
      }
    } catch (error: any) {
      console.error(error);
      toast.error('Failed to analyze link via agent backend');
      setAgentStatus('error');
      setErrorMessage(error.message || 'Analysis failed');
    }
  };

  const proceedToMethodSelection = () => {
    setAgentStatus('select_method');
  };

  const handleMethodSelected = (method: string) => {
    setSelectedMethod(method);
    setShowPaymentModal(true);
    setAgentStatus('payment_input');
  };

  const handlePaymentSubmit = async (formData: Record<string, any>) => {
    setShowPaymentModal(false);
    setAgentStatus('processing');

    try {
      const response = await fetch('/api/execute-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paymentDetails: details,
          paymentMethod: selectedMethod,
          paymentLink,
          cardDetails: formData,
          verificationConfig: state.verificationConfig,
        }),
      });

      const result = await response.json();
      if (result.success) {
        setCurrentTxId(result.transactionId);
        toast.info(result.message || 'Payment agent deployed. Execution started.');
      } else {
        throw new Error(result.error || 'Payment failed on backend');
      }
    } catch (error: any) {
      console.error(error);
      setAgentStatus('error');
      setErrorMessage(error.message || 'Execution failed');
      toast.error('Execution failed: ' + (error.message || ''));
    }
  };

  const handlePaymentModalRetry = () => {
    setShowPaymentModal(true);
    setAgentStatus('payment_input');
    setErrorMessage('');
  };

  const resetAgent = () => {
    setAgentStatus('idle');
    setPaymentLink('');
    setDetails(null);
    setSelectedMethod('');
    setShowPaymentModal(false);
    setCurrentTxId('');
    setErrorMessage('');
  };

  const currentTx = state.transactions.find((t) => t.id === currentTxId);

  // Listen for success/fail from SSE updates via useEffect to avoid infinite re-render
  const currentTxStatus = currentTx?.status;
  const currentTxError = currentTx?.errorDetails;
  React.useEffect(() => {
    if (agentStatus !== 'processing' || !currentTxStatus) return;
    if (currentTxStatus === 'success') {
      setAgentStatus('success');
    } else if (currentTxStatus === 'failed' || currentTxStatus === 'declined' || currentTxStatus === 'error') {
      setAgentStatus('error');
      setErrorMessage(currentTxError || 'Payment was declined or encountered an error');
    }
  }, [currentTxStatus, currentTxError, agentStatus]);

  return (
    <motion.div
      key="process"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="p-6 lg:p-10 max-w-4xl mx-auto"
    >
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-white flex items-center gap-3">
          <Bot className="w-8 h-8 text-primary" />
          Agent Payer Workflow
        </h2>
        {agentStatus !== 'idle' && (
          <button
            onClick={resetAgent}
            className="text-sm text-muted-foreground hover:text-white px-4 py-2 rounded-lg bg-white/5"
          >
            Reset Agent
          </button>
        )}
      </div>

      <div className="relative">
        {/* Progress Line */}
        <div className="absolute left-8 top-10 bottom-10 w-0.5 bg-white/10 z-0" />

        <AnimatePresence>
          {/* ─── Step 1: Input Link ─── */}
          <div className="relative z-10 flex gap-6 mb-8">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0 transition-colors duration-500 shadow-lg ${
                agentStatus !== 'idle'
                  ? 'bg-primary text-primary-foreground neon-glow-primary'
                  : 'bg-input text-muted-foreground border border-white/10'
              }`}
            >
              <Link2 className="w-6 h-6" />
            </div>
            <div className="flex-1 pt-2">
              <h3
                className={`text-xl font-bold mb-4 ${
                  agentStatus !== 'idle' ? 'text-primary' : 'text-white'
                }`}
              >
                1. Receive Payment Link
              </h3>
              {agentStatus === 'idle' ? (
                <div className="glass-panel p-6 rounded-2xl border-white/10">
                  <label className="block text-sm font-medium text-muted-foreground mb-3">
                    Paste standard or invoice link (Stripe, PayPal, Crypto, etc.)
                  </label>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <input
                      type="text"
                      value={paymentLink}
                      onChange={(e) => setPaymentLink(e.target.value)}
                      placeholder="https://checkout.stripe.com/c/pay/..."
                      className="flex-1 bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary shadow-inner"
                    />
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleAnalyzeLink}
                      disabled={!paymentLink}
                      className="disabled:opacity-50 px-8 py-3 bg-primary text-primary-foreground font-bold rounded-xl whitespace-nowrap hover:bg-primary/90 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all"
                    >
                      <Bot className="w-5 h-5" />
                      Initiate Agent
                    </motion.button>
                  </div>
                </div>
              ) : (
                <div className="glass-panel px-6 py-4 rounded-xl border-white/5 text-muted-foreground truncate font-mono text-sm">
                  {paymentLink}
                </div>
              )}
            </div>
          </div>

          {/* ─── Step 2: Analysis & Verification ─── */}
          {agentStatus !== 'idle' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative z-10 flex gap-6 mb-8"
            >
              <div
                className={`w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0 transition-colors duration-500 shadow-lg ${
                  agentStatus !== 'analyzing'
                    ? 'bg-secondary text-secondary-foreground neon-glow-secondary'
                    : 'bg-input text-muted-foreground border border-white/10'
                }`}
              >
                {agentStatus === 'analyzing' ? (
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                ) : (
                  <Activity className="w-6 h-6" />
                )}
              </div>
              <div className="flex-1 pt-2">
                <h3
                  className={`text-xl font-bold mb-4 ${
                    agentStatus === 'analyzing' ? 'text-white' : 'text-secondary'
                  }`}
                >
                  2. Fetch & Verification
                </h3>

                {agentStatus === 'analyzing' && (
                  <div className="glass-panel p-6 rounded-2xl border-white/10 flex flex-col gap-4">
                    <div className="flex items-center gap-4">
                      <Loader2 className="w-5 h-5 animate-spin text-primary" />
                      <span className="text-muted-foreground">
                        Chromium fetching gateway, performing real-time DOM verification...
                      </span>
                    </div>
                  </div>
                )}

                {details && (
                  <div className="glass-panel p-6 rounded-2xl border-secondary/30 relative overflow-hidden">
                    <div className="absolute -right-10 -top-10 w-32 h-32 bg-secondary/10 rounded-full blur-2xl" />
                    <div className="grid grid-cols-2 gap-y-4 gap-x-8 relative z-10">
                      <div>
                        <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">
                          Gateway Detected
                        </div>
                        <div className="font-medium text-white flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-secondary" />
                          {details.gateway}
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">
                          Vendor / Product
                        </div>
                        <div className="font-medium text-white">{details.vendor || 'Unknown'}</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">
                          Amount Due
                        </div>
                        <div className="font-bold text-2xl text-accent">
                          {details.amount ? details.amount.toFixed(2) : '??'}{' '}
                          <span className="text-sm">{details.currency}</span>
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">
                          Agent Risk Score
                        </div>
                        <div className="font-medium text-primary flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" />
                          {details.riskScore}
                        </div>
                      </div>
                    </div>

                    {/* Available Payment Methods */}
                    {details.availablePaymentMethods && details.availablePaymentMethods.length > 0 && agentStatus === 'confirm' && (
                      <div className="mt-6 pt-4 border-t border-white/10">
                        <div className="text-xs text-muted-foreground mb-3 uppercase tracking-wider">
                          Available Payment Methods on Link
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {details.availablePaymentMethods
                            .filter((m) => m && m.trim().length > 0)
                            .map((m, idx) => (
                              <span
                                key={`method-${m}-${idx}`}
                                className="px-3 py-1 bg-white/5 border border-white/10 rounded-lg text-sm text-white"
                              >
                                {m}
                              </span>
                            ))}
                        </div>
                      </div>
                    )}

                    {agentStatus === 'confirm' && (
                      <div className="mt-6 flex justify-end">
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={proceedToMethodSelection}
                          className="px-6 py-3 bg-secondary text-secondary-foreground font-bold rounded-xl hover:bg-secondary/90 transition-all flex items-center gap-2"
                        >
                          Continue to Execution <ChevronRight className="w-4 h-4" />
                        </motion.button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {/* ─── Smart Verification Panel (between step 2 and 3) ─── */}
          {(agentStatus === 'select_method' || agentStatus === 'payment_input' || agentStatus === 'processing' || agentStatus === 'success') && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative z-10 ml-[88px] mb-8"
            >
              <SmartVerificationPanel />
            </motion.div>
          )}

          {/* ─── Step 3: User Provisioning ─── */}
          {(agentStatus === 'select_method' || agentStatus === 'payment_input' || agentStatus === 'processing' || agentStatus === 'success' || agentStatus === 'error') && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative z-10 flex gap-6 mb-8"
            >
              <div
                className={`w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0 transition-colors duration-500 shadow-lg ${
                  agentStatus === 'processing' || agentStatus === 'success'
                    ? 'bg-accent text-accent-foreground neon-glow-accent'
                    : 'bg-input text-muted-foreground border border-white/10'
                }`}
              >
                <Key className="w-6 h-6" />
              </div>
              <div className="flex-1 pt-2">
                <h3 className="text-xl font-bold mb-4 text-accent">3. User Provisioning</h3>

                {agentStatus === 'select_method' && details && (
                  <div className="glass-panel p-6 rounded-2xl border-accent/20">
                    <p className="text-sm text-muted-foreground mb-4">
                      Select the funding method for the agent to use on the detected target gateway.
                    </p>
                    <PaymentMethodSelector
                      availableMethods={details.availablePaymentMethods?.filter((m) => m && m.trim().length > 0) || []}
                      onSelect={handleMethodSelected}
                    />
                    <p className="text-xs text-muted-foreground mt-4 italic">
                      You can save this method in Settings for another time
                    </p>
                  </div>
                )}

                {(agentStatus === 'processing' || agentStatus === 'success') && (
                  <div className="glass-panel px-6 py-4 rounded-xl border-white/5 text-muted-foreground font-medium flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-accent" />
                    Credentials provisioned to secure backend enclave.
                  </div>
                )}

                {agentStatus === 'error' && (
                  <div className="glass-panel p-6 rounded-2xl border-destructive/30">
                    <div className="flex items-center gap-3 mb-3">
                      <AlertTriangle className="w-5 h-5 text-destructive" />
                      <span className="font-bold text-destructive">Payment Failed</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">{errorMessage}</p>
                    <button
                      onClick={handlePaymentModalRetry}
                      className="px-4 py-2 bg-accent/20 text-accent font-medium rounded-lg hover:bg-accent/30 transition-all"
                    >
                      Retry with Different Card
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {/* ─── Step 4: Execution & Proof ─── */}
          {(agentStatus === 'processing' || agentStatus === 'success') && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative z-10 flex gap-6 mb-8"
            >
              <div
                className={`w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0 transition-colors duration-500 shadow-lg ${
                  agentStatus === 'success'
                    ? 'bg-primary text-primary-foreground neon-glow-primary'
                    : 'bg-input text-muted-foreground border border-white/10'
                }`}
              >
                {agentStatus === 'processing' ? (
                  <Loader2 className="w-6 h-6 animate-spin text-white" />
                ) : (
                  <FileText className="w-6 h-6" />
                )}
              </div>
              <div className="flex-1 pt-2">
                <h3
                  className={`text-xl font-bold mb-4 ${
                    agentStatus === 'success' ? 'text-primary' : 'text-white'
                  }`}
                >
                  {agentStatus === 'processing' ? '4. Agent Executing Remotely...' : '4. Proof of Payment'}
                </h3>

                {agentStatus === 'processing' && (
                  <div className="glass-panel p-6 rounded-2xl border-white/10 space-y-3">
                    <div className="flex items-center gap-3 text-sm text-muted-foreground">
                      <Loader2 className="w-4 h-4 animate-spin text-primary" />
                      {backendStage || 'Waiting for agent cluster...'}
                    </div>
                    {currentTx?.stages && currentTx.stages.length > 0 && (
                      <div className="mt-4 space-y-2">
                        {currentTx.stages.map((stage, i) => (
                          <div key={`stage-${i}-${stage.timestamp}`} className="flex items-center gap-2 text-xs text-muted-foreground">
                            <CheckCircle2 className="w-3 h-3 text-primary" />
                            <span>{stage.name}</span>
                            <span className="text-white/30">
                              {new Date(stage.timestamp).toLocaleTimeString()}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {agentStatus === 'success' && (
                  <div className="glass-panel p-1 rounded-2xl border-primary bg-primary/5 neon-glow-primary/20">
                    <div className="bg-black/40 rounded-xl p-6">
                      <div className="flex items-center gap-3 mb-6">
                        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                          <CheckCircle2 className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <div className="font-bold text-white text-lg">Transaction Complete</div>
                          <div className="text-sm text-primary font-mono">
                            {currentTxId || 'Real bypass recorded'}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                        <div className="bg-white/5 p-4 rounded-lg">
                          <div className="text-xs text-muted-foreground mb-1">Amount Paid</div>
                          <div className="font-bold text-white">
                            ${details?.amount?.toFixed(2)} {details?.currency || 'USD'}
                          </div>
                        </div>
                        <div className="bg-white/5 p-4 rounded-lg">
                          <div className="text-xs text-muted-foreground mb-1">Target Vendor</div>
                          <div className="font-bold text-white">{details?.vendor}</div>
                        </div>
                      </div>

                      <div className="flex gap-4">
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(currentTxId);
                            setIsCopied(true);
                            setTimeout(() => setIsCopied(false), 2000);
                          }}
                          className="flex-1 py-3 bg-white/10 hover:bg-white/20 text-white font-medium rounded-xl transition-all flex items-center justify-center gap-2"
                        >
                          {isCopied ? <Check className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4" />}
                          {isCopied ? 'Copied!' : 'Copy TXN Hash'}
                        </button>
                        <button className="flex-1 py-3 bg-primary/20 hover:bg-primary/30 text-primary font-medium rounded-xl transition-all flex items-center justify-center gap-2">
                          <FileText className="w-4 h-4" />
                          Download Receipt PDF
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Payment Method Modal (floating popup tab) */}
      {details && (
        <PaymentMethodModal
          open={showPaymentModal}
          onClose={() => {
            setShowPaymentModal(false);
            if (agentStatus === 'payment_input') setAgentStatus('select_method');
          }}
          selectedMethod={selectedMethod}
          paymentDetails={details}
          onSubmit={handlePaymentSubmit}
          error={errorMessage}
        />
      )}
    </motion.div>
  );
}
