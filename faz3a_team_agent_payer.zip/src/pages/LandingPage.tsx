import { motion } from 'motion/react';
import { Bot, Zap, Search, CreditCard, FileText } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

export default function LandingPage() {
  const { dispatch } = useAppContext();

  const features = [
    {
      icon: Search,
      title: 'Smart Link Detection',
      description:
        'Automatically identifies the gateway type from the link and displays available payment methods across 60+ gateways.',
      color: 'text-primary',
      glow: 'neon-glow-primary',
      bgColor: 'bg-primary/10',
    },
    {
      icon: CreditCard,
      title: 'Auto-Fill',
      description:
        'Automatically fills in payment details from saved tokenized cards. Supports up to 1000 saved cards in your vault.',
      color: 'text-secondary',
      glow: 'neon-glow-secondary',
      bgColor: 'bg-secondary/10',
    },
    {
      icon: FileText,
      title: 'AI Receipt Parser',
      description:
        'Reads uploaded invoices and extracts the payment link automatically using advanced AI analysis.',
      color: 'text-accent',
      glow: 'neon-glow-accent',
      bgColor: 'bg-accent/10',
    },
  ];

  return (
    <motion.div
      key="landing"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="h-full flex flex-col items-center justify-center text-center p-6 relative overflow-hidden"
    >
      {/* Particle background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(0,136,255,0.15),rgba(255,255,255,0))]" />
        <div className="particles-container">
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className="particle"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 6}s`,
                animationDuration: `${6 + Math.random() * 8}s`,
              }}
            />
          ))}
        </div>
      </div>

      <div className="relative z-10 flex flex-col items-center max-w-5xl mx-auto">
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', duration: 1, bounce: 0.4 }}
        >
          <Bot className="w-24 h-24 text-primary neon-glow-primary mb-6 rounded-full bg-primary/10 p-4" />
        </motion.div>

        <motion.h1
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-5xl md:text-6xl font-extrabold mb-4 tracking-tight"
        >
          <span className="text-primary">FAZ3A TEAM</span>
          <br />
          AGENT PAYER
        </motion.h1>

        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed font-medium"
          style={{ fontFamily: "'Cairo', sans-serif" }}
        >
          الوكيل الذكي لإتمام عمليات الدفع
          <br />
          <span style={{ fontFamily: "'Inter', sans-serif" }}>
            AI-powered payment agent capable of handling complex transactions intelligently. Drop a
            link, let the agent scrape, verify, bypass and execute.
          </span>
        </motion.p>

        <motion.button
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: 'dashboard' })}
          className="px-8 py-4 bg-primary text-primary-foreground font-bold rounded-full neon-glow-primary hover:shadow-[0_0_30px_rgba(0,255,136,0.5)] transition-all duration-300 flex items-center gap-2 text-lg mb-16"
        >
          <Zap className="w-5 h-5" />
          Launch Dashboard
        </motion.button>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.8 + i * 0.15 }}
              className="glass-panel p-6 rounded-2xl text-left hover:border-white/10 transition-all group"
            >
              <div
                className={`w-12 h-12 rounded-xl ${feature.bgColor} flex items-center justify-center mb-4 ${feature.glow} group-hover:scale-110 transition-transform`}
              >
                <feature.icon className={`w-6 h-6 ${feature.color}`} />
              </div>
              <h3 className="font-bold text-white text-lg mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
