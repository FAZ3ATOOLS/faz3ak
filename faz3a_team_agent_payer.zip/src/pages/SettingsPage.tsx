import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Settings, CreditCard, Bitcoin, Wallet, Shield, Bell, Globe,
  Plus, Trash2, Star, Eye, EyeOff, Copy, Check, Lock, Unlock,
  Banknote, ChevronDown,
} from 'lucide-react';
import { toast } from 'sonner';
import { useAppContext } from '../context/AppContext';
import SmartVerificationPanel from '../components/SmartVerificationPanel';

const PROXY_CODE = 'Aamm0909@';

export default function SettingsPage() {
  const { state, dispatch, fetchSavedCards, fetchWallets, fetchACH } = useAppContext();

  // Proxy
  const [proxyCode, setProxyCode] = useState('');

  // Card form
  const [showCardForm, setShowCardForm] = useState(false);
  const [cardForm, setCardForm] = useState({
    number: '', name: '', expiry: '', cvv: '', nickname: '',
  });

  // ACH form
  const [showACHForm, setShowACHForm] = useState(false);
  const [achForm, setACHForm] = useState({
    routingNumber: '', accountNumber: '', bankName: '', accountType: 'checking' as 'checking' | 'savings',
  });

  // Wallet
  const [walletNetwork, setWalletNetwork] = useState<'ETH' | 'BSC' | 'TRC20'>('ETH');
  const [creatingWallet, setCreatingWallet] = useState(false);
  const [revealedKeys, setRevealedKeys] = useState<Set<string>>(new Set());
  const [copiedId, setCopiedId] = useState('');

  // Notification settings
  const [notifyEnabled, setNotifyEnabled] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);

  useEffect(() => {
    fetchSavedCards();
    fetchWallets();
    fetchACH();
  }, [fetchSavedCards, fetchWallets, fetchACH]);

  const handleProxyActivation = () => {
    if (proxyCode === PROXY_CODE) {
      dispatch({ type: 'SET_PROXY_ACTIVATED', payload: true });
      toast.success('Proxy activated successfully');
    } else {
      toast.error('Invalid activation code');
    }
  };

  const detectBrand = (num: string): string => {
    const n = num.replace(/\s/g, '');
    if (/^4/.test(n)) return 'Visa';
    if (/^5[1-5]/.test(n) || /^2[2-7]/.test(n)) return 'Mastercard';
    if (/^3[47]/.test(n)) return 'Amex';
    if (/^6(?:011|5)/.test(n)) return 'Discover';
    if (/^35/.test(n)) return 'JCB';
    if (/^3(?:0[0-5]|[68])/.test(n)) return 'Diners';
    return 'Card';
  };

  const handleSaveCard = async () => {
    if (!cardForm.number || !cardForm.name || !cardForm.expiry || !cardForm.cvv) {
      toast.error('All card fields are required');
      return;
    }
    try {
      const res = await fetch('/api/saved-cards', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cardNumber: cardForm.number.replace(/\s/g, ''),
          cardholderName: cardForm.name,
          expiry: cardForm.expiry,
          cvv: cardForm.cvv,
          nickname: cardForm.nickname || detectBrand(cardForm.number),
        }),
      });
      if (res.ok) {
        toast.success('Card saved successfully');
        setShowCardForm(false);
        setCardForm({ number: '', name: '', expiry: '', cvv: '', nickname: '' });
        fetchSavedCards();
      } else {
        const err = await res.json();
        toast.error(err.error || 'Failed to save card');
      }
    } catch {
      toast.error('Network error');
    }
  };

  const handleDeleteCard = async (id: string) => {
    try {
      await fetch(`/api/saved-cards/${id}`, { method: 'DELETE' });
      dispatch({ type: 'REMOVE_SAVED_CARD', payload: id });
      toast.success('Card removed');
    } catch {
      toast.error('Failed to remove card');
    }
  };

  const handleSetDefault = async (id: string) => {
    try {
      await fetch(`/api/saved-cards/${id}/default`, { method: 'PUT' });
      dispatch({ type: 'SET_DEFAULT_CARD', payload: id });
      toast.success('Default card updated');
    } catch {
      toast.error('Failed to set default');
    }
  };

  const handleSaveACH = async () => {
    if (!achForm.routingNumber || !achForm.accountNumber || !achForm.bankName) {
      toast.error('All ACH fields are required');
      return;
    }
    try {
      const res = await fetch('/api/saved-ach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(achForm),
      });
      if (res.ok) {
        toast.success('ACH account saved');
        setShowACHForm(false);
        setACHForm({ routingNumber: '', accountNumber: '', bankName: '', accountType: 'checking' });
        fetchACH();
      }
    } catch {
      toast.error('Network error');
    }
  };

  const handleDeleteACH = async (id: string) => {
    try {
      await fetch(`/api/saved-ach/${id}`, { method: 'DELETE' });
      dispatch({ type: 'REMOVE_SAVED_ACH', payload: id });
      toast.success('ACH account removed');
    } catch {
      toast.error('Failed to remove');
    }
  };

  const handleCreateWallet = async () => {
    setCreatingWallet(true);
    try {
      const res = await fetch('/api/wallets/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ network: walletNetwork }),
      });
      if (res.ok) {
        toast.success('Wallet generated successfully');
        fetchWallets();
      }
    } catch {
      toast.error('Failed to create wallet');
    } finally {
      setCreatingWallet(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(''), 2000);
  };

  const toggleRevealKey = (id: string) => {
    const next = new Set(revealedKeys);
    if (next.has(id)) next.delete(id); else next.add(id);
    setRevealedKeys(next);
  };

  const handleLanguageToggle = () => {
    const newLang = state.language === 'en' ? 'ar' : 'en';
    dispatch({ type: 'SET_LANGUAGE', payload: newLang });
    document.documentElement.dir = newLang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = newLang;
  };

  return (
    <motion.div
      key="settings"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="p-6 lg:p-10 max-w-4xl mx-auto"
    >
      <h2 className="text-3xl font-bold mb-8 text-white flex items-center gap-3">
        <Settings className="w-8 h-8 text-primary" />
        Agent Settings
      </h2>

      <div className="space-y-6">
        {/* ─── Proxy Activation ─── */}
        <div className="glass-panel p-6 rounded-2xl border-white/5">
          <h3 className="text-xl font-bold mb-4 text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-secondary" />
            Proxy Activation
          </h3>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <input
                type="password"
                value={proxyCode}
                onChange={(e) => setProxyCode(e.target.value)}
                placeholder="Enter activation code"
                className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-secondary"
              />
            </div>
            <button
              onClick={handleProxyActivation}
              className="px-6 py-3 bg-secondary text-secondary-foreground font-bold rounded-xl hover:bg-secondary/90 transition-all"
            >
              Activate
            </button>
            <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${state.proxyActivated ? 'bg-primary/10 text-primary' : 'bg-white/5 text-muted-foreground'}`}>
              {state.proxyActivated ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
              <span className="text-sm font-medium">{state.proxyActivated ? 'Active' : 'Inactive'}</span>
            </div>
          </div>
        </div>

        {/* ─── Saved Payment Cards ─── */}
        <div className="glass-panel p-6 rounded-2xl border-white/5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-accent" />
              Saved Payment Cards
              <span className="text-sm text-muted-foreground font-normal ml-2">
                {state.savedCards.length} / 1000
              </span>
            </h3>
            {state.savedCards.length < 1000 && (
              <button
                onClick={() => setShowCardForm(!showCardForm)}
                className="px-4 py-2 bg-accent/10 text-accent font-medium rounded-lg hover:bg-accent/20 transition-all flex items-center gap-2 text-sm"
              >
                <Plus className="w-4 h-4" />
                Add New Card
              </button>
            )}
          </div>

          <AnimatePresence>
            {showCardForm && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden mb-4"
              >
                <div className="bg-white/5 rounded-xl p-4 space-y-3">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-muted-foreground mb-1">Card Number</label>
                      <input type="text" value={cardForm.number} onChange={(e) => setCardForm({ ...cardForm, number: e.target.value })} placeholder="4242 4242 4242 4242" className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-accent" />
                    </div>
                    <div>
                      <label className="block text-xs text-muted-foreground mb-1">Cardholder Name</label>
                      <input type="text" value={cardForm.name} onChange={(e) => setCardForm({ ...cardForm, name: e.target.value })} placeholder="JOHN DOE" className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-accent" />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs text-muted-foreground mb-1">Expiry</label>
                      <input type="text" value={cardForm.expiry} onChange={(e) => setCardForm({ ...cardForm, expiry: e.target.value })} placeholder="12/26" className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-accent" />
                    </div>
                    <div>
                      <label className="block text-xs text-muted-foreground mb-1">CVV</label>
                      <input type="text" value={cardForm.cvv} onChange={(e) => setCardForm({ ...cardForm, cvv: e.target.value })} placeholder="123" className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-accent" />
                    </div>
                    <div>
                      <label className="block text-xs text-muted-foreground mb-1">Nickname</label>
                      <input type="text" value={cardForm.nickname} onChange={(e) => setCardForm({ ...cardForm, nickname: e.target.value })} placeholder="My Card" className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-accent" />
                    </div>
                  </div>
                  <div className="flex justify-end gap-3">
                    <button onClick={() => setShowCardForm(false)} className="px-4 py-2 text-muted-foreground text-sm hover:text-white">Cancel</button>
                    <button onClick={handleSaveCard} className="px-6 py-2 bg-accent text-accent-foreground font-bold rounded-lg text-sm">Save Card</button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="space-y-2">
            {state.savedCards.length === 0 ? (
              <div className="text-muted-foreground text-center py-6 text-sm">No saved cards yet. Add your first card above.</div>
            ) : (
              state.savedCards.map((card, index) => (
                <div key={`${card.id}-${index}`} className="flex items-center justify-between p-4 bg-white/5 rounded-xl hover:bg-white/8 transition-all">
                  <div className="flex items-center gap-3">
                    <CreditCard className="w-5 h-5 text-muted-foreground" />
                    <div>
                      <div className="font-medium text-white flex items-center gap-2">
                        {card.nickname || card.brand}
                        {card.isDefault && (
                          <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">Default</span>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {card.brand} •••• {card.last4} · Exp: {card.expiry}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {!card.isDefault && (
                      <button onClick={() => handleSetDefault(card.id)} className="p-2 hover:bg-white/10 rounded-lg transition-all" title="Set as default">
                        <Star className="w-4 h-4 text-muted-foreground" />
                      </button>
                    )}
                    <button onClick={() => handleDeleteCard(card.id)} className="p-2 hover:bg-destructive/10 rounded-lg transition-all" title="Delete">
                      <Trash2 className="w-4 h-4 text-destructive/70" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* ─── ACH Accounts ─── */}
        <div className="glass-panel p-6 rounded-2xl border-white/5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <Banknote className="w-5 h-5 text-secondary" />
              ACH Accounts
            </h3>
            <button
              onClick={() => setShowACHForm(!showACHForm)}
              className="px-4 py-2 bg-secondary/10 text-secondary font-medium rounded-lg hover:bg-secondary/20 transition-all flex items-center gap-2 text-sm"
            >
              <Plus className="w-4 h-4" />
              Add ACH Account
            </button>
          </div>

          <AnimatePresence>
            {showACHForm && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden mb-4">
                <div className="bg-white/5 rounded-xl p-4 space-y-3">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-muted-foreground mb-1">Routing Number</label>
                      <input type="text" value={achForm.routingNumber} onChange={(e) => setACHForm({ ...achForm, routingNumber: e.target.value })} placeholder="021000021" className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-secondary" />
                    </div>
                    <div>
                      <label className="block text-xs text-muted-foreground mb-1">Account Number</label>
                      <input type="text" value={achForm.accountNumber} onChange={(e) => setACHForm({ ...achForm, accountNumber: e.target.value })} placeholder="123456789" className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-secondary" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-muted-foreground mb-1">Bank Name</label>
                      <input type="text" value={achForm.bankName} onChange={(e) => setACHForm({ ...achForm, bankName: e.target.value })} placeholder="Bank of America" className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-secondary" />
                    </div>
                    <div>
                      <label className="block text-xs text-muted-foreground mb-1">Account Type</label>
                      <div className="flex gap-2">
                        <button onClick={() => setACHForm({ ...achForm, accountType: 'checking' })} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${achForm.accountType === 'checking' ? 'bg-secondary/20 text-secondary border border-secondary/30' : 'bg-white/5 text-muted-foreground'}`}>Checking</button>
                        <button onClick={() => setACHForm({ ...achForm, accountType: 'savings' })} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${achForm.accountType === 'savings' ? 'bg-secondary/20 text-secondary border border-secondary/30' : 'bg-white/5 text-muted-foreground'}`}>Savings</button>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end gap-3">
                    <button onClick={() => setShowACHForm(false)} className="px-4 py-2 text-muted-foreground text-sm hover:text-white">Cancel</button>
                    <button onClick={handleSaveACH} className="px-6 py-2 bg-secondary text-secondary-foreground font-bold rounded-lg text-sm">Save ACH</button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="space-y-2">
            {state.savedACH.length === 0 ? (
              <div className="text-muted-foreground text-center py-6 text-sm">No ACH accounts saved.</div>
            ) : (
              state.savedACH.map((ach, index) => (
                <div key={`${ach.id}-${index}`} className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Banknote className="w-5 h-5 text-muted-foreground" />
                    <div>
                      <div className="font-medium text-white">{ach.bankName}</div>
                      <div className="text-xs text-muted-foreground">
                        Routing: •••{ach.routingNumber.slice(-4)} · Account: •••{ach.accountLast4} · {ach.accountType}
                      </div>
                    </div>
                  </div>
                  <button onClick={() => handleDeleteACH(ach.id)} className="p-2 hover:bg-destructive/10 rounded-lg transition-all">
                    <Trash2 className="w-4 h-4 text-destructive/70" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* ─── Crypto Wallets ─── */}
        <div className="glass-panel p-6 rounded-2xl border-white/5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <Wallet className="w-5 h-5 text-accent" />
              Crypto Wallets
            </h3>
            <div className="flex items-center gap-2">
              <select
                value={walletNetwork}
                onChange={(e) => setWalletNetwork(e.target.value as 'ETH' | 'BSC' | 'TRC20')}
                className="bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-accent"
              >
                <option value="ETH">ETH</option>
                <option value="BSC">BSC</option>
                <option value="TRC20">USDT TRC20</option>
              </select>
              <button
                onClick={handleCreateWallet}
                disabled={creatingWallet}
                className="px-4 py-2 bg-accent/10 text-accent font-medium rounded-lg hover:bg-accent/20 transition-all flex items-center gap-2 text-sm disabled:opacity-50"
              >
                <Plus className="w-4 h-4" />
                {creatingWallet ? 'Creating...' : 'Create Wallet'}
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {state.wallets.length === 0 ? (
              <div className="text-muted-foreground text-center py-6 text-sm">No wallets created. Generate your first wallet above.</div>
            ) : (
              state.wallets.map((wallet, index) => (
                <div key={`${wallet.id}-${index}`} className="bg-white/5 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`px-2 py-1 rounded-md text-xs font-bold ${
                        wallet.network === 'ETH' ? 'bg-secondary/20 text-secondary' :
                        wallet.network === 'BSC' ? 'bg-accent/20 text-accent' :
                        'bg-primary/20 text-primary'
                      }`}>
                        {wallet.network}
                      </div>
                      <div className="font-mono text-sm text-white">
                        {wallet.address.substring(0, 10)}...{wallet.address.substring(wallet.address.length - 8)}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">{wallet.balance}</span>
                      <button
                        onClick={() => copyToClipboard(wallet.address, wallet.id)}
                        className="p-2 hover:bg-white/10 rounded-lg transition-all"
                        title="Copy address"
                      >
                        {copiedId === wallet.id ? <Check className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4 text-muted-foreground" />}
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => toggleRevealKey(wallet.id)}
                      className="text-xs text-muted-foreground hover:text-white flex items-center gap-1 transition-all"
                    >
                      {revealedKeys.has(wallet.id) ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      {revealedKeys.has(wallet.id) ? 'Hide Private Key' : 'Show Private Key'}
                    </button>
                  </div>
                  <AnimatePresence>
                    {revealedKeys.has(wallet.id) && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                        <div className="mt-2 p-3 bg-destructive/5 border border-destructive/20 rounded-lg">
                          <div className="text-xs text-destructive mb-1">⚠ Private Key — Keep this secret</div>
                          <div className="font-mono text-xs text-white/80 break-all select-all">{wallet.privateKey}</div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))
            )}
          </div>
        </div>

        {/* ─── Verification Defaults ─── */}
        <SmartVerificationPanel />

        {/* ─── Notification Settings ─── */}
        <div className="glass-panel p-6 rounded-2xl border-white/5">
          <h3 className="text-xl font-bold mb-4 text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-primary" />
            Notification Settings
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
              <span className="text-sm text-muted-foreground">Enable Notifications</span>
              <button
                onClick={() => setNotifyEnabled(!notifyEnabled)}
                className={`relative w-11 h-6 rounded-full transition-colors ${notifyEnabled ? 'bg-primary shadow-[0_0_10px_rgba(0,255,136,0.4)]' : 'bg-white/10'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-black rounded-full transition-transform ${notifyEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
              </button>
            </div>
            <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
              <span className="text-sm text-muted-foreground">Sound on Payment</span>
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`relative w-11 h-6 rounded-full transition-colors ${soundEnabled ? 'bg-primary shadow-[0_0_10px_rgba(0,255,136,0.4)]' : 'bg-white/10'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-black rounded-full transition-transform ${soundEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
              </button>
            </div>
          </div>
        </div>

        {/* ─── Language ─── */}
        <div className="glass-panel p-6 rounded-2xl border-white/5">
          <h3 className="text-xl font-bold mb-4 text-white flex items-center gap-2">
            <Globe className="w-5 h-5 text-secondary" />
            Language
          </h3>
          <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
            <span className="text-sm text-muted-foreground">
              Current: {state.language === 'en' ? 'English' : 'العربية'}
            </span>
            <button
              onClick={handleLanguageToggle}
              className="px-6 py-2 bg-secondary/10 text-secondary font-medium rounded-lg hover:bg-secondary/20 transition-all text-sm"
            >
              {state.language === 'en' ? 'عربي' : 'English'}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
