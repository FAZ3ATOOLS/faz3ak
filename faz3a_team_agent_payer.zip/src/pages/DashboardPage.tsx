import { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { Activity, ShieldCheck, Bot, Link2, Zap } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { TransactionCard } from '../components/TransactionCard';

type FilterType = 'all' | 'success' | 'processing' | 'failed';

export default function DashboardPage() {
  const { state, dispatch } = useAppContext();
  const { transactions } = state;
  const [filter, setFilter] = useState<FilterType>('all');

  const processedAmount = useMemo(
    () =>
      transactions
        .filter((t) => t.status === 'success')
        .reduce((sum, t) => sum + t.amount, 0),
    [transactions]
  );

  const successCount = useMemo(
    () => transactions.filter((t) => t.status === 'success').length,
    [transactions]
  );

  const activeCount = useMemo(
    () => transactions.filter((t) => t.status === 'processing').length,
    [transactions]
  );

  const successRate = useMemo(
    () => (transactions.length > 0 ? ((successCount / transactions.length) * 100).toFixed(1) : '0'),
    [transactions, successCount]
  );

  const filteredTransactions = useMemo(() => {
    if (filter === 'all') return transactions;
    if (filter === 'failed')
      return transactions.filter(
        (t) => t.status === 'failed' || t.status === 'declined' || t.status === 'error'
      );
    return transactions.filter((t) => t.status === filter);
  }, [transactions, filter]);

  const filterButtons: { key: FilterType; label: string }[] = [
    { key: 'all', label: 'All' },
    { key: 'success', label: 'Completed' },
    { key: 'processing', label: 'Pending' },
    { key: 'failed', label: 'Failed' },
  ];

  return (
    <motion.div
      key="dashboard"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="p-6 lg:p-10 max-w-7xl mx-auto"
    >
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-3xl font-bold text-white">Dashboard Overview</h2>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: 'process' })}
          className="px-6 py-3 bg-primary text-primary-foreground font-bold rounded-xl neon-glow-primary flex items-center gap-2 hover:shadow-[0_0_25px_rgba(0,255,136,0.4)] transition-all"
        >
          <Link2 className="w-4 h-4" />
          Send New Payment Link
        </motion.button>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="glass-panel p-6 rounded-2xl flex flex-col gap-2 border-primary/20"
        >
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Activity className="w-4 h-4 text-primary" />
            Total Processed
          </div>
          <div className="text-3xl font-bold text-white">${processedAmount.toFixed(2)}</div>
          <div className="text-xs text-primary">{successCount} successful txns</div>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="glass-panel p-6 rounded-2xl flex flex-col gap-2 border-secondary/20"
        >
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <ShieldCheck className="w-4 h-4 text-secondary" />
            Success Rate
          </div>
          <div className="text-3xl font-bold text-white">{successRate}%</div>
          <div className="text-xs text-secondary">Secured by AI Risk Engine</div>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="glass-panel p-6 rounded-2xl flex flex-col gap-2 border-accent/20"
        >
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Bot className="w-4 h-4 text-accent" />
            Active Tasks
          </div>
          <div className="text-3xl font-bold text-white">{activeCount}</div>
          <div
            className="text-xs text-accent cursor-pointer hover:underline"
            onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: 'process' })}
          >
            Start a new task →
          </div>
        </motion.div>
      </div>

      {/* Transactions */}
      <div className="glass-panel rounded-2xl p-6 border-white/5">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            Recent Executions
          </h3>
          <div className="flex gap-1">
            {filterButtons.map((fb) => (
              <button
                key={fb.key}
                onClick={() => setFilter(fb.key)}
                className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  filter === fb.key
                    ? 'bg-white/10 text-white border border-white/20'
                    : 'text-muted-foreground hover:bg-white/5'
                }`}
              >
                {fb.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          {filteredTransactions.length === 0 ? (
            <div className="text-muted-foreground text-center py-12 flex flex-col items-center gap-3">
              <Bot className="w-12 h-12 text-white/10" />
              <span>No transactions yet. Start a new payment task.</span>
            </div>
          ) : (
            filteredTransactions.map((tx, index) => (
              <TransactionCard
                key={`dashboard-tx-${tx.id}-${index}`}
                transaction={tx}
                onClick={() => {
                  dispatch({ type: 'SET_SELECTED_TRANSACTION_ID', payload: tx.id });
                  dispatch({ type: 'SET_ACTIVE_TAB', payload: 'transaction-details' });
                }}
              />
            ))
          )}
        </div>
      </div>
    </motion.div>
  );
}
