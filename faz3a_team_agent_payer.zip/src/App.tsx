import { Toaster } from 'sonner';
import { Layout } from './components/Layout';
import { useSSE } from './hooks/useSSE';
import { ErrorBoundary } from './components/ErrorBoundary';

function AppContent() {
  useSSE();
  return <Layout />;
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppContent />
      <Toaster theme="dark" position="top-right" />
    </ErrorBoundary>
  );
}
