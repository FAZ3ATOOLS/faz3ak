import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  CreditCard,
  Copy,
  ChevronDown,
  ChevronUp,
  Loader2,
  Save,
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { toast } from 'sonner';
import type { PaymentDetails, CryptoWallet } from '../types';

interface PaymentMethodModalProps {
  open: boolean;
  onClose: () => void;
  selectedMethod: string;
  paymentDetails: PaymentDetails;
  onSubmit: (formData: Record<string, string>) => void;
  error?: string;
}

export function PaymentMethodModal({
  open,
  onClose,
  selectedMethod,
  paymentDetails,
  onSubmit,
  error,
}: PaymentMethodModalProps) {
  const { state } = useAppContext();
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [showBilling, setShowBilling] = useState(false);
  const [saveCard, setSaveCard] = useState(false);
  const [saveACH, setSaveACH] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [selectedSavedCard, setSelectedSavedCard] = useState('');
  const [cryptoWallet, setCryptoWallet] = useState<CryptoWallet | null>(null);
  const [cryptoLoading, setCryptoLoading] = useState(false);
  const [cryptoNetwork, setCryptoNetwork] = useState<'ETH' | 'BSC' | 'TRC20'>('TRC20');

  const updateField = (key: string, value: string) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const detectBrand = (num: string): string => {
    const cleaned = num.replace(/\s/g, '');
    if (/^4/.test(cleaned)) return 'Visa';
    if (/^5[1-5]/.test(cleaned) || /^2[2-7]/.test(cleaned)) return 'Mastercard';
    if (/^3[47]/.test(cleaned)) return 'Amex';
    if (/^6(?:011|5)/.test(cleaned)) return 'Discover';
    return '';
  };

  const handleAutoFill = (cardId: string) => {
    const card = state.savedCards.find((c) => c.id === cardId);
    if (!card) return;
    setSelectedSavedCard(cardId);
    setFormData((prev) => ({
      ...prev,
      cardholderName: card.cardholderName,
      cardNumber: `**** **** **** ${card.last4}`,
      expiry: card.expiry,
      savedCardId: card.id,
    }));
    toast.info(`Auto-filled from saved card: ${card.nickname || card.last4}`);
  };

  const createCryptoWallet = async () => {
    setCryptoLoading(true);
    try {
      const res = await fetch('/api/wallets/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ network: cryptoNetwork }),
      });
      if (res.ok) {
        const data = await res.json();
        setCryptoWallet(data.wallet);
      } else {
        toast.error('Failed to create wallet');
      }
    } catch {
      toast.error('Network error creating wallet');
    } finally {
      setCryptoLoading(false);
    }
  };

  useEffect(() => {
    if (
      open &&
      (selectedMethod === 'Crypto') &&
      !cryptoWallet
    ) {
      createCryptoWallet();
    }
    // eslint-disable-next-line
  }, [open, selectedMethod]);

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      await onSubmit({
        ...formData,
        paymentMethod: selectedMethod,
        saveCard: saveCard ? 'true' : 'false',
        saveACH: saveACH ? 'true' : 'false',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const copyAddress = (addr: string) => {
    navigator.clipboard.writeText(addr);
    toast.success('Address copied to clipboard');
  };

  const renderCardForm = () => (
    <div className="space-y-4">
      {state.savedCards.length > 0 && (
        <div>
          <label className="block text-xs text-[var(--muted-foreground)] mb-1">
            Auto-fill from saved cards
          </label>
          <select
            value={selectedSavedCard}
            onChange={(e) => handleAutoFill(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white focus:border-[var(--primary)] focus:outline-none transition-colors"
          >
            <option value="">Select a saved card...</option>
            {state.savedCards.map((c, index) => (
              <option key={`${c.id}-${index}`} value={c.id}>
                {c.brand} •••• {c.last4} — {c.nickname || c.cardholderName}
                {c.isDefault ? ' (Default)' : ''}
              </option>
            ))}
          </select>
        </div>
      )}

      <div>
        <label className="block text-xs text-[var(--muted-foreground)] mb-1">Card Number</label>
        <div className="relative">
          <input
            type="text"
            value={formData.cardNumber || ''}
            onChange={(e) => updateField('cardNumber', e.target.value)}
            placeholder="4242 4242 4242 4242"
            maxLength={19}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none transition-colors"
          />
          {formData.cardNumber && (
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[var(--muted-foreground)]">
              {detectBrand(formData.cardNumber || '')}
            </span>
          )}
        </div>
      </div>

      <div>
        <label className="block text-xs text-[var(--muted-foreground)] mb-1">Cardholder Name</label>
        <input
          type="text"
          value={formData.cardholderName || ''}
          onChange={(e) => updateField('cardholderName', e.target.value)}
          placeholder="John Doe"
          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none transition-colors"
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs text-[var(--muted-foreground)] mb-1">Expiry (MM/YY)</label>
          <input
            type="text"
            value={formData.expiry || ''}
            onChange={(e) => updateField('expiry', e.target.value)}
            placeholder="12/28"
            maxLength={5}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none transition-colors"
          />
        </div>
        <div>
          <label className="block text-xs text-[var(--muted-foreground)] mb-1">CVV</label>
          <input
            type="password"
            value={formData.cvv || ''}
            onChange={(e) => updateField('cvv', e.target.value)}
            placeholder="•••"
            maxLength={4}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none transition-colors"
          />
        </div>
      </div>

      {/* Billing Address - Collapsible */}
      <div className="border border-white/5 rounded-lg">
        <button
          type="button"
          onClick={() => setShowBilling(!showBilling)}
          className="w-full flex items-center justify-between px-3 py-2.5 text-xs text-[var(--muted-foreground)] hover:text-white transition-colors"
        >
          <span>Billing Address</span>
          {showBilling ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>
        {showBilling && (
          <div className="px-3 pb-3 space-y-3">
            <input
              type="text"
              value={formData.street || ''}
              onChange={(e) => updateField('street', e.target.value)}
              placeholder="Street address"
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none"
            />
            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                value={formData.city || ''}
                onChange={(e) => updateField('city', e.target.value)}
                placeholder="City"
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none"
              />
              <input
                type="text"
                value={formData.state || ''}
                onChange={(e) => updateField('state', e.target.value)}
                placeholder="State"
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                value={formData.zip || ''}
                onChange={(e) => updateField('zip', e.target.value)}
                placeholder="ZIP / Postal Code"
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none"
              />
              <input
                type="text"
                value={formData.country || ''}
                onChange={(e) => updateField('country', e.target.value)}
                placeholder="Country"
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none"
              />
            </div>
          </div>
        )}
      </div>

      {/* Save Card Toggle */}
      <div className="flex items-center justify-between">
        <span className="text-xs text-[var(--muted-foreground)]">Save this card for future use</span>
        <button
          type="button"
          onClick={() => setSaveCard(!saveCard)}
          className={`relative w-10 h-5 rounded-full transition-colors duration-200 ${
            saveCard ? 'bg-[var(--primary)]' : 'bg-white/10'
          }`}
        >
          <span
            className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform duration-200 ${
              saveCard ? 'translate-x-5' : 'translate-x-0.5'
            }`}
          />
        </button>
      </div>
      {saveCard && (
        <input
          type="text"
          value={formData.nickname || ''}
          onChange={(e) => updateField('nickname', e.target.value)}
          placeholder="Card nickname (e.g. Personal Visa)"
          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none"
        />
      )}
    </div>
  );

  const renderACHForm = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-xs text-[var(--muted-foreground)] mb-1">Routing Number</label>
        <input
          type="text"
          value={formData.routingNumber || ''}
          onChange={(e) => updateField('routingNumber', e.target.value)}
          placeholder="021000021"
          maxLength={9}
          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none"
        />
      </div>
      <div>
        <label className="block text-xs text-[var(--muted-foreground)] mb-1">Account Number</label>
        <input
          type="text"
          value={formData.accountNumber || ''}
          onChange={(e) => updateField('accountNumber', e.target.value)}
          placeholder="123456789"
          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none"
        />
      </div>
      <div>
        <label className="block text-xs text-[var(--muted-foreground)] mb-1">Bank Name</label>
        <input
          type="text"
          value={formData.bankName || ''}
          onChange={(e) => updateField('bankName', e.target.value)}
          placeholder="Chase Bank"
          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder:text-white/20 focus:border-[var(--primary)] focus:outline-none"
        />
      </div>
      <div>
        <label className="block text-xs text-[var(--muted-foreground)] mb-1">Account Type</label>
        <select
          value={formData.accountType || 'checking'}
          onChange={(e) => updateField('accountType', e.target.value)}
          className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white focus:border-[var(--primary)] focus:outline-none"
        >
          <option value="checking">Checking</option>
          <option value="savings">Savings</option>
        </select>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-xs text-[var(--muted-foreground)]">Save for future use</span>
        <button
          type="button"
          onClick={() => setSaveACH(!saveACH)}
          className={`relative w-10 h-5 rounded-full transition-colors duration-200 ${
            saveACH ? 'bg-[var(--primary)]' : 'bg-white/10'
          }`}
        >
          <span
            className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform duration-200 ${
              saveACH ? 'translate-x-5' : 'translate-x-0.5'
            }`}
          />
        </button>
      </div>
    </div>
  );

  const renderCryptoForm = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-xs text-[var(--muted-foreground)] mb-1">Network</label>
        <div className="flex gap-2">
          {(['ETH', 'BSC', 'TRC20'] as const).map((net) => (
            <button
              key={net}
              type="button"
              onClick={() => {
                setCryptoNetwork(net);
                setCryptoWallet(null);
              }}
              className={`px-4 py-2 rounded-lg text-xs font-medium border transition-all ${
                cryptoNetwork === net
                  ? 'border-[var(--primary)] bg-[var(--primary)]/10 text-[var(--primary)]'
                  : 'border-white/10 bg-white/5 text-[var(--muted-foreground)] hover:border-white/20'
              }`}
            >
              {net}
            </button>
          ))}
        </div>
      </div>

      {!cryptoWallet && !cryptoLoading && (
        <button
          type="button"
          onClick={createCryptoWallet}
          className="w-full py-2.5 rounded-lg bg-[var(--secondary)]/20 text-[var(--secondary)] text-sm font-medium border border-[var(--secondary)]/30 hover:bg-[var(--secondary)]/30 transition-colors"
        >
          Generate Agent Wallet
        </button>
      )}

      {cryptoLoading && (
        <div className="flex items-center justify-center gap-2 py-4 text-[var(--muted-foreground)]">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span className="text-sm">Generating {cryptoNetwork} wallet...</span>
        </div>
      )}

      {cryptoWallet && (
        <div className="space-y-3 p-4 rounded-lg bg-white/5 border border-white/10">
          <div className="flex items-center gap-2 text-xs text-[var(--muted-foreground)]">
            <span className="px-2 py-0.5 rounded bg-[var(--primary)]/10 text-[var(--primary)] font-medium">
              {cryptoWallet.network}
            </span>
            <span>Agent Deposit Wallet</span>
          </div>
          <div className="font-mono text-xs text-white break-all bg-black/30 rounded-lg p-3">
            {cryptoWallet.address}
          </div>
          <button
            type="button"
            onClick={() => copyAddress(cryptoWallet.address)}
            className="flex items-center gap-1.5 text-xs text-[var(--secondary)] hover:text-white transition-colors"
          >
            <Copy className="h-3.5 w-3.5" />
            Copy Address
          </button>
          <div className="text-xs text-[var(--accent)] bg-[var(--accent)]/10 rounded-lg p-2 border border-[var(--accent)]/20">
            Deposit exactly {paymentDetails.amount} {paymentDetails.currency} to this address. 
            The agent will auto-detect the deposit and execute payment.
          </div>
          <div className="flex items-center gap-2 text-xs text-[var(--muted-foreground)]">
            <Loader2 className="h-3.5 w-3.5 animate-spin text-[var(--primary)]" />
            <span>Waiting for deposit confirmation...</span>
          </div>
        </div>
      )}
    </div>
  );

  const renderDigitalWalletForm = () => (
    <div className="space-y-4 text-center py-6">
      <div className="w-16 h-16 mx-auto rounded-2xl bg-white/5 flex items-center justify-center">
        <CreditCard className="h-8 w-8 text-[var(--secondary)]" />
      </div>
      <p className="text-sm text-[var(--muted-foreground)]">
        You will be redirected to complete payment with <strong className="text-white">{selectedMethod}</strong>.
      </p>
      <p className="text-xs text-[var(--muted-foreground)]">
        The agent will handle the authentication flow automatically.
      </p>
    </div>
  );

  const renderForm = () => {
    if (selectedMethod === 'Credit Card' || selectedMethod === 'Debit Card') return renderCardForm();
    if (selectedMethod === 'ACH' || selectedMethod === 'Bank Transfer') return renderACHForm();
    if (selectedMethod === 'Crypto') return renderCryptoForm();
    return renderDigitalWalletForm();
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay"
          onClick={(e) => {
            if (e.target === e.currentTarget) onClose();
          }}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="w-full max-w-lg max-h-[90vh] overflow-y-auto glass-panel rounded-2xl border border-white/10 shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
              <div className="flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-[var(--primary)]" />
                <h2 className="text-lg font-semibold text-white">{selectedMethod}</h2>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
              >
                <X className="h-5 w-5 text-[var(--muted-foreground)]" />
              </button>
            </div>

            {/* Payment Summary */}
            <div className="px-6 py-3 bg-white/[0.02] border-b border-white/5">
              <div className="flex items-center justify-between text-sm">
                <span className="text-[var(--muted-foreground)]">{paymentDetails.vendor}</span>
                <span className="font-semibold text-white">
                  {paymentDetails.amount.toLocaleString(undefined, {
                    style: 'currency',
                    currency: paymentDetails.currency || 'USD',
                  })}
                </span>
              </div>
            </div>

            {/* Form Content */}
            <div className="px-6 py-5">{renderForm()}</div>

            {/* Error Display */}
            {error && (
              <div className="mx-6 mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-xs text-red-400">
                {error}
              </div>
            )}

            {/* Footer */}
            <div className="px-6 py-4 border-t border-white/5 space-y-3">
              <button
                type="button"
                onClick={handleSubmit}
                disabled={submitting}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-[var(--accent)] text-black font-semibold text-sm hover:brightness-110 transition-all neon-glow-accent disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Execute Payment
                  </>
                )}
              </button>
              <p className="text-[10px] text-center text-[var(--muted-foreground)]">
                You can save this method in Settings for future use
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
