import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, ChevronDown, Save } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { toast } from 'sonner';

function Toggle({ enabled, onChange }: { enabled: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!enabled)}
      className={`relative w-11 h-6 rounded-full transition-colors duration-300 flex-shrink-0 ${
        enabled ? 'bg-primary shadow-[0_0_10px_rgba(0,255,136,0.4)]' : 'bg-white/10'
      }`}
    >
      <div
        className={`absolute top-1 w-4 h-4 bg-black rounded-full transition-transform duration-300 ${
          enabled ? 'translate-x-6' : 'translate-x-1'
        }`}
      />
    </button>
  );
}

function NumberInput({
  value,
  onChange,
  label,
}: {
  value: number;
  onChange: (v: number) => void;
  label: string;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-muted-foreground">{label}</span>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-24 bg-black/50 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm focus:outline-none focus:border-primary text-right"
      />
    </div>
  );
}

function ToggleRow({
  label,
  enabled,
  onChange,
}: {
  label: string;
  enabled: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between py-2">
      <span className="text-sm text-muted-foreground">{label}</span>
      <Toggle enabled={enabled} onChange={onChange} />
    </div>
  );
}

export default function SmartVerificationPanel() {
  const { state, dispatch } = useAppContext();
  const config = state.verificationConfig;
  const [isExpanded, setIsExpanded] = useState(false);

  const update = (partial: Partial<typeof config>) => {
    dispatch({ type: 'UPDATE_VERIFICATION_CONFIG', payload: partial });
  };

  const saveConfig = async () => {
    try {
      const res = await fetch('/api/config/verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });
      if (res.ok) {
        toast.success('Verification config saved');
      } else {
        toast.error('Failed to save config');
      }
    } catch {
      toast.error('Network error saving config');
    }
  };

  return (
    <div className="glass-panel rounded-2xl border-white/5 overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-5 hover:bg-white/5 transition-colors"
      >
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-5 h-5 text-secondary" />
          <span className="font-bold text-white">Smart Verification Controls</span>
        </div>
        <motion.div animate={{ rotate: isExpanded ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-5 h-5 text-muted-foreground" />
        </motion.div>
      </button>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 space-y-6">
              {/* Security Group */}
              <div>
                <h4 className="text-xs uppercase tracking-wider text-secondary font-bold mb-3">
                  Security
                </h4>
                <div className="space-y-1 bg-white/5 rounded-xl p-4">
                  <div className="flex items-center justify-between py-2">
                    <span className="text-sm text-muted-foreground">CVC Modifier</span>
                    <div className="flex gap-1">
                      {(['none', 'generate', 'remove', 'bypass'] as const).map((opt) => (
                        <button
                          key={opt}
                          onClick={() => update({ cvcModifier: opt })}
                          className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                            config.cvcModifier === opt
                              ? 'bg-secondary text-secondary-foreground'
                              : 'bg-white/5 text-muted-foreground hover:bg-white/10'
                          }`}
                        >
                          {opt.charAt(0).toUpperCase() + opt.slice(1)}
                        </button>
                      ))}
                    </div>
                  </div>
                  <ToggleRow
                    label="Remove Payment Agent (Stripe)"
                    enabled={config.removePaymentAgent}
                    onChange={(v) => update({ removePaymentAgent: v })}
                  />
                  <ToggleRow
                    label="3D Bypass (Stripe & Xsolla)"
                    enabled={config.bypass3D}
                    onChange={(v) => update({ bypass3D: v })}
                  />
                  <ToggleRow
                    label="Remove Zip Code"
                    enabled={config.removeZipCode}
                    onChange={(v) => update({ removeZipCode: v })}
                  />
                  <ToggleRow
                    label="Cancel 3D Popup"
                    enabled={config.cancel3DPopup}
                    onChange={(v) => update({ cancel3DPopup: v })}
                  />
                </div>
              </div>

              {/* Privacy Group */}
              <div>
                <h4 className="text-xs uppercase tracking-wider text-secondary font-bold mb-3">
                  Privacy
                </h4>
                <div className="space-y-1 bg-white/5 rounded-xl p-4">
                  <ToggleRow
                    label="Block Analytics"
                    enabled={config.blockAnalytics}
                    onChange={(v) => update({ blockAnalytics: v })}
                  />
                  <NumberInput
                    label="Proxy Interval (mins)"
                    value={config.proxyInterval}
                    onChange={(v) => update({ proxyInterval: v })}
                  />
                </div>
              </div>

              {/* Automation Group */}
              <div>
                <h4 className="text-xs uppercase tracking-wider text-secondary font-bold mb-3">
                  Automation
                </h4>
                <div className="space-y-1 bg-white/5 rounded-xl p-4">
                  <ToggleRow
                    label="Enable Autofill"
                    enabled={config.enableAutofill}
                    onChange={(v) => update({ enableAutofill: v })}
                  />
                  <ToggleRow
                    label="Click on Load"
                    enabled={config.clickOnLoad}
                    onChange={(v) => update({ clickOnLoad: v })}
                  />
                  <NumberInput
                    label="Click on Load Delay (ms)"
                    value={config.clickOnLoadDelay}
                    onChange={(v) => update({ clickOnLoadDelay: v })}
                  />
                  <div className="flex items-center justify-between py-2">
                    <span className="text-sm text-muted-foreground">Clicker Path</span>
                    <input
                      type="text"
                      value={config.clickerPath}
                      onChange={(e) => update({ clickerPath: e.target.value })}
                      placeholder="CSS selector"
                      className="w-40 bg-black/50 border border-white/10 rounded-lg px-3 py-1.5 text-white text-sm focus:outline-none focus:border-primary"
                    />
                  </div>
                  <NumberInput
                    label="Clicker Interval (ms)"
                    value={config.clickerInterval}
                    onChange={(v) => update({ clickerInterval: v })}
                  />
                  <ToggleRow
                    label="Ignore Disabled"
                    enabled={config.ignoreDisabled}
                    onChange={(v) => update({ ignoreDisabled: v })}
                  />
                </div>
              </div>

              {/* Timing Group */}
              <div>
                <h4 className="text-xs uppercase tracking-wider text-secondary font-bold mb-3">
                  Timing
                </h4>
                <div className="space-y-1 bg-white/5 rounded-xl p-4">
                  <NumberInput
                    label="Delay (ms)"
                    value={config.delay}
                    onChange={(v) => update({ delay: v })}
                  />
                  <NumberInput
                    label="Timeout (ms)"
                    value={config.timeout}
                    onChange={(v) => update({ timeout: v })}
                  />
                  <ToggleRow
                    label="Enable Interval"
                    enabled={config.enableInterval}
                    onChange={(v) => update({ enableInterval: v })}
                  />
                  <NumberInput
                    label="Interval (ms)"
                    value={config.interval}
                    onChange={(v) => update({ interval: v })}
                  />
                </div>
              </div>

              {/* Feedback Group */}
              <div>
                <h4 className="text-xs uppercase tracking-wider text-secondary font-bold mb-3">
                  Feedback
                </h4>
                <div className="space-y-1 bg-white/5 rounded-xl p-4">
                  <ToggleRow
                    label="Hit Sound"
                    enabled={config.hitSound}
                    onChange={(v) => update({ hitSound: v })}
                  />
                  <ToggleRow
                    label="Hit Screenshot"
                    enabled={config.hitScreenshot}
                    onChange={(v) => update({ hitScreenshot: v })}
                  />
                  <ToggleRow
                    label="Enable Notification"
                    enabled={config.enableNotification}
                    onChange={(v) => update({ enableNotification: v })}
                  />
                  <NumberInput
                    label="Dismiss After (ms)"
                    value={config.dismissAfter}
                    onChange={(v) => update({ dismissAfter: v })}
                  />
                </div>
              </div>

              <button
                onClick={saveConfig}
                className="w-full py-3 bg-secondary text-secondary-foreground font-bold rounded-xl hover:bg-secondary/90 transition-all flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save Configuration
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
