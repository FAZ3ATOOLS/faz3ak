import React from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { useAppContext } from '../context/AppContext';
import { Sidebar } from './Sidebar';
import { NotificationBell } from './NotificationBell';
import { Wifi, WifiOff } from 'lucide-react';
import { useWebSocket } from '../context/WebSocketContext';

import LandingPage from '../pages/LandingPage';
import DashboardPage from '../pages/DashboardPage';
import ProcessPage from '../pages/ProcessPage';
import SettingsPage from '../pages/SettingsPage';
import TransactionDetailsPage from '../pages/TransactionDetailsPage';

const pageComponents: Record<string, React.ComponentType> = {
  landing: LandingPage,
  dashboard: DashboardPage,
  process: ProcessPage,
  settings: SettingsPage,
  'transaction-details': TransactionDetailsPage,
};

export function Layout() {
  const { state } = useAppContext();
  const { isConnected } = useWebSocket();
  const isLanding = state.activeTab === 'landing';

  const PageComponent = pageComponents[state.activeTab] || LandingPage;

  return (
    <div className="min-h-screen bg-[var(--background)] text-white">
      {!isLanding && <Sidebar />}

      <div className={!isLanding ? 'ml-20 lg:ml-64 rtl:ml-0 rtl:mr-20 lg:rtl:mr-64' : ''}>
        {/* Header */}
        {!isLanding && (
          <header className="sticky top-0 z-30 glass-panel border-b border-white/5">
            <div className="flex items-center justify-between px-6 py-3">
              <div className="flex items-center gap-2">
                {isConnected ? (
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400">
                    <Wifi className="h-3.5 w-3.5" />
                    <span>Connected</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 text-xs text-[var(--muted-foreground)]">
                    <WifiOff className="h-3.5 w-3.5" />
                    <span>Reconnecting...</span>
                  </div>
                )}
              </div>
              <NotificationBell />
            </div>
          </header>
        )}

        {/* Main Content */}
        <main className={!isLanding ? 'p-6' : ''}>
          <AnimatePresence mode="wait">
            <motion.div
              key={state.activeTab}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.2 }}
            >
              <PageComponent />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
