import React from 'react';
import { CreditCard, Bitcoin, Banknote, Wallet, Smartphone, Globe, AlertCircle } from 'lucide-react';

interface PaymentMethodSelectorProps {
  availableMethods: string[];
  onSelect: (method: string) => void;
}

const methodIcons: Record<string, React.ReactNode> = {
  'Credit Card': <CreditCard className="h-6 w-6" />,
  'Debit Card': <CreditCard className="h-6 w-6" />,
  'PayPal': <Globe className="h-6 w-6" />,
  'Apple Pay': <Smartphone className="h-6 w-6" />,
  'Google Pay': <Smartphone className="h-6 w-6" />,
  'Crypto': <Bitcoin className="h-6 w-6" />,
  'ACH': <Banknote className="h-6 w-6" />,
  'Bank Transfer': <Banknote className="h-6 w-6" />,
  'Bitcoin': <Bitcoin className="h-6 w-6" />,
  'Ethereum': <Bitcoin className="h-6 w-6" />,
  'USDT': <Bitcoin className="h-6 w-6" />,
  'Wire Transfer': <Banknote className="h-6 w-6" />,
  'SEPA': <Banknote className="h-6 w-6" />,
  'iDEAL': <Banknote className="h-6 w-6" />,
  'Sofort': <Banknote className="h-6 w-6" />,
  'Klarna': <Wallet className="h-6 w-6" />,
  'Afterpay': <Wallet className="h-6 w-6" />,
  'Affirm': <Wallet className="h-6 w-6" />,
  'Venmo': <Wallet className="h-6 w-6" />,
  'Cash App': <Wallet className="h-6 w-6" />,
  'Alipay': <Globe className="h-6 w-6" />,
  'WeChat Pay': <Smartphone className="h-6 w-6" />,
};

function getIcon(method: string): React.ReactNode {
  return methodIcons[method] || <Wallet className="h-6 w-6" />;
}

export default function PaymentMethodSelector({
  availableMethods,
  onSelect,
}: PaymentMethodSelectorProps) {
  // Deduplicate methods and filter out empty strings
  const uniqueMethods = React.useMemo(() => {
    const seen = new Set<string>();
    const result: string[] = [];
    for (const method of availableMethods) {
      const trimmed = method?.trim();
      if (trimmed && !seen.has(trimmed)) {
        seen.add(trimmed);
        result.push(trimmed);
      }
    }
    return result;
  }, [availableMethods]);

  if (uniqueMethods.length === 0) {
    return (
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
          Available Payment Methods
        </h3>
        <div className="flex flex-col items-center gap-3 p-6 rounded-xl border border-white/10 bg-white/5 text-muted-foreground">
          <AlertCircle className="h-8 w-8 text-muted-foreground/50" />
          <p className="text-sm text-center">No specific payment methods detected on this page.</p>
          <p className="text-xs text-center text-muted-foreground/70">
            The link may require manual inspection, or the page may use a custom payment flow.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
        Available Payment Methods
      </h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {uniqueMethods.map((method) => (
          <button
            key={`method-${method}`}
            type="button"
            onClick={() => onSelect(method)}
            className="flex flex-col items-center gap-2 p-4 rounded-xl border transition-all duration-200 border-white/10 bg-white/5 text-muted-foreground hover:border-primary hover:bg-primary/10 hover:text-primary"
          >
            {getIcon(method)}
            <span className="text-xs font-medium text-center">{method}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
