import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Loader2, AlertTriangle, XCircle } from 'lucide-react';
import { StatusBadge } from './StatusBadge';
import type { Transaction } from '../types';

interface TransactionCardProps {
  key?: React.Key;
  transaction: Transaction;
  onClick: (id?: string) => void;
}

const statusIcons: Record<string, React.ReactNode> = {
  processing: <Loader2 className="h-5 w-5 text-blue-400 animate-spin" />,
  success: <CheckCircle2 className="h-5 w-5 text-emerald-400" />,
  failed: <XCircle className="h-5 w-5 text-red-400" />,
  declined: <AlertTriangle className="h-5 w-5 text-red-400" />,
  error: <AlertTriangle className="h-5 w-5 text-orange-400" />,
};

export function TransactionCard({ transaction, onClick }: TransactionCardProps) {
  const formattedDate = new Date(transaction.timestamp).toLocaleString();
  const icon = statusIcons[transaction.status] || statusIcons.error;

  return (
    <motion.button
      type="button"
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      onClick={() => onClick(transaction.id)}
      className="w-full glass-panel rounded-xl p-4 hover:border-primary/40 hover:shadow-[0_0_20px_rgba(0,255,136,0.15)] transition-all duration-300 cursor-pointer text-left group"
    >
      <div className="flex items-center gap-4">
        <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
          {icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className="text-sm font-medium text-white truncate">
              {transaction.vendor}
            </span>
            <span className="text-xs text-[var(--muted-foreground)] px-1.5 py-0.5 rounded bg-white/5">
              {transaction.gateway}
            </span>
          </div>
          <div className="flex items-center gap-2 text-xs text-[var(--muted-foreground)]">
            <span className="font-mono">{transaction.id}</span>
            <span>•</span>
            <span>{formattedDate}</span>
            <span>•</span>
            <span className="capitalize">{transaction.paymentMethod}</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <span className="text-sm font-semibold text-white">
            {transaction.amount.toLocaleString(undefined, {
              style: 'currency',
              currency: transaction.currency || 'USD',
            })}
          </span>
          <StatusBadge status={transaction.status} />
        </div>
      </div>
    </motion.button>
  );
}
