import React from 'react';
import { Home, LayoutDashboard, CreditCard, Settings, Languages, Bot } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useAppContext } from '../context/AppContext';
import type { TabType } from '../types';

interface NavItem {
  id: TabType;
  labelKey: string;
  icon: React.ReactNode;
}

const navItems: NavItem[] = [
  { id: 'landing', labelKey: 'nav.home', icon: <Home className="h-5 w-5" /> },
  { id: 'dashboard', labelKey: 'nav.dashboard', icon: <LayoutDashboard className="h-5 w-5" /> },
  { id: 'process', labelKey: 'nav.newPayment', icon: <CreditCard className="h-5 w-5" /> },
  { id: 'settings', labelKey: 'nav.settings', icon: <Settings className="h-5 w-5" /> },
];

export function Sidebar() {
  const { t, i18n } = useTranslation();
  const { state, dispatch } = useAppContext();

  const toggleLanguage = () => {
    const newLang = state.language === 'en' ? 'ar' : 'en';
    dispatch({ type: 'SET_LANGUAGE', payload: newLang });
    i18n.changeLanguage(newLang);
    document.documentElement.dir = newLang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = newLang;
  };

  return (
    <aside className="fixed left-0 top-0 h-full w-20 lg:w-64 glass-panel border-r border-white/5 flex flex-col z-40 rtl:left-auto rtl:right-0 rtl:border-r-0 rtl:border-l rtl:border-white/5">
      {/* Brand */}
      <div className="flex items-center gap-3 px-4 py-6 border-b border-white/5">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--primary)] to-[var(--secondary)] flex items-center justify-center flex-shrink-0 neon-glow-primary">
          <Bot className="h-5 w-5 text-black" />
        </div>
        <div className="hidden lg:block">
          <div className="text-xs font-bold tracking-wider text-[var(--primary)]">
            {t('brand.teamName')}
          </div>
          <div className="text-sm font-semibold text-white">
            {t('brand.agentPayer')}
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-2 space-y-1">
        {navItems.map((item) => {
          const isActive = state.activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: item.id })}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 group ${
                isActive
                  ? 'bg-[var(--primary)]/10 text-[var(--primary)] neon-glow-primary'
                  : 'text-[var(--muted-foreground)] hover:bg-white/5 hover:text-white'
              }`}
            >
              <span className={`flex-shrink-0 ${isActive ? 'drop-shadow-[0_0_6px_rgba(0,255,136,0.5)]' : ''}`}>
                {item.icon}
              </span>
              <span className="hidden lg:block text-sm font-medium">{t(item.labelKey)}</span>
            </button>
          );
        })}
      </nav>

      {/* Language Toggle */}
      <div className="px-2 pb-6">
        <button
          type="button"
          onClick={toggleLanguage}
          className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-[var(--muted-foreground)] hover:bg-white/5 hover:text-white transition-all duration-200"
        >
          <Languages className="h-5 w-5 flex-shrink-0" />
          <span className="hidden lg:block text-sm font-medium">
            {t('common.switchLang')}
          </span>
        </button>
      </div>
    </aside>
  );
}
