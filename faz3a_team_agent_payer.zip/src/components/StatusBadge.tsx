interface StatusBadgeProps {
  status: 'processing' | 'success' | 'failed' | 'declined' | 'error';
  className?: string;
}

const statusConfig: Record<string, { label: string; classes: string }> = {
  processing: {
    label: 'Processing',
    classes: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  },
  success: {
    label: 'Success',
    classes: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  },
  failed: {
    label: 'Failed',
    classes: 'bg-red-500/20 text-red-400 border-red-500/30',
  },
  declined: {
    label: 'Declined',
    classes: 'bg-red-500/20 text-red-400 border-red-500/30',
  },
  error: {
    label: 'Error',
    classes: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  },
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status] || statusConfig.error;

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium ${config.classes} ${className || ''}`}
    >
      {status === 'processing' && (
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-blue-400 opacity-75" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-blue-500" />
        </span>
      )}
      {config.label}
    </span>
  );
}
