export interface Transaction {
  id: string;
  vendor: string;
  amount: number;
  currency: string;
  gateway: string;
  status: 'processing' | 'success' | 'failed' | 'declined' | 'error';
  timestamp: string;
  paymentMethod: 'card' | 'crypto' | 'ach' | 'paypal' | 'applepay' | 'googlepay';
  riskScore: string;
  description: string;
  availablePaymentMethods?: string[];
  errorDetails?: string;
  stages?: TransactionStage[];
  proof?: PaymentProof;
}

export interface TransactionStage {
  name: string;
  status: 'pending' | 'active' | 'completed' | 'failed';
  timestamp: string;
  message?: string;
}

export interface PaymentProof {
  screenshotUrl?: string;
  confirmationUrl?: string;
  transactionId?: string;
  receiptPdfUrl?: string;
}

export interface PaymentDetails {
  vendor: string;
  amount: number;
  currency: string;
  description: string;
  gateway: string;
  riskScore: 'Low' | 'Medium' | 'High';
  availablePaymentMethods: string[];
}

export interface SavedCard {
  id: string;
  last4: string;
  brand: string;
  cardholderName: string;
  expiry: string;
  nickname: string;
  isDefault: boolean;
}

export interface SavedACH {
  id: string;
  routingNumber: string;
  accountLast4: string;
  bankName: string;
  accountType: 'checking' | 'savings';
}

export interface CryptoWallet {
  id: string;
  network: 'ETH' | 'BSC' | 'TRC20';
  address: string;
  privateKey: string;
  balance: string;
}

export interface SmartVerificationConfig {
  cvcModifier: 'none' | 'generate' | 'remove' | 'bypass';
  removePaymentAgent: boolean;
  bypass3D: boolean;
  removeZipCode: boolean;
  blockAnalytics: boolean;
  hitSound: boolean;
  hitScreenshot: boolean;
  cancel3DPopup: boolean;
  clickOnLoad: boolean;
  clickOnLoadDelay: number;
  clickerPath: string;
  clickerInterval: number;
  ignoreDisabled: boolean;
  enableNotification: boolean;
  dismissAfter: number;
  proxyInterval: number;
  enableAutofill: boolean;
  delay: number;
  timeout: number;
  enableInterval: boolean;
  interval: number;
}

export interface AppNotification {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  transactionId?: string;
}

export const DEFAULT_VERIFICATION_CONFIG: SmartVerificationConfig = {
  cvcModifier: 'none',
  removePaymentAgent: false,
  bypass3D: false,
  removeZipCode: false,
  blockAnalytics: true,
  hitSound: true,
  hitScreenshot: true,
  cancel3DPopup: false,
  clickOnLoad: false,
  clickOnLoadDelay: 2000,
  clickerPath: '',
  clickerInterval: 5000,
  ignoreDisabled: false,
  enableNotification: true,
  dismissAfter: 2000,
  proxyInterval: 0.5,
  enableAutofill: true,
  delay: 5000,
  timeout: 5000,
  enableInterval: false,
  interval: 5000,
};

export type TabType = 'landing' | 'dashboard' | 'process' | 'settings' | 'transaction-details';
